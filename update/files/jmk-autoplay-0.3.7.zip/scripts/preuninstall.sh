#!/system/bin/sh
# Stops the daemon. On a real uninstall it puts back exactly what we changed: the cfg lines we commented, the files we
# added, the properties' earlier values (a reboot applies it). NEMESIS runs this before every update too: then the
# changes stay (the new postinstall finds them in place).
# 0.3.0: Wireless AutoPlay comes as a pair with its HUD · 계기판 길안내 add-on (jmk-autoplay-hud, a package of its own,
# AGPL-3.0, depends on this one). The JMK MAP menu removes the add-on first; uninstalled here by hand (NEMESIS Manager)
# while the add-on is still there, its patched stock apps stay behind without these features: a clear warning (a hook
# never runs nemesis itself).
# 0.3.4 (QA 2026-11-19 #6): when something could not be put back, the records and INSTALLED stay and the hook exits 1
# (NEMESIS then keeps the package), so a later uninstall can still undo it. Before, the records went anyway and our
# cfg edit and feature files stayed in /system for good.
. ./scripts/common.sh
log_cap $LOG
log "preuninstall jmk-autoplay"
stop_daemon
real_uninstall || exit 0
if hud=$(hud_addon); then
    log "WARNING: JMK AutoPlay 확장(jmk-autoplay-hud)이 아직 설치되어 있습니다 ($hud). 그 확장이 바꾼 순정 앱은 그대로 남습니다: NEMESIS Manager에서 jmk-autoplay-hud도 제거하고 재부팅하세요 (the add-on's patched stock apps stay until it is uninstalled too)"
    sh_report preuninstall-hud-left "$hud"
fi
ok=1
put_back || ok=0
if [ $ok -eq 0 ]; then
    log "FAIL: uninstall stopped: the records stay in $STORE, so it can be done again with /system writable"
    sh_report preuninstall-failed "cfg $(md5of "$(cfg_path)"); added $(cat $ADDED 2>/dev/null)"
    exit 1
fi
props_restore
# 0.3.4 (QA #15): the stock cfg copy older versions kept (never used, stale after a firmware update) goes too
rm -f $COMMENTED $ADDED $PROPS_BEFORE $LOCKED $INSTALLED $BACKUP/featurexml.cfg
rmdir $BACKUP 2>/dev/null
log "uninstalled: stock features back (reboot to apply)"
exit 0
