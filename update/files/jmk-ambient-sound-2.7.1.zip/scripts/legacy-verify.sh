#!/system/bin/sh
# The runner's verify (migrate.meta: verify=): exit 0 = the files LivePatch would take as stock carry none of our legacy edits (no rename in the CarPlay library, no apk in /system/app
# that no installed package owns; the apk of an installed package is the uninstall's to remove and the runner verifies BEFORE it); anything else = not stock, one line says why. It writes nothing. Run as root from the folder of the NEW zip, also before the restore on a legacy car (exit 1 there).
here=${JMK_TMP:-}
if [ -z "$here" ]; then case $0 in */*) here=${0%/*}; here=${here%/*} ;; *) here=.. ;; esac; fi
dex=$here/bin/miclight.dex
[ -r "$dex" ] || { echo 'legacy-verify: miclight.dex missing'; exit 22; }
data=${JMK_TMP:+$JMK_TMP/var}
[ -n "$data" ] || data=${TMPDIR:-/data/local/tmp}/jmk-ambient-ctl
mkdir -p "$data/dalvik-cache" 2>/dev/null || { echo "legacy-verify: cannot create $data"; exit 22; }
ANDROID_DATA=$data CLASSPATH=$dex /system/bin/app_process /system/bin jmkaudioprobe.AmbientCtl ambient.legacy.verify </dev/null
