#!/system/bin/sh
set -e
. ./scripts/common.sh
# 2.7.0: nothing in /system to put back: LivePatch removes the wrapper property with the package. This hook stops the worker, puts the light back, backs the recipes up,
# removes the user app (ambient.app.remove) and drops its runtime copy. No setprop, no remount, no tap removal.
stop_worker || { echo 'Could not stop the ambient worker; leaving everything untouched' >&2; exit 1; }
if [ -r "$RECIPE_FILE" ]; then
    mkdir -p "$RECIPE_BACKUP"
    chmod 0700 "$RECIPE_BACKUP"
    recipe_copy=$RECIPE_BACKUP/recipes-$(date +%Y%m%d-%H%M%S)-$$.json
    cp "$RECIPE_FILE" "$recipe_copy"
    chmod 0600 "$recipe_copy"
    same_file "$RECIPE_FILE" "$recipe_copy" || exit 1
    echo "Recipe backup: $recipe_copy"
fi
ctl ambient.app.remove || true   # the settings saved, then pm uninstall of the user app (NEMESIS did that for an [app.0]; an update removes the old apps too)
ctl ambient.runtime.drop || true
echo 'Recipes remain in app data and a readable copy was backed up when available.'
