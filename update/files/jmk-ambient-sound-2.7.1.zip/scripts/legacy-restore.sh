#!/system/bin/sh
# Run by the JMK MAP menu's migration runner (migrate.meta: restore=), as root, from the folder of the NEW zip, before the legacy package is uninstalled (2.7.0).
# It takes out what a 2.x install left that the LivePatch install must not find: the worker, our rename in the CarPlay library, the wrapper property; it saves the
# user's settings. Exit 0 restored, 10 nothing to do, 21 our rename found and not undoable, 22 the helper cannot run (anything but 0 / 10 stops the migration).
# The work is the verb ambient.legacy.restore in this zip's bin/miclight.dex (the installed old package may be any version: nothing of it is used but its controller).
here=${JMK_TMP:-}
if [ -z "$here" ]; then case $0 in */*) here=${0%/*}; here=${here%/*} ;; *) here=.. ;; esac; fi
dex=$here/bin/miclight.dex
[ -r "$dex" ] || { echo 'legacy-restore: miclight.dex missing'; exit 22; }
data=${JMK_TMP:+$JMK_TMP/var}
[ -n "$data" ] || data=${TMPDIR:-/data/local/tmp}/jmk-ambient-ctl
mkdir -p "$data/dalvik-cache" 2>/dev/null || { echo "legacy-restore: cannot create $data"; exit 22; }
ANDROID_DATA=$data CLASSPATH=$dex /system/bin/app_process /system/bin jmkaudioprobe.AmbientCtl ambient.legacy.restore </dev/null
rc=$?
echo "legacy-restore: exit $rc"
exit $rc
