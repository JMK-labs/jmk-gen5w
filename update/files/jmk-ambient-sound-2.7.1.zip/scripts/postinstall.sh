#!/system/bin/sh
set -e
. ./scripts/common.sh
# 2.7.0: nothing is written in /system. The apk is a user app that ambient.app.install puts in (no [app.0]: NEMESIS would install it at once, also over a legacy package that a boot has not yet unregistered), the CarPlay sound tap's property is its [prop.1], the shim
# is bin/libjmkalsa.so of this package. What is left: the runtime copy for the light worker, the old package's worker, the home tile, and the marks.
[ -f app/JMKAmbient.apk ] && [ -f bin/miclight.dex ] || exit 1
# Taking over from the old package id (ambient-sound, app org.gen5w.ambientsound, up to 2.0.7): stop its worker so the two never fight over the
# light (and start ours after this install if it ran), and leave its settings where the new app imports them. (ambient.migrate.old)
ctl ambient.migrate.old || true
chmod 0755 "$PKG" "$PKG/bin" "$PKG/scripts"
chmod 0644 "$PKG/bin/miclight.dex" "$PKG/bin/ambient_party_mode.sh" "$PKG/bin/libjmkalsa.so"
stage=/data/nemesis/jmk-ambient-sound-stage-$$
[ ! -e "$stage" ] || { echo 'Runtime staging path already exists' >&2; exit 1; }
mkdir "$stage"
chmod 0755 "$stage"
trap 'rm -rf "$stage"' 0
cp "$PKG/bin/ambient_party_mode.sh" "$stage/ambient_party_mode.sh"
cp "$PKG/bin/miclight.dex" "$stage/miclight.dex"
chmod 0644 "$stage/ambient_party_mode.sh" "$stage/miclight.dex"
same_file "$PKG/bin/ambient_party_mode.sh" "$stage/ambient_party_mode.sh"
same_file "$PKG/bin/miclight.dex" "$stage/miclight.dex"
mkdir -p "$BACKUP"
chmod 0700 "$BACKUP"
stop_worker "$stage/ambient_party_mode.sh" || { echo 'Could not stop the ambient worker; the runtime copy is left unchanged' >&2; exit 1; }
install_runtime "$stage" || { echo 'Could not stage the system-UID runtime' >&2; exit 1; }
rm -rf "$stage"
trap - 0
# the property came after the CarPlay app started when Android is up now: tell the watcher (it stops the app once when no phone is on it); the user app takes its first wake
ctl ambient.tap.arm || true
ctl ambient.app.install || true   # the user app: not when the package is still registered as a system app (the boot service installs it after the reboot that clears it)
ctl ambient.app.wake || true
ctl ambient.tiles.install "dir=$PWD" || true
# another model not checked yet: installed locked, no light command and no tap; the developer is told once per version
model_ok || locked_report
echo 'livepatch: the CarPlay sound tap applies from the next start of the CarPlay app'
exit 0
