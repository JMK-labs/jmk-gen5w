#!/system/bin/sh
set -e
. ./scripts/common.sh
# 2.7.0 (NEMESIS 1.17 LivePatch): the package changes nothing in /system. First: NEMESIS 1.17 or newer, and none of the legacy package left on the car
# (its apk copy in /system/app, our rename in the CarPlay library) and the CarPlay app able to open this package's shim under /data (shim-unreadable: a wrap property that names a
# file the app's uid cannot open would stop CarPlay at its next start): ambient.install.check refuses with a sentence and a report. The dex runs from the staging dir (this hook's cwd). If it cannot run at all we cannot prove 1.17: refuse.
CTL_DEX=$PWD/bin/miclight.dex
ctl ambient.install.check "shim=$PWD/bin/libjmkalsa.so" || exit 1
# Any head unit: on one these commands were not checked on, it installs locked (ambient.model): no light command, no CarPlay sound tap, the MAP menu's screen read-only.
ctl ambient.model say=pre || true
# the JMK MAP menu decides whether this version may run and updates it: it goes in first. Only on a first install: an update has already run the old
# package's uninstall hooks by now (NEMESIS is not transactional), so a refusal here would leave it half removed. The backups folder outlives an uninstall.
if [ ! -d "$BACKUP" ] && [ ! -d /data/nemesis/apps/jmk-map-menu ] && [ ! -d /data/nemesis/packages/jmk-map-menu ]; then
    echo 'JMK 런처 메뉴(jmk-map-menu)를 먼저 설치하세요 (install jmk-map-menu first)' >&2
    exit 1
fi
[ -f app/JMKAmbient.apk ] && [ -f bin/miclight.dex ] && [ -f bin/ambient_party_mode.sh ] && [ -f bin/libjmkalsa.so ] || { echo 'Package payload incomplete' >&2; exit 1; }
exit 0
