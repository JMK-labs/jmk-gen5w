#!/system/bin/sh
# Refuses a first install without the JMK MAP menu (its screen and updater) or next to another wireless projection
# package. An update always goes ahead: the old preuninstall has run already, a refusal would leave the car without it.
. ./scripts/common.sh
log "preinstall jmk-autoplay"
if [ ! -f $INSTALLED ]; then
    if [ ! -d $R/data/nemesis/apps/jmk-map-menu ] && [ ! -d $R/data/nemesis/packages/jmk-map-menu ]; then
        log "FAIL: JMK 런처 메뉴(jmk-map-menu)를 먼저 설치하세요 (install jmk-map-menu first)"
        sh_report preinstall-no-map "jmk-map-menu is not installed"
        exit 1
    fi
    # 0.3.1: the menu 2.3.8+ installs AutoPlay and its HUD add-on as one pair and shows their screens; an older one
    # lists them as two separate rows (one could go in without the other, CarPlay would not connect)
    mv=$(map_version)
    if ! version_at_least "$mv" 2 3 8; then
        log "FAIL: 런처 메뉴를 2.3.8 이상으로 먼저 업데이트하세요 (MAP menu ${mv:-?} found, 2.3.8+ needed)"
        sh_report preinstall-old-map "jmk-map-menu ${mv:-?}"
        exit 1
    fi
    if other=$(other_projection); then
        log "FAIL: another wireless projection package is installed: $other. Uninstall it and reboot first (다른 무선 프로젝션 프로그램이 설치되어 있습니다)"
        sh_report preinstall-other-projection "$other"
        exit 1
    fi
fi
exit 0
