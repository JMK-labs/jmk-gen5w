#!/system/bin/sh
# 2.3.70: the JMK menu's icon on the NEMESIS Manager's first screen = a tiny user app (com.jmk.map.icon, app/JMKIcon.apk) that
# only opens the menu. The Manager lists non-system apps with a launcher activity; the menu app itself is a system app.
#   icon.sh          install / refresh it (postinstall, and the daemon's start once Android is up)
#   icon.sh remove   uninstall it (a real uninstall of the package)
# NEVER fails the caller and never touches the menu: every problem ends in a line in var/icon.log and exit 0.
# This head unit takes only OEM signers while sys.boot_completed is 1: as NEMESIS does for kind=apk (and Korea Projection for its
# status app), the property is 0 for the pm call only and put back (trap) whatever happens. After 3 failures of one version
# no more tries (a failing install would otherwise repeat at every boot). (mksh: fds <= 9; no sed/head/tail)
[ -n "$ICON_TEST" ] || export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
PKG=${ICON_PKG:-/data/nemesis/apps/jmk-map-menu}
[ -d "$PKG" ] || PKG=/data/nemesis/packages/jmk-map-menu
APK="$PKG/app/JMKIcon.apk"
VC="$PKG/app/icon.vc"
ID=com.jmk.map.icon
V="$PKG/var"
log() { mkdir -p "$V" 2>/dev/null; echo "$(date '+%m-%d %H:%M:%S') icon: $1" >> "$V/icon.log" 2>/dev/null; }
android_up() { [ "$(getprop sys.boot_completed)" = 1 ]; }
has_pkg() { case "$(pm path $ID 2>/dev/null)" in *package:*) return 0 ;; esac; return 1; }
if [ "$1" = remove ]; then
    has_pkg && { r=$(pm uninstall $ID 2>&1); log "removed: $r"; }
    rm -f "$V/icon.done" "$V/icon.fail"
    exit 0
fi
# one run at a time (postinstall and the daemon's start can meet): a lock file with the pid, stale when that pid is gone (kill -0)
mkdir -p "$V" 2>/dev/null
if [ -f "$V/icon.lock" ]; then
    read -r other < "$V/icon.lock" || other=
    case "$other" in ''|*[!0-9]*) ;; *) kill -0 "$other" 2>/dev/null && [ "$other" != "$$" ] && exit 0 ;; esac
fi
echo $$ > "$V/icon.lock" 2>/dev/null
trap 'rm -f "$V/icon.lock"' EXIT
[ -f "$APK" ] && [ -f "$VC" ] || { log "no icon app in the package: skipped"; exit 0; }
read -r want < "$VC" || want=
android_up || { log "Android is not up: later"; exit 0; }
done_vc=; [ -f "$V/icon.done" ] && read -r done_vc < "$V/icon.done"
if [ "$done_vc" = "$want" ] && has_pkg; then exit 0; fi
fails=0; failed_vc=
[ -f "$V/icon.fail" ] && read -r failed_vc fails < "$V/icon.fail"
[ "$failed_vc" = "$want" ] || fails=0
case "$fails" in ''|*[!0-9]*) fails=0 ;; esac
if [ "$fails" -ge 3 ]; then log "version $want failed $fails times: not tried again"; exit 0; fi
trap 'setprop sys.boot_completed 1; rm -f "$V/icon.lock"' EXIT TERM INT HUP
setprop sys.boot_completed 0
r=$(pm install -r "$APK" 2>&1)
setprop sys.boot_completed 1
trap 'rm -f "$V/icon.lock"' EXIT
case "$r" in
    *Success*)
        mkdir -p "$V" 2>/dev/null
        echo "$want" > "$V/icon.done" 2>/dev/null
        rm -f "$V/icon.fail"
        log "installed (version $want)" ;;
    *)
        mkdir -p "$V" 2>/dev/null
        echo "$want $((fails + 1))" > "$V/icon.fail" 2>/dev/null
        log "install failed ($((fails + 1)) of 3): $r" ;;
esac
exit 0
