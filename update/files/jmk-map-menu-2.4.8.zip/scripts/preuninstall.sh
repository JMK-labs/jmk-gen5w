#!/system/bin/sh
# Leaves camping first (the daemon puts the screen, display and light back), stops the daemon, removes the app.
# NEMESIS runs this before every update too; postinstall puts the new APK back.
DIR=/data/local/tmp/jmk-map-menu
TARGET=/system/app/JMKMap.apk
if [ -f "$DIR/camp" ]; then
    rm -f "$DIR/camp"
    sleep 3
fi
if [ -f "$DIR/daemon.pid" ]; then
    read -r pid < "$DIR/daemon.pid" || pid=
    case "$pid" in
        ''|*[!0-9]*) ;;
        *) grep -q jmkmap.MapDaemon "/proc/$pid/cmdline" 2>/dev/null && kill "$pid" 2>/dev/null ;;
    esac
fi
# ☆ (2.3.19), the icon app (2.3.70), the USB port (2.3.34) and the warmer's firewall rule: the head unit's own side is Java now (2.4.0, Ops
# uninstall-stock; a failure is logged and the removal goes on: an uninstall is never blocked). After the daemon stopped, so it does not
# take the ☆ slot again; on an update the new daemon takes it again.
PKG=/data/nemesis/apps/jmk-map-menu
[ -d "$PKG" ] || PKG=/data/nemesis/packages/jmk-map-menu
ops_rc=1
if [ -f "$PKG/bin/mapmenu.dex" ]; then
    mkdir -p "$PKG/var/dalvik-cache" 2>/dev/null   # app_process aborts without it (a service that never ran leaves var empty)
    ANDROID_DATA="$PKG/var" CLASSPATH="$PKG/bin/mapmenu.dex" /system/bin/app_process /system/bin jmkmap.Ops uninstall-stock "$PPID" "$PKG" </dev/null 2>&1
    ops_rc=$?
fi
if [ "$ops_rc" != 0 ]; then
    # the restores of our own edits keep a shell fallback in the uninstall. Ops did not run (the dex is damaged or missing,
    # $PKG/var is not writable, app_process failed): the warmer's firewall rule goes, the icon app goes and the USB port comes back as before.
    # (The ☆ slot's restore stays in Java only, as it always was.)
    echo "uninstall-stock did not run (rc=$ops_rc): the shell does the restores"
    real_uninstall() {
        case "$(cat /proc/$PPID/cmdline 2>/dev/null)" in *uninstall*) return 0 ;; *install*) return 1 ;; esac
        grep -q '^id=jmk-map-menu$' /data/local/tmp/nemesis/stage/jmk-map-menu/NEMESIS.data 2>/dev/null && return 1
        return 0
    }
    if real_uninstall; then
        [ -f "$PKG/scripts/icon.sh" ] && sh "$PKG/scripts/icon.sh" remove </dev/null >/dev/null 2>&1
        usbmode=; [ -f /data/nemesis/usbmode/mode ] && read -r usbmode < /data/nemesis/usbmode/mode
        if [ "$usbmode" = mac ] || [ "$(getprop sys.usb.config)" = adb ]; then
            setprop sys.usb.config host
            echo phone > /data/nemesis/usbmode/mode 2>/dev/null
            echo "USB port back to phone mode (was PC adb)"
        fi
    fi
    /system/xbin/nemesis root 1000 -c "rm -f /data/system/ifw/jmk-warmer.xml" >/dev/null 2>&1 || rm -f /data/system/ifw/jmk-warmer.xml
fi
if [ -f "$TARGET" ]; then
    remounted=0
    while read -r dev mnt fs opts rest; do
        [ "$mnt" = /system ] || continue
        case ",$opts," in *,rw,*) ;; *) /system/xbin/nemesis remount rw && remounted=1 ;; esac
        break
    done < /proc/mounts
    rm -f "$TARGET"
    sync
    # /system stays read-write (a failing "remount ro" broke updates, car 2026-11-10)
fi
rm -f "$DIR/daemon.pid" "$DIR/status" "$DIR/request" "$DIR/vr" "$DIR/camp-dark" "$DIR/ifw-rule"
exit 0
