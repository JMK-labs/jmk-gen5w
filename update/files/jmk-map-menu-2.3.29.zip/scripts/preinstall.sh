#!/system/bin/sh
# 2.3.9 (the owner, 2026-11-17): the menu installs next to Korea Projection too (2.3.8 refused a first install there);
# what cannot run next to it (Wi-Fi Driver, Wireless AutoPlay) is left out, and 설정 → 업데이트 says what to remove first.
for d in /data/nemesis/apps/korea.projection /data/nemesis/packages/korea.projection; do
    [ -d "$d" ] && echo 'note: korea.projection is installed: Wi-Fi Driver and Wireless AutoPlay are not offered next to it' >&2
done
exit 0
