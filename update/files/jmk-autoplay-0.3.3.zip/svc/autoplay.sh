#!/system/bin/sh
# NEMESIS service (root): the JMK Wireless AutoPlay daemon (jmkautoplay.AutoPlayDaemon). It writes the status the
# JMK MAP menu shows (features, the stock hotspot, phones on it) into $DIR/status.
# (mksh: single-digit fds only; no sed/head/tail on this firmware)
export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
PKG=/data/nemesis/apps/jmk-autoplay
[ -d "$PKG" ] || PKG=/data/nemesis/packages/jmk-autoplay
DIR=/data/local/tmp/jmk-autoplay

# The MAP menu (an app, uid of its own) reads $DIR; /data/local/tmp is 0771 shell:shell after boot, and root without
# capabilities can't create in it, so ask the shell user then (that dir then stays the shell's, 0777).
if mkdir -p "$DIR" 2>/dev/null; then
    chmod 0755 "$DIR"
else
    /system/xbin/nemesis root 2000 -c "mkdir -p $DIR; chmod 0777 $DIR" </dev/null >/dev/null 2>&1
fi
mkdir -p "$DIR/req" 2>/dev/null && chmod 1777 "$DIR/req"

if [ -f "$DIR/daemon.pid" ]; then
    read -r old < "$DIR/daemon.pid" || old=
    case "$old" in
        ''|*[!0-9]*) ;;
        *) grep -q jmkautoplay.AutoPlayDaemon "/proc/$old/cmdline" 2>/dev/null && kill "$old" 2>/dev/null ;;
    esac
    rm -f "$DIR/daemon.pid"
fi
# 0.3.3: a model opened after the install (the update list gave it "projection"; installed locked, nothing was changed
# then): applied now, as an update's postinstall does (it changes the stock files only when they fit; a reboot applies)
if [ -f /data/nemesis/jmk-autoplay/locked ] && read -r why < /data/nemesis/jmk-autoplay/locked; then
    ok=$(cat /data/nemesis/jmk-updates/car-ok 2>/dev/null)
    case "$why" in model*)
        case ",$ok," in *,projection,*) ( cd "$PKG" && sh scripts/postinstall.sh ) >> "$DIR/unlock.log" 2>&1 ;; esac ;;
    esac
fi
mkdir -p "$PKG/var/dalvik-cache"
[ -f "$DIR/daemon.log" ] && mv "$DIR/daemon.log" "$DIR/daemon.log.old"
echo $$ > "$DIR/daemon.pid"
chmod 0644 "$DIR/daemon.pid"
ANDROID_DATA="$PKG/var" CLASSPATH="$PKG/bin/autoplay.dex" exec /system/bin/app_process /system/bin jmkautoplay.AutoPlayDaemon \
    </dev/null >>"$DIR/daemon.log" 2>&1
