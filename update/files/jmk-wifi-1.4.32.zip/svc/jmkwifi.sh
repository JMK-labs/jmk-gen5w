#!/system/bin/sh
# NEMESIS service (root): our driver (88x2bu; 1.4.0: 8851bu for AX900-class dongles), then the JMK Wi-Fi daemon.
# The driver goes in first and as early as possible: its usbfs block must be in place before Android's USB host
# service sees the dongle (else the stock Android Auto service probes it as a phone). Port names: wlan0 for the stock
# Wi-Fi stack's hotspot, rtwlan0 for our client (usb.mode lets adb in on rtwlan* only).
# Never rmmod it (that rebooted the head unit) and never call it bcmdhd (the stock stack rmmods that name).
# After an update started from adb this runs as root without capabilities: insmod is then impossible, and the
# daemon keeps what the previous one left running until the next boot.
# (mksh: single-digit fds only; no sed/head/tail on this firmware)
export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
PKG=/data/nemesis/apps/jmk-wifi
[ -d "$PKG" ] || PKG=/data/nemesis/packages/jmk-wifi
DIR=/data/local/tmp/jmk-wifi
ARGS='ifname=wlan%d if2name=rtwlan%d rtw_country_code=KR rtw_power_mgnt=0 rtw_ips_mode=0 rtw_enusbss=0 rtw_en_napi=0 rtw_en_gro=0'
# 1.4.0: the AX900-class driver (RTL8851BU / RTL8831BU): no power-save parameters there, its IPS/LPS are not built in
# (CONFIG_RTW_IPS / CONFIG_RTW_LPS off in its autoconf.h); rtw_usbfs_block is our patch 0003
ARGS_8851='ifname=wlan%d if2name=rtwlan%d rtw_country_code=KR rtw_en_napi=0 rtw_en_gro=0 rtw_usbfs_block=1'
STORE=/data/nemesis/jmk-wifi
# exactly 8851bu.ko's own table (driver patch 0005, the build's "USB IDs:" line); another AX chip stays unsupported
AX_IDS=' 0bda:b851 0bda:b831 3625:010b 2c4e:0128 2001:332a 7392:e611 '
VCD_IDS=' 0bda:1a2b 0bda:1a2c '
# RTL88x2BU dongles the 88x2bu driver takes (with one of these in, it is the driver: the proven one wins)
BU_IDS=' 0bda:b812 0bda:b82c 0bda:b81a 0bda:b820 0bda:b82b 2357:012d 2357:012e 2357:0138 2357:0115 0b05:184c 0b05:1841 0b05:19aa 7392:b822 7392:c822 2001:331c 2001:331e 0846:9055 13b1:0043 056e:4011 '
# vendor:product of every USB device, one string (no tr / sed on this firmware)
usb_ids() {
    ids=' '
    for d in /sys/bus/usb/devices/*; do
        [ -r "$d/idVendor" ] && [ -r "$d/idProduct" ] || continue
        read -r v < "$d/idVendor"; read -r p < "$d/idProduct"
        ids="$ids$v:$p "
    done
    echo "$ids"
}
any_of() { for i in $2; do case "$1" in *" $i "*) return 0 ;; esac; done; return 1; }
# "client" mode (the preinstall saw a stock Wi-Fi module): wlan0 belongs to the stock module, so both of our ports are
# rtwlan (the jmk.usbwifi names) and the daemon only runs the phone-hotspot client
mode=
[ -f /data/nemesis/jmk-wifi/mode ] && read -r mode < /data/nemesis/jmk-wifi/mode
# 1.4.10: a stock-chip car whose kernel does not fit our driver (the preinstall's no-driver file): nothing of ours goes
# into its kernel, only the daemon runs (기본 / 호환성 on the stock module)
nodrv=
if [ "$mode" = client ] && [ -f /data/nemesis/jmk-wifi/no-driver ]; then
    read -r nodrv < /data/nemesis/jmk-wifi/no-driver
    [ -n "$nodrv" ] || nodrv="kernel unfit"
fi
# 1.4.31 (the firmware-change review, 2026-11-26): the install's checks run again at every boot, before anything is
# loaded: the module was built for the kernel of the install, and the stock library patch for one library file. A firmware
# update (dealer / OTA) can change either; then the driver is not loaded and the car is left as the installer would leave
# it on this firmware today (kernel: client without our driver; library: locked), one line per check in driver.txt, one
# report "driver: firmware-changed". Not sticky: every boot judges the facts again, and a car that fits again (a rolled-back
# firmware, an update that put a fitting kernel / library back) returns to the mode the installer chose (report "driver:
# firmware-fits-again"). Facts read from the system, no hardware is guessed. scripts/fit.sh is shared with the preinstall.
MODE_FILE=$STORE/mode; LOCKED_FILE=$STORE/locked; NODRV_FILE=$STORE/no-driver; FP_FILE=$STORE/fingerprint; FIT_BASE_FILE=$STORE/fit-base
FIT_NOTE=; FIT_RESULT=; FIT_REPORT=
if [ -f "$PKG/scripts/fit.sh" ]; then
    . "$PKG/scripts/fit.sh"
    fit_boot "$PKG/bin/88x2bu.ko" "$PKG/bin/8851bu.ko"
    if [ -n "$FIT_REPORT" ]; then
        fitver=
        while IFS='=' read -r k v; do [ "$k" = package-version ] && fitver=$v; done < "$PKG/NEMESIS.data"
        ( fit_report "$fitver" "$FIT_REPORT" ) </dev/null >/dev/null 2>&1 &
    fi
fi
[ "$mode" = client ] && ARGS="ifname=rtwlan%d ${ARGS#ifname=wlan%d }" && ARGS_8851="ifname=rtwlan%d ${ARGS_8851#ifname=wlan%d }"

# 1.4.10: the previous boot's end as the kernel recorded it (pstore ramoops, last_kmsg, apanic; whichever this head
# unit keeps, all read only): prints the record when it shows a kernel panic / oops / BUG with 8851bu in it (its
# "Modules linked in" line lists every loaded module, so a crash in a boot that had it loaded names it)
ax_panic_record() {
    local f
    for f in /sys/fs/pstore/console-ramoops* /sys/fs/pstore/dmesg-ramoops* /proc/last_kmsg /proc/apanic_console; do
        [ -r "$f" ] || continue
        grep -qE 'Kernel panic|Internal error: Oops|Unable to handle kernel|BUG: |Watchdog bark|hard LOCKUP' "$f" 2>/dev/null || continue
        grep -q '8851bu' "$f" 2>/dev/null || continue
        echo "$f"; return 0
    done
    return 1
}

# 1.4.24 (KTYOXPX4, Ioniq 6 + A3000MINI, 2026-11-23: the head unit restarted again and again right after a phone joined
# the car hotspot, fine with the dongle out): the previous boot's kernel record for any driver; the first that shows a
# panic / oops / BUG
panic_record() {
    local f
    for f in /sys/fs/pstore/console-ramoops* /sys/fs/pstore/dmesg-ramoops* /proc/last_kmsg /proc/apanic_console; do
        [ -r "$f" ] || continue
        grep -qE 'Kernel panic|Internal error: Oops|Unable to handle kernel|BUG: |Watchdog bark|hard LOCKUP' "$f" 2>/dev/null || continue
        echo "$f"; return 0
    done
    return 1
}

# "locked" (1.3.6, the preinstall decided: another model whose kernel or library does not fit): never insmod there, no
# daemon; only the status, so that the MAP menu shows 이 차종 미지원 (pid= empty: not running)
if [ "$mode" = locked ]; then
    why=
    [ -f /data/nemesis/jmk-wifi/locked ] && read -r why < /data/nemesis/jmk-wifi/locked
    if mkdir -p "$DIR" 2>/dev/null; then chmod 0755 "$DIR"; else /system/xbin/nemesis root 2000 -c "mkdir -p $DIR; chmod 0777 $DIR" </dev/null >/dev/null 2>&1; fi
    rm -f "$DIR/status.new"
    { echo "mode=locked"; echo "locked=$why"; echo "pid="; } > "$DIR/status.new" && chmod 0644 "$DIR/status.new" && mv "$DIR/status.new" "$DIR/status"
    echo "locked: no driver on this model ($why)" > "$DIR/driver.txt"
    [ -n "$FIT_NOTE" ] && echo "$FIT_NOTE" >> "$DIR/driver.txt"
    exit 0
fi

# 1.4.0: a dongle that shows as its Windows driver disk (virtual CD) is told to switch first; it comes back as the
# Wi-Fi device a moment later
note=
ids=$(usb_ids)
# 1.4.1 (AX900 owners, 2026-11-18): at 3 s of uptime the dongle was often not on the bus yet (the reports saw 0bda:b831
# later), so 88x2bu went in and the AX900 stayed without a driver. Up to 4 s more for a known dongle to show.
n=0
while [ -z "$nodrv" ] && [ $n -lt 4 ] && ! any_of "$ids" "$BU_IDS $AX_IDS $VCD_IDS"; do sleep 1; n=$((n + 1)); ids=$(usb_ids); done   # whole seconds: toolbox sleep
[ $n -gt 0 ] && note="waited $n s for the dongle"
if [ -z "$nodrv" ] && any_of "$ids" "$VCD_IDS" && [ -x "$PKG/bin/jmkiw" ]; then
    note="eject: $("$PKG/bin/jmkiw" eject 2>&1)"
    n=0
    while [ $n -lt 16 ]; do
        sleep 0.5; n=$((n + 1))
        ids=$(usb_ids)
        any_of "$ids" "$VCD_IDS" || break
    done
    note="$note; after $((n / 2)) s: $(any_of "$ids" "$VCD_IDS" && echo 'still a CD' || echo 'switched')"
fi
# which driver: 8851bu when an AX900-class dongle is in, else 88x2bu (as before: also with no dongle yet, for a later
# plug of an RTL88x2BU one). 8851bu is a trial: two boots in a row that crashed with it (the kernel's record) or that
# loaded it without its port ever showing turn it off (the daemon reports that), so a module that hangs or panics this
# kernel cannot keep the head unit from starting.
drv=88x2bu
# 1.4.8 (QA 2026-11-19, an EV6 owner 2026-11-20): a new package version starts the guard again (a car whose 1.4.7 or
# older guard had turned the driver off after two short drives gets it back with the update); the daemon resets it
# as soon as this driver made its network port (WifiDaemon.axWorked), no timer any more
ver=
while IFS='=' read -r k v; do [ "$k" = package-version ] && ver=$v; done < "$PKG/NEMESIS.data"
seenver=; [ -f "$STORE/8851bu-ver" ] && read -r seenver < "$STORE/8851bu-ver"
if [ -n "$ver" ] && [ "$ver" != "$seenver" ]; then
    mkdir -p "$STORE" && echo 0 > "$STORE/8851bu-tries" && echo 0 > "$STORE/8851bu-panics" && echo "$ver" > "$STORE/8851bu-ver"
    echo 0 > "$STORE/88x2bu-panics"; rm -f "$STORE/88x2bu-off"   # 1.4.24: a new version tries 88x2bu again
fi
seenpanics=; [ -f "$STORE/8851bu-panics" ] && read -r seenpanics < "$STORE/8851bu-panics"
# 1.4.10 (the owner: a root fix for the guard): the kernel's own record of how the previous boot ended. A panic or
# oops with 8851bu loaded (its "Modules linked in" line or a call trace in it) counts in 8851bu-panics; a previous boot
# without one sets it to 0. Two in a row turn the driver off. Only where this head unit keeps such a record (pstore /
# last_kmsg / apanic, listed in hw-install.txt): elsewhere nothing shows and 8851bu-tries (boots that loaded it without
# its port appearing, reset by the daemon on the port) is the guard, as in 1.4.8.
panics=0
[ -f "$STORE/8851bu-panics" ] && read -r panics < "$STORE/8851bu-panics"
case "$panics" in ''|*[!0-9]*) panics=0 ;; esac
if rec=$(ax_panic_record); then
    panics=$((panics + 1))
    note="$note${note:+; }previous boot ended in a kernel panic with 8851bu ($rec, $panics in a row)"
else
    panics=0
fi
[ "$panics" != "$seenpanics" ] && mkdir -p "$STORE" && echo $panics > "$STORE/8851bu-panics" && sync
# 1.4.24: any kernel panic that ended the previous boot is said (the daemon reports its crash lines); with 88x2bu in it
# (a boot that had it loaded names it), 88x2bu-panics counts boots in a row. Two turn 88x2bu off (88x2bu-off) so that
# the head unit starts: it stays off, also over boots without it (they show no panic of it), until a new package
# version (above). A boot that had it loaded and ended without a panic sets the count to 0.
if prec=$(panic_record); then
    case "$note" in *"kernel panic with 8851bu"*) ;; *) note="$note${note:+; }previous boot ended in a kernel panic ($prec)" ;; esac
fi
bupanics=0
[ -f "$STORE/88x2bu-panics" ] && read -r bupanics < "$STORE/88x2bu-panics"
case "$bupanics" in ''|*[!0-9]*) bupanics=0 ;; esac
# (a pstore file stays until it is removed: the same record seen again is no new panic; ls -l gives its size and time)
precid=; [ -n "$prec" ] && precid=$(ls -l "$prec" 2>/dev/null)
seenid=; [ -f "$STORE/panic-seen" ] && read -r seenid < "$STORE/panic-seen"
if [ -n "$precid" ] && [ "$precid" = "$seenid" ]; then prec=; note="$note (seen before)"; fi
[ -n "$precid" ] && mkdir -p "$STORE" && echo "$precid" > "$STORE/panic-seen"
if [ ! -f "$STORE/88x2bu-off" ]; then
    if [ -n "$prec" ] && grep -q '88x2bu' "$prec" 2>/dev/null; then
        bupanics=$((bupanics + 1))
        note="$note; kernel panic with 88x2bu ($bupanics in a row)"
    else
        bupanics=0
    fi
    mkdir -p "$STORE" && echo $bupanics > "$STORE/88x2bu-panics"
    [ "$bupanics" -ge 2 ] && echo "$bupanics" > "$STORE/88x2bu-off"
    sync
fi
if [ -z "$nodrv" ] && any_of "$ids" "$AX_IDS" && ! any_of "$ids" "$BU_IDS"; then
    tries=0
    [ -f "$STORE/8851bu-tries" ] && read -r tries < "$STORE/8851bu-tries"
    case "$tries" in ''|*[!0-9]*) tries=0 ;; esac
    if [ "$panics" -ge 2 ]; then
        note="$note${note:+; }8851bu off: $panics boots in a row ended in a kernel panic with it"
    elif [ "$tries" -ge 2 ]; then
        note="$note${note:+; }8851bu off: $tries boots did not get past it"
    else
        drv=8851bu
        mkdir -p "$STORE" && echo $((tries + 1)) > "$STORE/8851bu-tries" && sync
    fi
fi
loaded=
err=
while read -r name rest; do
    [ "$name" = "$drv" ] && loaded=1
done < /proc/modules
if [ -z "$nodrv" ] && [ "$drv" = 88x2bu ] && [ -f "$STORE/88x2bu-off" ]; then
    drv=none; rc=none
    note="$note${note:+; }88x2bu off: boots in a row ended in a kernel panic with it (a new version tries again)"
elif [ -n "$nodrv" ]; then
    drv=none; rc=none
elif [ -z "$loaded" ]; then
    if [ "$drv" = 8851bu ]; then
        err=$(insmod "$PKG/bin/8851bu.ko" $ARGS_8851 2>&1)
    else
        err=$(insmod "$PKG/bin/88x2bu.ko" $ARGS 2>&1)   # 1.3.7: its error text goes into driver.txt (the daemon's report)
    fi
    rc=$?
else
    rc=loaded
fi
read -r up idle < /proc/uptime

# status and logs: root's dir, readable by all (0755), so nobody can swap a log for a symlink; requests from the menu
# app go into req/ (1777). /data/local/tmp is 0771 shell:shell after boot, and root without capabilities can't create
# in it, so ask the shell user then (that dir then stays the shell's, 0777).
if mkdir -p "$DIR" 2>/dev/null; then
    chmod 0755 "$DIR"
else
    /system/xbin/nemesis root 2000 -c "mkdir -p $DIR; chmod 0777 $DIR" </dev/null >/dev/null 2>&1
fi
mkdir -p "$DIR/req" 2>/dev/null && chmod 1777 "$DIR/req"
if [ -n "$nodrv" ]; then   # (no "insmod " in it: the daemon reports only a failed insmod)
    echo "uptime $up: no driver (mode client, stock Wi-Fi module only: $nodrv)" > "$DIR/driver.txt"
else
    echo "uptime $up: insmod $rc (mode ${mode:-emulate}) driver $drv${note:+; $note}" > "$DIR/driver.txt"
fi
case "$rc" in 0|loaded|none) ;; *) [ -n "$err" ] && echo "insmod error: $err" >> "$DIR/driver.txt" ;; esac
[ -n "$FIT_NOTE" ] && echo "$FIT_NOTE" >> "$DIR/driver.txt"   # 1.4.31: one line per fit check (none says "insmod": the daemon reports only a failed one)

# 1.4.1: an AX900-class dongle that comes on the bus after this (still enumerating, or its virtual CD switched late):
# for 90 s, switch a CD and put 8851bu in (the same two-failed-boots guard); it binds only the AX ids
if [ "$drv" = 88x2bu ] && [ "$mode" != client ]; then
    (
        n=0
        while [ $n -lt 90 ]; do
            sleep 1; n=$((n + 1))
            ids=$(usb_ids)
            any_of "$ids" "$BU_IDS" && break
            if any_of "$ids" "$VCD_IDS" && [ -x "$PKG/bin/jmkiw" ]; then "$PKG/bin/jmkiw" eject >/dev/null 2>&1; continue; fi
            any_of "$ids" "$AX_IDS" || continue
            tries=0
            [ -f "$STORE/8851bu-tries" ] && read -r tries < "$STORE/8851bu-tries"
            case "$tries" in ''|*[!0-9]*) tries=0 ;; esac
            if [ "$panics" -ge 2 ]; then echo "late AX dongle at ${n} s: 8851bu off ($panics boots in a row ended in a kernel panic with it)" >> "$DIR/driver.txt"; break; fi
            if [ "$tries" -ge 2 ]; then echo "late AX dongle at ${n} s: 8851bu off ($tries boots did not get past it)" >> "$DIR/driver.txt"; break; fi
            mkdir -p "$STORE" && echo $((tries + 1)) > "$STORE/8851bu-tries" && sync
            err=$(insmod "$PKG/bin/8851bu.ko" $ARGS_8851 2>&1); rc=$?
            echo "late AX dongle at ${n} s: insmod 8851bu $rc${err:+ ($err)}" >> "$DIR/driver.txt"
            break
        done
    ) </dev/null >/dev/null 2>&1 &
fi

if [ -f "$DIR/daemon.pid" ]; then
    read -r old < "$DIR/daemon.pid" || old=
    case "$old" in
        ''|*[!0-9]*) ;;
        *) grep -q jmkwifi.WifiDaemon "/proc/$old/cmdline" 2>/dev/null && kill "$old" 2>/dev/null ;;
    esac
    rm -f "$DIR/daemon.pid"
fi
mkdir -p "$PKG/var/dalvik-cache"
[ -f "$DIR/daemon.log" ] && mv "$DIR/daemon.log" "$DIR/daemon.log.old"
echo $$ > "$DIR/daemon.pid"
chmod 0644 "$DIR/daemon.pid"
ANDROID_DATA="$PKG/var" CLASSPATH="$PKG/bin/jmkwifi.dex" exec /system/bin/app_process /system/bin jmkwifi.WifiDaemon \
    </dev/null >>"$DIR/daemon.log" 2>&1
