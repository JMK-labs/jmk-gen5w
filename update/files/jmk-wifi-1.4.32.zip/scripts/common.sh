#!/system/bin/sh
# jmk-wifi, shared by the hooks. NEMESIS runs them as root with the package folder as the current directory.
# (this head unit's mksh: single-digit fds only; no sed/head/tail/printf; toolbox dd, md5, cmp, grep exist)
export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
# a hook started over adb runs in adbd's session: a pulled cable or a host timeout must not stop it halfway
trap '' HUP INT PIPE
PKG=/data/nemesis/apps/jmk-wifi
[ -d "$PKG" ] || PKG=/data/nemesis/packages/jmk-wifi
DIR=/data/local/tmp/jmk-wifi
STORE=/data/nemesis/jmk-wifi
BACKUP=/data/nemesis/backups/jmk-wifi
LOG=/data/nemesis/jmk-wifi.log

# 1.4.31: the library hashes and the facts the driver was made for (kernel, vermagic, stack protector) moved into
# scripts/fit.sh, which the boot service reads too (LIB, STOCK_MD5, PATCHED_MD5, P2_OFFSET are defined there)
. ./scripts/fit.sh

# "emulate": the dongle passes as the stock Wi-Fi module (chipless cars). "client": the car has the stock module, so the
# dongle only joins the phone hotspot and nothing stock is patched or driven. Decided by the preinstall, read at boot.
MODE_FILE=$STORE/mode
HW_FILE=$STORE/hw-install.txt   # what the preinstall saw (the USB installer copies it into its log)
# "locked" (1.3.6): why, one line (the kernel or the library did not fit); the service puts it into the status
LOCKED_FILE=$STORE/locked
# 1.4.10: a stock-chip car whose kernel does not fit our dongle driver: why, one line; the service then loads no driver
NODRV_FILE=$STORE/no-driver
# 1.4.31: ro.build.fingerprint of the install (and of every boot that saw it change): the boot service compares it
FP_FILE=$STORE/fingerprint
# 1.4.31: the mode the installer chooses when the kernel and the library fit (emulate | client): the boot service judges the
# facts again at every boot and puts the car back to it when they fit again
FIT_BASE_FILE=$STORE/fit-base

log() { echo "$1"; echo "$(date) $1" >> $LOG 2>/dev/null; true; }

# There while the package is installed (1.3.4): postinstall makes it, only a real uninstall takes it away, so the
# preinstall of an update knows it is one. The wifi_on value from before the daemon first turned it off.
INSTALLED=$STORE/installed
WIFI_ON_BEFORE=$STORE/wifi_on.before

# A real uninstall, not the old package's uninstall step inside an update: NEMESIS runs the old preuninstall with the
# new package already staged (the HMG-API rule). Never "update" when the nemesis command is an uninstall: a stage left
# by an interrupted install must not turn an uninstall into nothing.
real_uninstall() {
    case "$(cat /proc/$PPID/cmdline 2>/dev/null)" in *uninstall*) return 0 ;; esac
    grep -q '^id=jmk-wifi$' /data/local/tmp/nemesis/stage/jmk-wifi/NEMESIS.data 2>/dev/null && return 1
    return 0
}

# Another Wi-Fi app on the car (the MAP menu's and the USB installer's rules, 2.1.0): a package known to bring one,
# any other package with a Wi-Fi driver (a .ko naming 80211; Leafia and ours ship none), or a USB Wi-Fi port up that
# is not our rtl88x2bu (second port rtwlan%d; it stays loaded until the next boot after our uninstall). Prints it.
other_wifi() {
    local d k n drv p2
    for d in /data/nemesis/apps/* /data/nemesis/packages/*; do
        [ -d "$d" ] || continue
        case "${d##*/}" in
            korea.projection|niro.carplay.hotspot) echo "${d##*/}"; return 0 ;;
            jmk-*) continue ;;
        esac
        for k in "$d"/*.ko "$d"/*/*.ko "$d"/*/*/*.ko "$d"/*/*/*/*.ko "$d"/*/*/*/*/*.ko; do
            [ -f "$k" ] && grep -q 80211 "$k" 2>/dev/null && { echo "${d##*/} (${k##*/})"; return 0; }
        done
    done
    for n in /sys/class/net/*; do
        [ -e "$n/wireless" ] || [ -e "$n/phy80211" ] || continue
        case "$(readlink "$n")" in */usb*) ;; *) continue ;; esac
        drv=$(readlink "$n/device/driver" 2>/dev/null); drv=${drv##*/}
        p2=; [ -r /sys/module/88x2bu/parameters/if2name ] && read -r p2 < /sys/module/88x2bu/parameters/if2name
        [ "$drv" = rtl88x2bu ] && [ "$p2" = 'rtwlan%d' ] && continue
        p2=; [ -r /sys/module/8851bu/parameters/if2name ] && read -r p2 < /sys/module/8851bu/parameters/if2name   # 1.4.0
        [ "$drv" = rtl8851bu ] && [ "$p2" = 'rtwlan%d' ] && continue
        echo "port ${n##*/} ($drv)"; return 0
    done
    return 1
}

# The stock Wi-Fi module (Broadcom BCM89359, bcmdhd): a wlan0 that is not our dongle (while the stock Wi-Fi is on) or a
# Broadcom SDIO/PCI device (when the chip is powered). A chipless car has neither (car 2026-11-09: wlan0 -> rtl88x2bu,
# sdio bus empty). Prints what it saw; true when the module is there.
stock_module() {
    local d ven drv
    if [ -e /sys/class/net/wlan0 ]; then
        drv=$(readlink /sys/class/net/wlan0/device/driver 2>/dev/null)
        case "$drv" in
            */rtl88x2bu|*/rtl8851bu) ;;
            *) echo "wlan0 driven by '${drv##*/}'"; return 0 ;;
        esac
    fi
    for d in /sys/bus/sdio/devices/* /sys/bus/pci/devices/*; do
        [ -r "$d/vendor" ] || continue
        read -r ven < "$d/vendor"
        case "$ven" in
            0x02d0|0x14e4) echo "Broadcom device ${d##*/} ($ven)"; return 0 ;;
        esac
    done
    return 1
}

# Network ports with their drivers, SDIO/PCI devices, Wi-Fi modules and props: data from cars we have not seen
# 1.4.5 (a car with the stock Wi-Fi chip installed with its Wi-Fi off went in as a dongle car, 2026-11-19: no phone
# hotspot port, 호환성 모드 "순정 Wi-Fi가 꺼져 있음"): the chip shows only while it is powered, so when none is seen and no
# Wi-Fi driver runs, the stock Wi-Fi is turned on for up to 15 s to power it, then off again. On a head unit without the
# chip the stock driver load just fails (as NEMESIS's WiFi button does there). Not while a driver runs (a dongle car's
# hotspot, e.g. during an update): that would stop wireless AA.
# 1.4.6 (QA 2026-11-19): "a driver runs" was read from wlan.driver.status=ok, which our P2 lib never sets (it stays
# "unloading"), so every update on a dongle car turned the stock Wi-Fi on for 15 s under a running hotspot. Now read
# from the kernel: our driver loaded (88x2bu / 8851bu in /proc/modules) or any wlan0 at all means no probe.
probe_stock_module() {
    local i s
    grep -qE '^(88x2bu|8851bu) ' /proc/modules 2>/dev/null && return 1
    [ -e /sys/class/net/wlan0 ] && return 1
    [ "$(getprop wlan.driver.status)" = ok ] && return 1
    [ -x /system/bin/svc ] || return 1
    svc wifi enable >/dev/null 2>&1 || return 1
    for i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do
        sleep 1
        if s=$(stock_module); then svc wifi disable >/dev/null 2>&1; echo "$s (powered by turning the stock Wi-Fi on for the check)"; return 0; fi
    done
    svc wifi disable >/dev/null 2>&1
    return 1
}

hw_report() {
    local n d ven dev drv
    echo "product $(getprop ro.build.product), kernel $(cat /proc/sys/kernel/osrelease)"
    for n in /sys/class/net/*; do
        [ -e "$n" ] || continue
        drv=$(readlink $n/device/driver 2>/dev/null)
        echo "net ${n##*/}: ${drv##*/}"
    done
    for d in /sys/bus/sdio/devices/* /sys/bus/pci/devices/*; do
        [ -r "$d/vendor" ] || continue
        read -r ven < "$d/vendor"; dev=; [ -r "$d/device" ] && read -r dev < "$d/device"
        echo "bus ${d##*/}: $ven $dev"
    done
    grep -E '^(bcmdhd|dhd|88x2bu|8851bu|8812au|8821cu|88x2cu|8188eu) ' /proc/modules | while read -r n d rest; do echo "module $n"; done
    echo "props wlan.driver.status=$(getprop wlan.driver.status) tcc.wifi.vendor=$(getprop tcc.wifi.vendor) wifi.interface=$(getprop wifi.interface) wifi.info.channel=$(getprop wifi.info.channel)"
    # 1.4.10: which records of a previous boot's end this head unit keeps (pstore, last_kmsg, apanic), for the AX900
    # driver's panic guard (svc/jmkwifi.sh): names and sizes only
    for n in /sys/fs/pstore/* /proc/last_kmsg /proc/apanic_console /data/dontpanic/apanic_console; do
        [ -e "$n" ] && echo "boot record: $(ls -l "$n" 2>&1)"   # (no wc on this firmware; /proc sizes may show 0)
    done
    [ -d /sys/fs/pstore ] && echo "pstore dir present" || echo "no /sys/fs/pstore"
    # nl80211 (read only): the ports and what each radio allows next to its hotspot (1.3.0, stock-module client port)
    if [ -f bin/jmkiw ]; then
        chmod 0755 bin/jmkiw 2>/dev/null
        ./bin/jmkiw dev 2>&1
        ./bin/jmkiw phy 2>&1
    fi
}
md5of() { set -- $(md5 "$1" 2>/dev/null); echo "$1"; }

system_rw() {
    local dev mnt fs opts rest
    while read -r dev mnt fs opts rest; do
        [ "$mnt" = /system ] || continue
        case ",$opts," in *,rw,*) return 0 ;; esac
        return 1
    done < /proc/mounts
    return 1
}

# Replace the library by rename, so running processes keep the file they mapped; takes effect at the next boot.
# /system goes back to read-only if it was read-only before, whatever the remount command returned.
swap_lib() {
    local src=$1 tmp=/system/lib/.libhardware_legacy.so.jmk was_ro=0 r
    system_rw || was_ro=1
    [ $was_ro -eq 1 ] && /system/xbin/nemesis remount rw >/dev/null 2>&1
    rm -f $tmp
    cp "$src" $tmp && chmod 0644 $tmp && sync && cmp "$src" $tmp >/dev/null && mv $tmp $LIB
    r=$?
    rm -f $tmp 2>/dev/null
    sync
    if [ $was_ro -eq 1 ] && system_rw; then
        /system/xbin/nemesis remount ro >/dev/null 2>&1
        system_rw && log "WARNING: /system is still read-write"
    fi
    return $r
}

# the daemon, only if that pid still runs our class (the pid file survives reboots)
stop_daemon() {
    local pid
    [ -f "$DIR/daemon.pid" ] || return 0
    read -r pid < "$DIR/daemon.pid" || pid=
    case "$pid" in
        ''|*[!0-9]*) ;;
        *) grep -q jmkwifi.WifiDaemon "/proc/$pid/cmdline" 2>/dev/null && kill "$pid" 2>/dev/null ;;
    esac
    rm -f "$DIR/daemon.pid"
}

# A locked install tells the developer once per version, through the JMK MAP menu's outbox (sent when the head unit is
# online and reports are on; the menu adds the car's code, firmware and versions and takes MAC and IP addresses out):
# why it is locked and what the preinstall saw (hw_report), data for supporting that model. Nothing else.
locked_report() {
    local ver= l old= box=/data/local/tmp/jmk-map-menu/outbox detail at tmp
    while read -r l; do case "$l" in package-version=*) ver=${l#package-version=} ;; esac; done < "$PKG/NEMESIS.data"
    [ -r $STORE/locked-reported ] && read -r old < $STORE/locked-reported
    [ -n "$ver" ] && [ "$old" != "$ver" ] && [ -d $box ] || return 0
    detail=
    [ -r $LOCKED_FILE ] && read -r detail < $LOCKED_FILE
    case "$detail" in *'"'*|*'\'*) detail='(reason not printable)' ;; esac
    if [ -r $HW_FILE ]; then
        while read -r l; do
            case "$l" in *'"'*|*'\'*) continue ;; esac
            set -f; set -- $l; set +f   # tabs and runs of spaces become one space (no raw control characters in JSON)
            [ $# -gt 0 ] && detail="$detail / $*"
        done < $HW_FILE
    fi
    at=$(date +%s)000
    tmp=$box/.jmk-wifi-locked-$$.tmp
    echo "{\"kind\":\"jmk-report\",\"type\":\"install\",\"app\":\"jmk-wifi\",\"ver\":\"$ver\",\"msg\":\"jmk-wifi $ver locked (driver does not fit this model)\",\"detail\":\"$detail\",\"at\":$at}" > $tmp 2>/dev/null || { rm -f $tmp; return 0; }
    chmod 0644 $tmp
    mv $tmp $box/jmk-wifi-locked-$at.json && echo "$ver" > $STORE/locked-reported
    return 0
}

# 1.3.7: a failed install hook tells the developer, once per version and category, through the JMK MAP menu's outbox
# (sent when the head unit is online and reports are on): msg "install: <category>", one fixed file name per category.
# $1 the category (a literal of a-z, 0-9 and '-': never names or numbers), $2 one detail line (md5s, paths, package ids;
# never Wi-Fi names or passwords). The version is the running package's (./NEMESIS.data: the hooks run in its folder).
# Reported categories are kept outside $STORE (the preinstall reads whether $STORE exists).
REPORTED=/data/nemesis/jmk-wifi.reported   # "<version> <category>" per line
sh_report() {
    local cat="$1" detail="$2" ver= l box=/data/local/tmp/jmk-map-menu/outbox at tmp
    [ -d $box ] || return 0
    case "$cat" in ''|*[!a-z0-9-]*) return 0 ;; esac
    if [ -r ./NEMESIS.data ]; then
        while read -r l; do case "$l" in package-version=*) ver=${l#package-version=} ;; esac; done < ./NEMESIS.data
    fi
    case "$ver" in ''|*[!0-9.]*) return 0 ;; esac
    if [ -r $REPORTED ]; then
        while read -r l; do [ "$l" = "$ver $cat" ] && return 0; done < $REPORTED
    fi
    case "$detail" in *'"'*|*'\'*) detail='(detail not printable)' ;; esac
    set -f; set -- $detail; set +f; detail="$*"   # tabs, newlines and runs of spaces become one space
    at=$(date +%s)000
    tmp=$box/.jmk-wifi-install-$$.tmp
    echo "{\"kind\":\"jmk-report\",\"type\":\"install\",\"app\":\"jmk-wifi\",\"ver\":\"$ver\",\"msg\":\"install: $cat\",\"detail\":\"$detail\",\"at\":$at}" > $tmp 2>/dev/null || { rm -f $tmp; return 0; }
    chmod 0644 $tmp
    mv $tmp $box/jmk-wifi-install-$cat.json && echo "$ver $cat" >> $REPORTED
    return 0
}
sysinfo() { echo "system_rw $(system_rw && echo 1 || echo 0), mount $(grep ' /system ' /proc/mounts), df $(df /system 2>&1)"; }
