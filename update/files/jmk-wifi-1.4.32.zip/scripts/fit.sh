#!/system/bin/sh
# jmk-wifi 1.4.31: what our dongle driver and the stock-library patch were made for, and the check of it. Sourced by the
# hooks (scripts/common.sh: the preinstall) and by the boot service (svc/jmkwifi.sh), so both read the same facts.
# Facts read from the system, never a guess about hardware: the kernel release and its stack protector, the release the
# module itself says it was built for (vermagic), and (emulate mode) the md5 of the stock library the patch needs.
# (this head unit's mksh: single-digit fds only; no sed/head/tail/printf; toolbox grep, md5 exist)

FIT_KERNEL=3.18.24-tcc

# libhardware_legacy.so of NEEV.KOR V039 260902 and the same file with patch P2 (tools/jmk-wifi/EMULATION-PLAN.md section 5):
# at 0x42d8 (17112) wifi_load_driver's "bl is_wifi_driver_loaded" becomes "movs r0,#1; nop", so the stock Wi-Fi stack
# takes the driver as loaded and never insmods/rmmods the Broadcom module this car has no chip for.
LIB=/system/lib/libhardware_legacy.so
STOCK_MD5=f81b0eb4b392bc766e0bcc1488272e0e
PATCHED_MD5=ef847b5075e01067a071c59434a9ac44
P2_OFFSET=17112

# the paths the check reads (a test points them at files)
FIT_OSRELEASE=/proc/sys/kernel/osrelease
FIT_KALLSYMS=/proc/kallsyms
FIT_OUTBOX=/data/local/tmp/jmk-map-menu/outbox
FIT_WAIT=300   # seconds fit_report waits for the outbox
fit_fp() { getprop ro.build.fingerprint; }
fit_md5() { set -- $(md5 "$1" 2>/dev/null); echo "$1"; }
FIT_NL='
'

FIT_BASE_FILE=   # set by the caller: STORE/fit-base, the mode the installer chooses when kernel and library fit

# FIT_WHY: why the last failed check failed (one line, the words the installer has always used for the lock / no-driver file)
FIT_WHY=
# FIT_NOTE: one line per check, for driver.txt and the install log; fit_say adds to it
FIT_NOTE=
fit_say() { FIT_NOTE="$FIT_NOTE${FIT_NOTE:+$FIT_NL}$1"; }

# The kernel and the modules given as arguments. 0 = fits. Checks, one line each:
#   release   the running kernel is the one the modules are built for
#   stack     1.4.0: the same release string built without the stack protector has no __stack_chk_fail; printk tells the
#             symbol list is a real one (an unreadable list says nothing: not a failure, and FIT_STACK stays "unknown")
#   vermagic  1.4.31: each module's own "vermagic=<release> " string names the running kernel's release; a module with no
#             vermagic string is said and not judged (the other two checks decide)
# FIT_STACK = yes | no | unknown (what the symbol list showed): going back to "fits" needs yes.
FIT_STACK=unknown
fit_kernel() {
    local rel= ko
    FIT_STACK=unknown
    read -r rel < "$FIT_OSRELEASE" 2>/dev/null
    if [ "$rel" != "$FIT_KERNEL" ]; then
        FIT_WHY="kernel $rel, the driver is built for $FIT_KERNEL"
        fit_say "fit release: $rel, built for $FIT_KERNEL: NO"
        return 1
    fi
    fit_say "fit release: $rel: ok"
    if grep -q ' printk$' "$FIT_KALLSYMS" 2>/dev/null; then
        if grep -q ' __stack_chk_fail$' "$FIT_KALLSYMS" 2>/dev/null; then
            FIT_STACK=yes
        else
            FIT_STACK=no
            FIT_WHY="kernel $rel without the stack protector (no __stack_chk_fail), the driver needs it"
            fit_say "fit stack protector: no __stack_chk_fail: NO"
            return 1
        fi
    fi
    case "$FIT_STACK" in yes) fit_say "fit stack protector: ok" ;; *) fit_say "fit stack protector: symbol list not readable, not judged" ;; esac
    for ko in "$@"; do
        [ -f "$ko" ] || continue
        if ! grep -q 'vermagic=' "$ko" 2>/dev/null; then fit_say "fit vermagic ${ko##*/}: none in the file, not judged"; continue; fi
        if grep -q "vermagic=$rel " "$ko" 2>/dev/null; then fit_say "fit vermagic ${ko##*/}: $rel: ok"; continue; fi
        FIT_WHY="module ${ko##*/} is built for another kernel than $rel"
        fit_say "fit vermagic ${ko##*/}: not $rel: NO"
        return 1
    done
    return 0
}

# Emulate mode only (the dongle passes as the stock module): the stock library is the file the patch was made for, or the
# patched one. 0 = fits. FIT_LIBMD5 = the md5 read.
FIT_LIBMD5=
fit_library() {
    FIT_LIBMD5=$(fit_md5 $LIB)
    case "$FIT_LIBMD5" in
        $STOCK_MD5|$PATCHED_MD5) fit_say "fit library $FIT_LIBMD5: ok"; return 0 ;;
    esac
    FIT_WHY="$LIB is $FIT_LIBMD5, neither the NEEV.KOR 260902 stock file nor our patched one"
    fit_say "fit library $FIT_LIBMD5: NO"
    return 1
}

# "driver" = a driver is loaded here (mode emulate, or client with the dongle driver); "nodrv" = client without our driver;
# "locked" = nothing of ours runs.
fit_class() { if [ "$1" = locked ]; then echo locked; elif [ -n "$2" ]; then echo nodrv; else echo driver; fi; }

# The boot service's check (1.4.31), at every boot, before anything is loaded. Not sticky: the facts are read again every
# boot and the car is put where the installer would put it on the firmware it finds (PROCESS-FLOWS §1, §1c).
#   base       the mode the installer chooses when kernel and library fit (STORE/fit-base, written by the preinstall)
#   wanted     kernel / vermagic does not fit   -> client without our driver (no-driver), never a lock
#              emulate base, library does not fit -> locked
#              everything fits                  -> the base mode
#   from a non-fitting state back to "fits" only on positive evidence (the symbol list shows __stack_chk_fail; the library is
#   the patched file, because an unpatched stock library needs the postinstall to patch it); else it stays as it was, said
# It reads $mode and $nodrv (the files' content) and changes them and the files. $1.. the module files.
# FIT_RESULT: ok (fits, as before) | kernel | library (a driver car that no longer fits) | again (a non-fitting car fits)
#             | still (stays not fitting) | stay (fits by the facts, no proof: stays as it was)
# FIT_REPORT: "" | firmware-changed | firmware-fits-again (the report to send, none for "still" / "stay" / no change)
# FIT_FWCHANGED: the previous boot's fingerprint when it differs from now, else empty (FIT_FP_OLD: that value, or empty)
# STORE, MODE_FILE, LOCKED_FILE, NODRV_FILE, FP_FILE, FIT_BASE_FILE come from the caller.
FIT_RESULT=
FIT_REPORT=
FIT_FWCHANGED=
FIT_FP_OLD=
FIT_FP_NOW=
fit_boot() {
    local old= now base= prior want wmode wnodrv wlocked why= cur
    FIT_NOTE=; FIT_RESULT=ok; FIT_REPORT=; FIT_FWCHANGED=; FIT_LIBMD5=
    now=$(fit_fp)
    FIT_FP_NOW=$now
    [ -r "$FP_FILE" ] && read -r old < "$FP_FILE"
    FIT_FP_OLD=$old
    [ -r "$FIT_BASE_FILE" ] && read -r base _ < "$FIT_BASE_FILE"
    case "$base" in emulate|client) ;; *)
        # no record (a package copied in, not installed): locked only ever comes from the library (emulate); else the mode as it is
        if [ "$mode" = locked ]; then base=emulate; else base=${mode:-emulate}; fi
        fit_say "fit: no record of the installer's mode, taken as $base" ;;
    esac
    prior=$(fit_class "$mode" "$nodrv")
    if ! fit_kernel "$@"; then want=nodrv; wmode=client; wnodrv=$FIT_WHY
    elif [ "$base" = emulate ] && ! fit_library; then want=locked; wmode=locked; wlocked=$FIT_WHY
    else want=driver; wmode=$base
    fi
    # back to "fits": positive evidence only
    if [ "$prior" != driver ] && [ "$want" = driver ]; then
        if [ "$FIT_STACK" != yes ]; then
            why="the symbol list is not readable, the stack protector cannot be seen"
        elif [ "$base" = emulate ]; then
            cur=${FIT_LIBMD5:-$(fit_md5 $LIB)}
            [ "$cur" = "$PATCHED_MD5" ] || why="the library is the stock file, not patched (an install or update patches it)"
        fi
        if [ -n "$why" ]; then
            want=$prior; FIT_RESULT=stay
            fit_say "fit: fits by the checks above, but $why: stays as it was"
        fi
    fi
    if [ "$FIT_RESULT" != stay ]; then
        case "$prior>$want" in
            driver">"driver) FIT_RESULT=ok; fit_say "fit: ok, mode ${mode:-emulate}" ;;
            driver">"nodrv)  FIT_RESULT=kernel; FIT_REPORT=firmware-changed
                fit_say "fit: the driver does not fit this firmware ($wnodrv): not loaded; mode client without our driver, the stock Wi-Fi module only" ;;
            driver">"locked) FIT_RESULT=library; FIT_REPORT=firmware-changed
                fit_say "fit: the stock library does not fit ($wlocked): nothing loaded, locked" ;;
            nodrv">"nodrv|locked">"locked) FIT_RESULT=still
                fit_say "fit: still does not fit (${wnodrv:-$wlocked}): stays as decided" ;;
            nodrv">"locked)  FIT_RESULT=still; fit_say "fit: still does not fit, now the library ($wlocked): locked" ;;
            locked">"nodrv)  FIT_RESULT=still; fit_say "fit: still does not fit, now the kernel ($wnodrv): client without our driver" ;;
            *">"driver)      FIT_RESULT=again; FIT_REPORT=firmware-fits-again
                if [ "$prior" = locked ]; then why=locked; else why="client without our driver"; fi
                fit_say "fit: fits again: mode $wmode as the installer chooses (was $why)"; why= ;;
        esac
        case "$want" in
            nodrv)  [ "$mode" = client ] && [ "$nodrv" = "$wnodrv" ] || { echo client > "$MODE_FILE"; echo "$wnodrv" > "$NODRV_FILE"; rm -f "$LOCKED_FILE"; }
                    mode=client; nodrv=$wnodrv ;;
            locked) cur=; [ -r "$LOCKED_FILE" ] && read -r cur < "$LOCKED_FILE"
                    [ "$mode" = locked ] && [ "$cur" = "$wlocked" ] || { echo locked > "$MODE_FILE"; echo "$wlocked" > "$LOCKED_FILE"; rm -f "$NODRV_FILE"; }
                    mode=locked; nodrv= ;;
            driver) if [ "$prior" != driver ]; then echo "$wmode" > "$MODE_FILE"; rm -f "$NODRV_FILE" "$LOCKED_FILE"; mode=$wmode; nodrv=; fi ;;
        esac
    fi
    if [ -z "$now" ]; then
        fit_say "fit fingerprint: not readable"
    elif [ -z "$old" ]; then
        fit_say "fit fingerprint: no record of the previous boot's, recorded now"
    elif [ "$old" = "$now" ]; then
        fit_say "fit fingerprint: same as at the previous boot"
    else
        FIT_FWCHANGED=$old
        fit_say "firmware changed: $old -> $now"
        # a fingerprint change with the car staying as it was (fits, or still not fitting) is reported only when it fits: a car
        # that still does not fit already said so
        [ -z "$FIT_REPORT" ] && [ "$FIT_RESULT" = ok ] && FIT_REPORT=firmware-changed
    fi
    if [ -n "$now" ] && [ "$old" != "$now" ]; then echo "$now" > "$FP_FILE" || fit_say "fit fingerprint: could not be recorded"; fi
    return 0
}

# One report to the developer through the MAP menu's outbox (sent when the head unit is online and reports are on): msg
# "driver: <$2>" (firmware-changed | firmware-fits-again), the kernel, the verdict, the previous and the new fingerprint and
# the check lines. Once per (category, new fingerprint, verdict). The outbox is made by the MAP menu's daemon after this
# service started, so this waits for it (FIT_WAIT seconds, 5 min): the caller runs it in the background. $1 the package version.
fit_report() {
    local ver=$1 cat=$2 key box=$FIT_OUTBOX old= detail at tmp l n=0
    case "$cat" in firmware-changed|firmware-fits-again) ;; *) return 0 ;; esac
    key="$cat $FIT_FP_NOW $FIT_RESULT"
    [ -r "$STORE/fit-reported" ] && read -r old < "$STORE/fit-reported"
    [ "$old" = "$key" ] && return 0
    while [ ! -d "$box" ] && [ $n -lt $FIT_WAIT ]; do sleep 1; n=$((n + 1)); done
    [ -d "$box" ] || return 0
    detail="verdict $FIT_RESULT, kernel $(cat "$FIT_OSRELEASE" 2>/dev/null), from ${FIT_FP_OLD:-?} to $FIT_FP_NOW;"
    set -f
    IFS="$FIT_NL"
    for l in $FIT_NOTE; do detail="$detail $l;"; done
    unset IFS
    set +f
    case "$detail" in *'"'*|*'\'*) detail='(detail not printable)' ;; esac
    set -f; set -- $detail; set +f; detail="$*"
    at=$(date +%s)000
    tmp=$box/.jmk-wifi-fit-$$.tmp
    echo "{\"kind\":\"jmk-report\",\"type\":\"driver\",\"app\":\"jmk-wifi\",\"ver\":\"$ver\",\"msg\":\"driver: $cat\",\"detail\":\"$detail\",\"at\":$at}" > $tmp 2>/dev/null || { rm -f $tmp; return 0; }
    chmod 0644 $tmp
    mv $tmp $box/jmk-wifi-driver-$cat.json && echo "$key" > "$STORE/fit-reported"
    return 0
}
