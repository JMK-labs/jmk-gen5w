#!/system/bin/sh
# Refuses to install next to another USB Wi-Fi package, and picks the mode: "locked" on a kernel or library its driver
# and patch were not made for (1.3.6: installs, does nothing), "client" on a car with the stock Wi-Fi module (the dongle only joins the phone hotspot, nothing stock is
# patched), "emulate" on a chipless car (the dongle passes as the stock module).
. ./scripts/common.sh
log "preinstall jmk-wifi"
# 1.4.11 (cars 2026-11-19/20: DT5ONEIZ, 4OUZISNW, 4FIXBWXL ...): this refusal ran on updates too, after the old
# version's preuninstall had already stopped the daemon and put the stock library back, so an update left the car
# without its Wi-Fi (and NEMESIS still counting the package as installed: the menu's next try "already installed").
# Now: a package counts only with its NEMESIS.data (a directory left behind is not one), and only a first install is
# refused; an update goes on and says so in a report.
first=1
{ [ -d $STORE ] || [ -d /data/nemesis/apps/jmk-wifi ] || [ -d /data/nemesis/packages/jmk-wifi ]; } && first=
for old in jmk.usbwifi usbwifi.hotspot; do
    if [ -f /data/nemesis/apps/$old/NEMESIS.data ] || [ -f /data/nemesis/packages/$old/NEMESIS.data ]; then
        if [ -n "$first" ]; then
            log "FAIL: uninstall $old first (it runs its own driver and hotspot). Its saved networks are imported."
            sh_report preinstall-old-usbwifi "$old is installed"
            exit 1
        fi
        log "note: $old is installed next to this update; it runs its own driver and hotspot, uninstall it (다른 USB Wi-Fi 패키지 $old 를 지워 주세요)"
        sh_report preinstall-old-usbwifi-update "$old is installed (an update: not refused)"
    fi
done
# the JMK MAP menu is its screen (networks, hotspot) and its updater: it goes in first (the USB bundle's order). Only
# on a first install: an update has already run the old preuninstall (daemon stopped, stock library back), so a
# refusal here would leave the car without its Wi-Fi. $STORE (saved networks, mode) outlives an uninstall.
if [ ! -d $STORE ] && [ ! -d /data/nemesis/apps/jmk-map-menu ] && [ ! -d /data/nemesis/packages/jmk-map-menu ]; then
    log "FAIL: JMK 맵핑퀵메뉴(jmk-map-menu)를 먼저 설치하세요 (install jmk-map-menu first)"
    sh_report preinstall-no-map "jmk-map-menu is not installed"
    exit 1
fi
# another Wi-Fi app (1.3.4): both would drive the same hotspot. Only on a first install (an update has run the old
# preuninstall already, a refusal now would leave the car without its Wi-Fi); the MAP menu and the USB stick skip us
# there already, this covers a zip installed by hand.
if [ ! -f $INSTALLED ] && [ ! -d /data/nemesis/apps/jmk-wifi ] && [ ! -d /data/nemesis/packages/jmk-wifi ] && other=$(other_wifi); then
    log "FAIL: another Wi-Fi app is installed: $other. Keep it and skip the JMK Wi-Fi Driver, or uninstall it first (다른 Wi-Fi 앱이 설치되어 있습니다)"
    sh_report preinstall-other-wifi "$other"
    exit 1
fi
# Another model (1.3.6): it installs, locked where its driver or library does not fit. Locked = the driver is never
# loaded (a module for another kernel could hang or reboot the head unit), nothing stock is patched, the daemon does not
# run; the MAP menu shows "이 차종 미지원". The install used to be refused here.
locked=
# 1.4.31: the checks (kernel release, 1.4.0's stack protector rule, the modules' own vermagic) are scripts/fit.sh's, the same
# the boot service runs at every boot; one line per check goes into the install log
if ! fit_kernel ./bin/88x2bu.ko ./bin/8851bu.ko; then locked=$FIT_WHY; fi
set -f; IFS="$FIT_NL"; for l in $FIT_NOTE; do log "$l"; done; unset IFS; set +f   # (no here-document: this mksh needs a temp file for it)

# The module shows only while the stock Wi-Fi is on (or its chip is powered), so once seen, client mode stays; 1.4.5:
# when none shows, probe_stock_module powers it for the check (common.sh).
# 1.4.10 (a CN7HEV owner 2026-11-20; the reports: CN7 / CN7HEV, DL3, DN8, DE HEV... all on a kernel without the stack
# protector, most with the stock Broadcom chip): an unfit kernel locked the whole package, also on a car whose stock
# chip makes the car hotspot by itself. Now the kernel decides only our dongle driver: with the stock chip seen, the
# car installs as a stock-chip car (기본 / 호환성 work, nothing of ours goes into the kernel, no-driver says why).
mode=
nodrv=
# 1.4.26 (the owner, K5 hybrid 2026-11-23: cars with the stock chip were locked because the chip, powered only while in
# use, was not seen at install): a kernel our driver does not fit no longer locks. Such a car installs as a stock-chip
# car without our driver (client + no-driver): the daemon runs, 차 핫스팟 켜기 starts the stock hotspot and so wakes the
# chip; nothing of ours goes into the kernel, nothing stock is patched. The chip is not looked for (no probe, no wait).
if [ -n "$locked" ]; then
    mode=client
    nodrv="$locked" && locked=
    seen=$(stock_module) || seen="stock chip not powered now (not looked for: 켜기 wakes it)"
elif seen=$(stock_module) || seen=$(probe_stock_module); then
    mode=client
else
    seen="no stock Wi-Fi module seen"
    [ -f $MODE_FILE ] && read -r mode < $MODE_FILE
    [ "$mode" = client ] && seen="$seen (client mode kept from an earlier install)" || mode=emulate
fi
base=$mode   # 1.4.31: what the installer chooses when the kernel and the library fit (an unfit kernel: client, the chip was not looked at)
if [ $mode = emulate ]; then
    FIT_NOTE=
    if fit_library; then log "libhardware_legacy.so ${FIT_NOTE#fit library }"; else mode=locked; locked=$FIT_WHY; log "$FIT_NOTE"; fi
fi
mkdir -p $STORE && chmod 0700 $STORE
echo $mode > $MODE_FILE
# 1.4.31: the firmware this install was made for; the boot service says when it changed
fit_fp > $FP_FILE
echo $base > $FIT_BASE_FILE
if [ -n "$locked" ]; then echo "$locked" > $LOCKED_FILE; else rm -f $LOCKED_FILE; fi
if [ -n "$nodrv" ]; then echo "$nodrv" > $NODRV_FILE; else rm -f $NODRV_FILE; fi
{ echo "$(date) jmk-wifi preinstall: mode $mode ($seen)"; hw_report; } > $HW_FILE 2>&1
chmod 0644 $HW_FILE
if [ $mode = locked ]; then
    log "LOCKED on this model: $locked ($seen). Installs, but the driver is not loaded and nothing stock is patched (이 차종 미지원)."
elif [ -n "$nodrv" ]; then
    log "mode client without our driver: $seen; $nodrv. The stock Wi-Fi module keeps the car hotspot (기본) and joins the phone hotspot (호환성); a USB dongle is not used on this kernel."
elif [ $mode = client ]; then
    log "mode client: $seen. The stock Wi-Fi module keeps the hotspot; the dongle only joins the phone hotspot (internet, updates, wireless adb). Nothing stock is patched."
else
    log "mode emulate: $seen. The dongle passes as the stock Wi-Fi module."
fi
exit 0
