#!/system/bin/sh
# jmk-autoplay, shared by the hooks. NEMESIS runs them as root with the package folder as the current directory.
# (this head unit's mksh: single-digit fds only; no sed/head/tail/printf; toolbox grep, md5, cmp exist)
export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
# a hook started over adb runs in adbd's session: a pulled cable or a host timeout must not stop it halfway
trap '' HUP INT PIPE
# R: a sandbox root for test/scripts-test.sh on the Mac only. Empty on the car, where every path is the real one.
R=${JMK_AUTOPLAY_TEST_ROOT:-}
PKG=$R/data/nemesis/apps/jmk-autoplay
[ -d "$PKG" ] || PKG=$R/data/nemesis/packages/jmk-autoplay
DIR=$R/data/local/tmp/jmk-autoplay        # status and requests for the JMK MAP menu
STORE=$R/data/nemesis/jmk-autoplay        # our state (root only); outlives an uninstall
BACKUP=$R/data/nemesis/backups/jmk-autoplay   # stock copies of every file we change, restored by the uninstall
LOG=$R/data/nemesis/jmk-autoplay.log
INSTALLED=$STORE/installed              # there while installed: an update's preinstall knows it is one
REPORTED=$R/data/nemesis/jmk-autoplay.reported

log() { echo "$1"; echo "$(date) $1" >> $LOG 2>/dev/null; true; }

# A real uninstall, not the old package's uninstall step inside an update (NEMESIS runs the old preuninstall with the
# new package already staged, from its "nemesis install --update" process). 0.3.4 (QA 2026-11-19 #5), three ways:
# the parent says "uninstall": a real uninstall, whatever is staged (a stage left by an interrupted install never
# turns it into nothing); it says "install": an update when our package is staged; it names neither (NEMESIS
# Manager's own process, an unreadable cmdline): the staged package decides, as before.
parent_cmdline() { cat /proc/$PPID/cmdline 2>/dev/null; }
real_uninstall() {
    case "$(parent_cmdline)" in *uninstall*) return 0 ;; esac
    grep -q '^id=jmk-autoplay$' $R/data/local/tmp/nemesis/stage/jmk-autoplay/NEMESIS.data 2>/dev/null && return 1
    return 0
}

# size_kb <file>: its size in KB (toolbox ls -s prints "<KB> <name>"), 0 when absent
size_kb() { local n; set -- $(ls -s "$1" 2>/dev/null); n=$1; case "$n" in ''|*[!0-9]*) n=0 ;; esac; echo $n; }
# free_kb <dir>: KB free on its filesystem, empty when unknown. Toolbox df's last line is "<fs> <size> <used> <free>
# <blksize>" with sizes like 412.0M; busybox df has KB in the same (4th) column.
free_kb() {
    local out last v i f IFS
    out=$(df "$1" 2>/dev/null) || return 0
    IFS='
'
    set -f; set -- $out; set +f
    [ $# -ge 2 ] || return 0
    eval "last=\${$#}"
    IFS=' 	'
    set -f; set -- $last; set +f
    v=$4
    case "$v" in
        *K|*M|*G) ;;
        ''|*[!0-9]*) return 0 ;;
        *) echo "$v"; return 0 ;;
    esac
    i=${v%?}; f=0
    case "$i" in *.*) f=${i#*.}; i=${i%%.*}; f=${f%"${f#?}"} ;; esac
    case "$i$f" in ''|*[!0-9]*) return 0 ;; esac
    case "$v" in
        *K) echo $i ;;
        *M) echo $((i * 1024 + f * 1024 / 10)) ;;
        *G) echo $((i * 1048576 + f * 104857)) ;;
    esac
}

# 0.3.4 (QA #15): a log over 256 KB becomes <log>.old (one generation kept), so no log of ours only grows
log_cap() {
    local f
    for f in "$@"; do [ -f "$f" ] && [ "$(size_kb "$f")" -gt 256 ] && mv "$f" "$f.old" 2>/dev/null; done
    true
}

# Another wireless CarPlay / Android Auto package (the MAP menu's rule, MapDaemon.projectionId): two of them would
# change the same stock files and features. Leafia (wireless.cp.aa.<fw>), Evergreen (wireless.carplay.aa), 단풍
# (danpung, danpung.update), Korea Projection, wireless.projection, projection.tbt, enhanced.projection, and an
# HMG-API wireless mod. Prints the first one found.
# 0.3.1: the installed MAP menu's package-version ("" when not found)
map_version() {
    local f k v
    for f in $R/data/nemesis/apps/jmk-map-menu/NEMESIS.data $R/data/nemesis/packages/jmk-map-menu/NEMESIS.data; do
        [ -f "$f" ] || continue
        while IFS== read -r k v; do [ "$k" = package-version ] && { echo "$v"; return 0; }; done < "$f"
    done
    echo ""
}

# version_at_least <x.y.z> <major> <minor> <patch>: true when x.y.z >= the given one (numbers only)
version_at_least() {
    local a b c
    IFS=. read -r a b c <<VEOF
$1
VEOF
    a=${a:-0}; b=${b:-0}; c=${c:-0}
    case "$a$b$c" in *[!0-9]*) return 1 ;; esac
    [ $a -gt $2 ] && return 0; [ $a -lt $2 ] && return 1
    [ $b -gt $3 ] && return 0; [ $b -lt $3 ] && return 1
    [ $c -ge $4 ]
}

other_projection() {
    local d id
    for d in $R/data/nemesis/apps/* $R/data/nemesis/packages/*; do
        [ -d "$d" ] || continue
        id=${d##*/}
        case "$id" in
            jmk-*|jmk.*) continue ;;
            wireless.*|danpung*|aa.usbwifi|*carplay*|*projection*|*leafia*|*evergreen*|*androidauto*) echo "$id"; return 0 ;;
        esac
    done
    for d in $R/data/hmgapi/mods/*; do
        [ -d "$d" ] || continue
        case "${d##*/}" in *wireless*|*carplay*|*projection*) echo "HMG-API mod ${d##*/}"; return 0 ;; esac
    done
    return 1
}

# The HUD · 계기판 길안내 add-on (jmk-autoplay-hud, 0.3.0): prints its NEMESIS folder while it is installed.
hud_addon() {
    local d
    for d in $R/data/nemesis/apps/jmk-autoplay-hud $R/data/nemesis/packages/jmk-autoplay-hud; do
        [ -d "$d" ] && { echo "$d"; return 0; }
    done
    return 1
}

stop_daemon() {
    local pid
    [ -f "$DIR/daemon.pid" ] || return 0
    read -r pid < "$DIR/daemon.pid" || pid=
    case "$pid" in
        ''|*[!0-9]*) ;;
        *) grep -q jmkautoplay.AutoPlayDaemon "/proc/$pid/cmdline" 2>/dev/null && kill "$pid" 2>/dev/null ;;
    esac
    rm -f "$DIR/daemon.pid"
}

# One install report per version and category, through the JMK MAP menu's outbox (sent when the head unit is online
# and reports are on; the menu adds the car's code, firmware and versions and takes MAC and IP addresses out).
sh_report() {
    local cat="$1" detail="$2" ver= l box=$R/data/local/tmp/jmk-map-menu/outbox at tmp
    [ -d $box ] || return 0
    case "$cat" in ''|*[!a-z0-9-]*) return 0 ;; esac
    if [ -r ./NEMESIS.data ]; then
        while read -r l; do case "$l" in package-version=*) ver=${l#package-version=} ;; esac; done < ./NEMESIS.data
    fi
    case "$ver" in ''|*[!0-9.]*) return 0 ;; esac
    if [ -r $REPORTED ]; then
        while read -r l; do [ "$l" = "$ver $cat" ] && return 0; done < $REPORTED
    fi
    case "$detail" in *'"'*|*'\'*) detail='(detail not printable)' ;; esac
    set -f; set -- $detail; set +f; detail="$*"
    at=$(date +%s)000
    tmp=$box/.jmk-autoplay-install-$$.tmp
    echo "{\"kind\":\"jmk-report\",\"type\":\"install\",\"app\":\"jmk-autoplay\",\"ver\":\"$ver\",\"msg\":\"install: $cat\",\"detail\":\"$detail\",\"at\":$at}" > $tmp 2>/dev/null || { rm -f $tmp; return 0; }
    chmod 0644 $tmp
    mv $tmp $box/jmk-autoplay-install-$cat.json && echo "$ver $cat" >> $REPORTED
    return 0
}

# ---------------------------------------------------------------- 0.2.0: the stock wireless features
# The KOR firmware lists the wireless CarPlay, wireless Android Auto and hotspot permission files with "-" in
# <ro.mobis.targetdir>/featurexml.cfg, so PackageManager and com.hkmc.Feature drop them (read once per process: a reboot
# applies a change). We comment those three lines ("#-…") and add the two feature files the firmware does not ship.
# Every change is recorded, and a real uninstall puts back exactly what we changed (tools/jmk-autoplay/RESEARCH-core.md §1, §2).
PERM=/system/etc/permissions      # as the cfg names it (files on disk: $R$PERM)
F_AA=com.hkmc.software.connectivity.androidauto_wireless
F_CP=com.hkmc.software.connectivity.carplay_wireless
F_HS=com.hkmc.software.wifihotspot
COMMENTED=$STORE/commented        # the cfg lines we commented, as they were ("-/system/etc/permissions/….xml")
ADDED=$STORE/added                # the permission files we added (as /system/etc/permissions/….xml)
PROPS_BEFORE=$STORE/props.before  # "name=value" before we set them (first install only)
LOCKED=$STORE/locked              # why nothing was changed (another model, no cfg)
PROPS="persist.sys.iap2.wifi persist.iap2.iden.wireless"   # iAP2 asks the iPhone for Wi-Fi (the CarPlay feature alone does not)

md5of() { set -- $(md5 "$1" 2>/dev/null); echo "$1"; }

system_rw() {
    local dev mnt fs opts rest
    while read -r dev mnt fs opts rest; do
        [ "$mnt" = /system ] || continue
        case ",$opts," in *,rw,*) return 0 ;; esac
        return 1
    done < /proc/mounts
    return 1
}

# /system read-write for a moment if it was not (after boot it is rw by design: never leave it ro when it was rw)
WAS_RO=0
rw_begin() { WAS_RO=0; system_rw || { WAS_RO=1; /system/xbin/nemesis remount rw >/dev/null 2>&1; }; system_rw; }
rw_end() { sync; [ $WAS_RO -eq 1 ] && system_rw && /system/xbin/nemesis remount ro >/dev/null 2>&1; true; }

cfg_path() {
    local d
    d=$(getprop ro.mobis.targetdir)
    [ -n "$d" ] && [ -f "$R$d/featurexml.cfg" ] && echo "$R$d/featurexml.cfg"
}

# Our model (KR Ioniq 5) always; another one only once the signed update list names "projection" for it (the MAP
# menu writes car-ok, like Active Ambient's gate).
fits() {
    local p ok
    p=$(getprop ro.build.product)
    [ -n "$p" ] || return 1
    case "$p" in NEEV.KOR.*) return 0 ;; esac
    # 0.3.6 (10 cars on 2026-11-20 alone): a fresh install from the USB stick comes before the menu's first update
    # check, so there is no car-ok yet and the car stayed locked until a check and a second reboot ("폰 프로젝션이 안
    # 된다"). With no list checked on this car yet the published policy applies: every model ("*": projection since
    # 2026-11-17). A verified list that later leaves this car out puts the stock features back at the next boot (svc).
    [ -f $R/data/nemesis/jmk-updates/car-ok ] || { FIT_DEFAULT=1; return 0; }
    ok=$(cat $R/data/nemesis/jmk-updates/car-ok 2>/dev/null)
    case ",$ok," in *,projection,*) return 0 ;; esac
    return 1
}

# Is $1 a whole line of file $2 (no grep -x / -F on this firmware's toolbox)?
has_line() {
    local l
    [ -f "$2" ] || return 1
    while IFS= read -r l || [ -n "$l" ]; do [ "$l" = "$1" ] && return 0; done < "$2"
    return 1
}

# Rewrite the cfg through a copy: "-<file>" -> "#-<file>" for our three ($1 = on), or back for the lines in $COMMENTED
# ($1 = off). The copy sits next to the cfg (same filesystem), gets the stock owner and mode, and replaces it by rename:
# the cfg is never half written (a failed write leaves the old one).
# 0.3.4 (QA 2026-11-19 #4): a full /system could stop the copy part-way and a non-empty, truncated copy replaced the
# cfg. Now: room for the copy and its check first (df), every write checked, and before the rename the copy must undo
# into the very cfg it came from (only the changed lines put back, then the same md5: same lines, same bytes). A line
# without its newline at the end stays so. COMMENTED gets the lines only once the new cfg is in place.
cfg_rewrite() {
    local want=$1 cfg tmp line e out n=0 i=0 chg=" " rec= free need sum
    cfg=$(cfg_path) || return 1
    tmp=$cfg.jmk
    rm -f $tmp $tmp.u
    need=$(( $(size_kb $cfg) * 2 + 64 ))
    free=$(free_kb ${cfg%/*})
    if [ -n "$free" ] && [ "$free" -lt $need ]; then
        log "FAIL: ${cfg%/*} has $free KB free, $need KB needed for the featurexml.cfg copy: left as it was"
        return 1
    fi
    : > $tmp || return 1
    while :; do
        if IFS= read -r line; then e=; elif [ -n "$line" ]; then e=n; else break; fi
        i=$((i+1)); out=$line
        if [ $want = on ]; then
            case "$line" in
                "-$PERM/$F_AA.xml"|"-$PERM/$F_CP.xml"|"-$PERM/$F_HS.xml")
                    out="#$line"; chg="$chg$i "; n=$((n+1)); has_line "$line" $COMMENTED || rec="$rec $line" ;;
            esac
        else
            case "$line" in
                "#-"*) has_line "${line#\#}" $COMMENTED && { out=${line#\#}; chg="$chg$i "; n=$((n+1)); } ;;
            esac
        fi
        print -r$e -- "$out" >> $tmp || { rm -f $tmp; log "FAIL: featurexml.cfg copy not written (line $i), left as it was"; return 1; }
    done < $cfg
    [ $n -eq 0 ] && { rm -f $tmp; return 0; }
    # the check: the copy with only our changed lines undone must be the cfg, byte for byte
    : > $tmp.u || { rm -f $tmp $tmp.u; return 1; }
    i=0
    while :; do
        if IFS= read -r line; then e=; elif [ -n "$line" ]; then e=n; else break; fi
        i=$((i+1))
        case "$chg" in *" $i "*) if [ $want = on ]; then line=${line#\#}; else line="#$line"; fi ;; esac
        print -r$e -- "$line" >> $tmp.u || { rm -f $tmp $tmp.u; log "FAIL: featurexml.cfg check copy not written, left as it was"; return 1; }
    done < $tmp
    sum=$(md5of $cfg)
    if [ -z "$sum" ] || [ "$(md5of $tmp.u)" != "$sum" ]; then
        rm -f $tmp $tmp.u; log "FAIL: featurexml.cfg copy does not undo into the cfg (incomplete write?), left as it was"; return 1
    fi
    rm -f $tmp.u
    sum=$(md5of $tmp)
    chmod 0644 $tmp; chown 0.0 $tmp 2>/dev/null
    sync
    if ! mv $tmp $cfg; then rm -f $tmp; log "FAIL: featurexml.cfg not replaced"; return 1; fi
    sync
    [ "$(md5of $cfg)" = "$sum" ] || { log "FAIL: featurexml.cfg is not the copy after the rename"; return 1; }
    for line in $rec; do print -r -- "$line" >> $COMMENTED || { log "FAIL: could not record $line in $COMMENTED"; return 1; }; done
    log "featurexml.cfg: $n line(s) $( [ $want = on ] && echo commented || echo restored ), now $sum"
    return 0
}

FEATURE_HEAD='<?xml version="1.0" encoding="utf-8"?>'
feature_body() { echo "<permissions><feature name=\"$1\" /></permissions>"; }
feature_file() {   # $1 = the feature name: a stock-format permissions file with that one feature
    local f=$PERM/$1.xml
    [ -f $R$f ] && return 0
    echo "$FEATURE_HEAD" > $R$f && feature_body "$1" >> $R$f && chmod 0644 $R$f || { rm -f $R$f; return 1; }
    has_line $f $ADDED || echo $f >> $ADDED
}
# ours_feature <file as the cfg names it>: the file is still the one feature_file wrote
ours_feature() {
    local n=${1##*/}
    n=${n%.xml}
    has_line "$FEATURE_HEAD" $R$1 && has_line "$(feature_body $n)" $R$1
}

# 0.3.4 (QA #8): CFG_STATE = what the boot finds against our record, from the files: "ok" (every recorded line commented, every
# added file there), "reapply" (a recorded line is "-" again or an added file is gone: a firmware update put the stock
# ones back), "nocfg" (the firmware has no cfg any more). Recorded lines the cfg no longer has in either form are
# dropped from the record (CFG_GONE names them): nothing of ours is left to put back there.
cfg_check() {
    local cfg l f st=ok keep= line found
    CFG_GONE=
    cfg=$(cfg_path) || { CFG_STATE=nocfg; return 0; }
    if [ -f $COMMENTED ]; then
        while IFS= read -r l || [ -n "$l" ]; do
            [ -n "$l" ] || continue
            found=
            while IFS= read -r line || [ -n "$line" ]; do
                case "$line" in "#$l") found=c; break ;; "$l") found=d ;; esac
            done < $cfg
            case "$found" in
                c) keep="$keep $l" ;;
                d) keep="$keep $l"; st=reapply ;;
                *) CFG_GONE="$CFG_GONE $l" ;;
            esac
        done < $COMMENTED
        if [ -n "$CFG_GONE" ]; then
            : > $COMMENTED.tmp && for l in $keep; do print -r -- "$l" >> $COMMENTED.tmp; done && mv $COMMENTED.tmp $COMMENTED
            [ -s $COMMENTED ] || rm -f $COMMENTED
        fi
    fi
    if [ -f $ADDED ]; then
        while read -r f || [ -n "$f" ]; do
            case "$f" in $PERM/*.xml) [ -f "$R$f" ] || st=reapply ;; esac
        done < $ADDED
    fi
    CFG_STATE=$st
}

# The properties' values before us, once: an update keeps the first install's.
props_save() {
    local p
    [ -f $PROPS_BEFORE ] && return 0
    for p in $PROPS; do echo "$p=$(getprop $p)" >> $PROPS_BEFORE; done
}

# 0.3.2: the three wireless lines as this firmware's cfg has them, and whether their permission files exist, for the
# locked report of another model: "aa=-,f0 cp=-,f0 hs=on,f1" (- listed with "-" (dropped), # commented, on listed,
# none not listed; f1/f0 the file is there or not). With the same lines as ours, that model can be opened as it is.
cfg_wireless() {
    local cfg n f s line out=
    cfg=$(cfg_path) || { echo "cfg none ($(getprop ro.mobis.targetdir))"; return 0; }
    for n in aa:$F_AA cp:$F_CP hs:$F_HS; do
        f=$PERM/${n#*:}.xml; s=none
        while IFS= read -r line || [ -n "$line" ]; do
            case "$line" in "-$f") s=- ;; "#-$f") s='#' ;; "$f") s=on ;; esac
        done < $cfg
        if [ -f $R$f ]; then s="$s,f1"; else s="$s,f0"; fi
        out="$out ${n%%:*}=$s"
    done
    echo "cfg$out"
}

# The uninstall: every property back to its recorded value (empty when it had none).
props_restore() {
    local p v
    [ -f $PROPS_BEFORE ] || return 0
    while IFS='=' read -r p v; do [ -n "$p" ] && setprop "$p" "$v"; done < $PROPS_BEFORE
}

# 0.3.5 / 0.1.9 (the owner 2026-11-19): the tamper lock the JMK MAP menu's daemon decides (its Integrity:
# /data/nemesis/jmk-updates/integrity, lock=0|1, text=). Sets ILOCK (1 or "") and ITEXT. Never this package's own call.
integrity_read() {
    ILOCK=; ITEXT=
    local k v
    [ -f "$R/data/nemesis/jmk-updates/integrity" ] || return 0
    while IFS='=' read -r k v || [ -n "$k" ]; do
        case "$k" in lock) [ "$v" = 1 ] && ILOCK=1 ;; text) ITEXT=$v ;; esac
    done < "$R/data/nemesis/jmk-updates/integrity"
}

# What we changed in /system back to stock (the uninstall's part, 0.3.5: also the tamper lock's, svc/autoplay.sh).
# Returns 1 when something could not be put back (the records stay).
put_back() {
    local ok=1 f left
    if [ -f $COMMENTED ] || [ -f $ADDED ]; then
        if rw_begin; then
            if [ -f $COMMENTED ] && ! cfg_rewrite off; then
                # no cfg any more (another firmware): nothing of ours is left in it to put back
                if cfg_path >/dev/null; then ok=0; log "FAIL: featurexml.cfg not restored"; else log "no featurexml.cfg any more: nothing to put back there"; fi
            fi
            if [ -f $ADDED ]; then
                left=
                while read -r f || [ -n "$f" ]; do
                    case "$f" in $PERM/*.xml) ;; *) continue ;; esac
                    [ -e "$R$f" ] || continue
                    if ! ours_feature "$f"; then log "WARNING: $f changed since we added it: left alone"; continue; fi
                    rm -f "$R$f"
                    [ -e "$R$f" ] && { left="$left $f"; ok=0; }
                done < $ADDED
                [ -n "$left" ] && log "FAIL: could not remove$left"
            fi
            rw_end
        else
            ok=0
            log "FAIL: /system read-only, nothing put back"
            sh_report preuninstall-system-ro "$(grep ' /system ' /proc/mounts)"
            rw_end
        fi
    fi
    [ $ok -eq 1 ]
}
