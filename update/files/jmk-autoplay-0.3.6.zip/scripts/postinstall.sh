#!/system/bin/sh
# Turns the stock wireless CarPlay / Android Auto features on (a reboot applies them). Another model that the update
# list does not name yet, or a firmware without the cfg: installed, nothing changed ("locked").
. ./scripts/common.sh
log_cap $LOG
log "postinstall jmk-autoplay"
mkdir -p $STORE && chmod 0700 $STORE
: > $INSTALLED
rm -f $LOCKED
if ! fits; then
    echo "model $(getprop ro.build.product)" > $LOCKED
    log "locked: $(getprop ro.build.product) is not checked yet, nothing changed"
    sh_report postinstall-locked "$(getprop ro.build.product); $(cfg_wireless); stepofspec $(getprop ro.product.opt.stepofspec)"
    exit 0
fi
cfg=$(cfg_path) || {
    echo "no featurexml.cfg in $(getprop ro.mobis.targetdir)" > $LOCKED
    log "locked: no featurexml.cfg ($(getprop ro.mobis.targetdir)), nothing changed"
    sh_report postinstall-no-cfg "$(getprop ro.mobis.targetdir)"
    exit 0
}
# 0.3.4 (QA #15): no whole-cfg copy any more (never used: the uninstall undoes our recorded lines; stale after a
# firmware update); the one an older version kept goes
rm -f $BACKUP/featurexml.cfg
log "featurexml.cfg before: $(md5of $cfg)"
props_save
if ! rw_begin; then
    log "FAIL: /system is read-only, nothing changed"
    sh_report postinstall-system-ro "$(grep ' /system ' /proc/mounts)"
    rw_end; exit 1
fi
ok=1
cfg_rewrite on || ok=0
feature_file $F_AA || ok=0
feature_file $F_CP || ok=0
rw_end
for p in $PROPS; do setprop $p t; done
[ -n "$FIT_DEFAULT" ] && log "no update list checked on this car yet: the published policy (every model) applies; a list that leaves it out puts the stock features back"
if [ $ok -eq 1 ]; then
    log "wireless CarPlay / Android Auto features on (reboot to apply); props: $(getprop persist.sys.iap2.wifi)/$(getprop persist.iap2.iden.wireless)"
else
    log "WARNING: a change failed (see above); the uninstall restores what was done"
    sh_report postinstall-apply "cfg $(md5of $cfg), added $(cat $ADDED 2>/dev/null)"
fi
[ "$(getprop persist.service.adb.tcp.enable)" = 1 ] && log "note: persist.service.adb.tcp.enable=1 puts eth0 on 192.168.0.123 (inside the hotspot): phones may get no address"
exit 0
