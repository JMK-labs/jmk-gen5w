#!/system/bin/sh
# NEMESIS service (root): the JMK Wireless AutoPlay daemon (jmkautoplay.AutoPlayDaemon). It writes the status the
# JMK MAP menu shows (features, the stock hotspot, phones on it) into $DIR/status.
# (mksh: single-digit fds only; no sed/head/tail on this firmware)
export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
PKG=${JMK_AUTOPLAY_PKG:-/data/nemesis/apps/jmk-autoplay}
[ -d "$PKG" ] || PKG=/data/nemesis/packages/jmk-autoplay
# 0.3.4: the hooks' functions and paths (DIR, STORE, the records; R is empty on the car)
. "$PKG/scripts/common.sh"
[ -n "$JMK_AUTOPLAY_PKG" ] && PKG=$JMK_AUTOPLAY_PKG

# The MAP menu (an app, uid of its own) reads $DIR; /data/local/tmp is 0771 shell:shell after boot, and root without
# capabilities can't create in it, so ask the shell user then (that dir then stays the shell's, 0777).
if mkdir -p "$DIR" 2>/dev/null; then
    chmod 0755 "$DIR"
else
    /system/xbin/nemesis root 2000 -c "mkdir -p $DIR; chmod 0777 $DIR" </dev/null >/dev/null 2>&1
fi
mkdir -p "$DIR/req" 2>/dev/null && chmod 1777 "$DIR/req"

if [ -f "$DIR/daemon.pid" ]; then
    read -r old < "$DIR/daemon.pid" || old=
    case "$old" in
        ''|*[!0-9]*) ;;
        *) grep -q jmkautoplay.AutoPlayDaemon "/proc/$old/cmdline" 2>/dev/null && kill "$old" 2>/dev/null ;;
    esac
    rm -f "$DIR/daemon.pid"
fi
# 0.3.3: a model opened after the install (the update list gave it "projection"; installed locked, nothing was changed
# then): applied now, as an update's postinstall does (it changes the stock files only when they fit; a reboot applies)
if [ -f $LOCKED ] && read -r why < $LOCKED; then
    ok=$(cat $R/data/nemesis/jmk-updates/car-ok 2>/dev/null)
    case "$why" in model*)
        case ",$ok," in *,projection,*) ( cd "$PKG" && sh scripts/postinstall.sh ) >> "$DIR/unlock.log" 2>&1 ;; esac ;;
    esac
fi
# 0.3.6: applied on another model by the default policy (no list checked yet at the install) or by an earlier list,
# and the verified list now leaves this car out: the stock features back (as the tamper lock puts them; a reboot
# applies), locked "model … closed by the update list" (the unlock above applies them again once a list names it)
if [ -f $INSTALLED ] && [ ! -f $LOCKED ] && { [ -f $COMMENTED ] || [ -f $ADDED ]; } && [ -f $R/data/nemesis/jmk-updates/car-ok ]; then
    p=$(getprop ro.build.product)
    ok=$(cat $R/data/nemesis/jmk-updates/car-ok 2>/dev/null)
    case "$p" in NEEV.KOR.*) ;; *)
        case ",$ok," in *,projection,*) ;; *)
            if put_back; then
                props_restore
                rm -f $COMMENTED $ADDED $PROPS_BEFORE
                echo "model $p (closed by the update list)" > $LOCKED
                log "boot: the update list leaves $p out: stock features back (reboot to apply)"
                ( cd "$PKG" && sh_report boot-closed "$p" )
            else
                log "boot: the update list leaves $p out, but the stock files could not be put back (records kept)"
            fi ;;
        esac ;;
    esac
fi
# 0.3.4 (QA 2026-11-19 #8): the record against the files at every boot. A firmware update that put the stock cfg
# lines or the feature files back left the menu on "reboot" forever (the state came from the record alone): our
# change is applied again (a reboot applies it), lines the new cfg no longer has leave the record, and a firmware
# without the cfg is said so (locked, its reason in words).
if [ -f $INSTALLED ] && [ ! -f $LOCKED ] && { [ -f $COMMENTED ] || [ -f $ADDED ]; }; then
    cfg_check
    [ -n "$CFG_GONE" ] && log "boot: firmware changed: featurexml.cfg has none of$CFG_GONE any more (dropped from the record)"
    case "$CFG_STATE" in
        reapply)
            log "boot: firmware changed: our featurexml.cfg lines or feature files are back to stock; applying them again (reboot to apply)"
            ( cd "$PKG" && sh scripts/postinstall.sh ) >> "$DIR/unlock.log" 2>&1
            ( cd "$PKG" && sh_report boot-reapplied "$(cfg_wireless); $(getprop ro.build.fingerprint)" ) ;;
        nocfg)
            echo "펌웨어가 바뀌어 순정 기능 설정 파일(featurexml.cfg)이 없습니다 · 순정 설정은 그대로입니다 (firmware changed: no featurexml.cfg in $(getprop ro.mobis.targetdir))" > $LOCKED
            rm -f $COMMENTED
            log "boot: firmware changed: no featurexml.cfg in $(getprop ro.mobis.targetdir) any more: locked"
            ( cd "$PKG" && sh_report boot-no-cfg "$(getprop ro.mobis.targetdir); $(getprop ro.build.fingerprint)" ) ;;
    esac
fi
# 0.3.5 (the owner 2026-11-19): the tamper lock. While the JMK MAP menu's daemon says lock=1, the stock featurexml.cfg
# and feature files come back (as an uninstall puts them; a reboot applies) and the menu shows its text; once it no
# longer does, our change is applied again (as a fresh install's postinstall).
integrity_read
if [ -n "$ILOCK" ] && [ -f $INSTALLED ] && ! { [ -f $LOCKED ] && read -r why < $LOCKED && case "$why" in integrity*) true ;; *) false ;; esac; }; then
    if put_back; then
        props_restore
        rm -f $COMMENTED $ADDED $PROPS_BEFORE
        echo "integrity ${ITEXT:-locked}" > $LOCKED
        log "boot: integrity lock: stock features back (reboot to apply)"
        ( cd "$PKG" && sh_report integrity-locked "$ITEXT" )
    else
        log "boot: integrity lock: could not put the stock files back (records kept)"
        ( cd "$PKG" && sh_report integrity-lock-failed "cfg $(md5of "$(cfg_path)")" )
    fi
elif [ -z "$ILOCK" ] && [ -f $LOCKED ] && read -r why < $LOCKED; then
    case "$why" in integrity*)
        rm -f $LOCKED
        log "boot: integrity lock lifted: applying our change again (reboot to apply)"
        ( cd "$PKG" && sh scripts/postinstall.sh ) >> "$DIR/unlock.log" 2>&1 ;;
    esac
fi
log_cap "$DIR/unlock.log" $LOG
[ -n "$JMK_AUTOPLAY_SVC_TEST" ] && exit 0   # test/scripts-test.sh: the boot checks only, no daemon
mkdir -p "$PKG/var/dalvik-cache"
[ -f "$DIR/daemon.log" ] && mv "$DIR/daemon.log" "$DIR/daemon.log.old"
echo $$ > "$DIR/daemon.pid"
chmod 0644 "$DIR/daemon.pid"
ANDROID_DATA="$PKG/var" CLASSPATH="$PKG/bin/autoplay.dex" exec /system/bin/app_process /system/bin jmkautoplay.AutoPlayDaemon \
    </dev/null >>"$DIR/daemon.log" 2>&1
