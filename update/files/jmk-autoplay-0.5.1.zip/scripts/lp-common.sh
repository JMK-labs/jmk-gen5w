#!/system/bin/sh
# The few shell helpers the LivePatch hooks need when the Java step cannot run (0.5.0): log, report, stop the daemon, "is this a real uninstall", the
# HUD add-on check, the firewall rules out. Nothing here touches /system or knows a stock name. (The 0.4.x put-back functions are NOT shipped: the line
# has nothing stock to put back; the migration's restore is the Java step jmkautoplay.Ops legacy-restore.)
[ -n "$JMK_AUTOPLAY_TEST_ROOT" ] || export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
R=${JMK_AUTOPLAY_TEST_ROOT:-}
DIR=$R/data/local/tmp/jmk-autoplay
STORE=$R/data/nemesis/jmk-autoplay
LOG=$R/data/nemesis/jmk-autoplay.log
INSTALLED=$STORE/installed
REPORTED=$R/data/nemesis/jmk-autoplay.reported
PROPS_BEFORE=$STORE/props.before

log() { echo "$1"; echo "$(date) $1" >> $LOG 2>/dev/null; true; }

parent_cmdline() { cat /proc/$PPID/cmdline 2>/dev/null; }
real_uninstall() {
    case "$(parent_cmdline)" in *uninstall*) return 0 ;; esac
    grep -q '^id=jmk-autoplay$' $R/data/local/tmp/nemesis/stage/jmk-autoplay/NEMESIS.data 2>/dev/null && return 1
    return 0
}

hud_addon() {
    local d
    for d in $R/data/nemesis/apps/jmk-autoplay-hud $R/data/nemesis/packages/jmk-autoplay-hud; do
        [ -d "$d" ] && { echo "$d"; return 0; }
    done
    return 1
}

fw_remove() {
    local b r n
    for b in iptables ip6tables; do
        for r in "INPUT -i wlan0 -p tcp --dport 5555 -j DROP" "INPUT -i wlan0 -j ACCEPT" "OUTPUT -o wlan0 -j ACCEPT"; do
            n=0
            while [ $n -lt 5 ] && $b -D $r >/dev/null 2>&1; do n=$((n + 1)); done
        done
    done
}

stop_daemon() {
    local pid
    [ -f "$DIR/daemon.pid" ] || return 0
    read -r pid < "$DIR/daemon.pid" || pid=
    case "$pid" in
        ''|*[!0-9]*) ;;
        *) grep -q jmkautoplay.AutoPlayDaemon "/proc/$pid/cmdline" 2>/dev/null && kill "$pid" 2>/dev/null ;;
    esac
    rm -f "$DIR/daemon.pid"
}

sh_report() {
    local cat="$1" detail="$2" ver= l box=$R/data/local/tmp/jmk-map-menu/outbox at tmp
    [ -d $box ] || return 0
    case "$cat" in ''|*[!a-z0-9-]*) return 0 ;; esac
    if [ -r ./NEMESIS.data ]; then
        while read -r l; do case "$l" in package-version=*) ver=${l#package-version=} ;; esac; done < ./NEMESIS.data
    fi
    case "$ver" in ''|*[!0-9.]*) return 0 ;; esac
    if [ -r $REPORTED ]; then
        while read -r l; do [ "$l" = "$ver $cat" ] && return 0; done < $REPORTED
    fi
    case "$detail" in *'"'*|*'\'*) detail='(detail not printable)' ;; esac
    set -f; set -- $detail; set +f; detail="$*"
    at=$(date +%s)000
    tmp=$box/.jmk-autoplay-install-$$.tmp
    echo "{\"kind\":\"jmk-report\",\"type\":\"install\",\"app\":\"jmk-autoplay\",\"ver\":\"$ver\",\"msg\":\"install: $cat\",\"detail\":\"$detail\",\"at\":$at}" > $tmp 2>/dev/null || { rm -f $tmp; return 0; }
    chmod 0644 $tmp
    mv $tmp $box/jmk-autoplay-install-$cat.json && echo "$ver $cat" >> $REPORTED
    return 0
}
