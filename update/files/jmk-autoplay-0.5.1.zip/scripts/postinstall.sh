#!/system/bin/sh
# LivePatch line (0.5.0): records the install and sets the two stock properties (runtime until their [prop.N] sections are approved). The feature cfg is patched
# by NEMESIS's exec step (bin/lp-cfg) and mounted at the next boot; nothing in /system is written here. rc 0 / 1 are the step's own results; anything else FAILS
# SAFE: exit 1 (NEMESIS does not take the install as done), cause logged and reported.
sh ./scripts/ops.sh postinstall --ppid "$PPID"; rc=$?
case $rc in 0|1) exit $rc ;; esac
. ./scripts/lp-common.sh
log "postinstall: the Java step could not run or failed (rc $rc): nothing more is applied"
sh_report postinstall-ops-failed "rc $rc"
exit 1
