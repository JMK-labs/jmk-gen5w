#!/system/bin/sh
# ops.sh <step> [args]: runs a step of the install hooks in the daemon's dex (the install hooks are Java steps). NEMESIS runs the hooks as root with the
# package folder as the current directory: the staging dir in preinstall, /data/nemesis/apps/<id> after. The dex's cache sits under ./var (scripts/lp-launch.sh:
# a VM that dies, a missing dex or an unwritable cache is a numbered exit 71 / 72 / 73 with a line saying why, never a silent abort).
[ -n "$JMK_AUTOPLAY_OPS_CMD" ] || [ -n "$JMK_AUTOPLAY_TEST_ROOT" ] || export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
trap '' HUP INT PIPE
if [ -n "$JMK_AUTOPLAY_OPS_CMD" ]; then   # test/ops-equiv-test.sh: the same classes on the Mac's JVM
    exec $JMK_AUTOPLAY_OPS_CMD "$@"
fi
D=$(pwd)
here=${0%/*}
case "$here" in /*) ;; *) here=$D/$here ;; esac
. "$here/lp-launch.sh"
jvm_run "ops.sh $1" "$D" "$D/bin/autoplay.dex" "$@"
exit $?
