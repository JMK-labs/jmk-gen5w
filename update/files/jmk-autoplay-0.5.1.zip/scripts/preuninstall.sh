#!/system/bin/sh
# LivePatch line (0.5.0): stops the daemon; on a real uninstall it removes our records (a Java step). The patched feature cfg and the two properties need no put-back:
# NEMESIS unmounts / restores them ([patch.1], [prop.1], [prop.2]). THE UNINSTALL NEVER DEPENDS ON JAVA: rc 0 / 1 are the step's own results (1 = refused: the HUD add-on
# is still there); anything else runs the shell fallback below, which stops the daemon, takes the firewall rules out and removes the records, then exits 0.
sh ./scripts/ops.sh preuninstall --ppid "$PPID"; rc=$?
case $rc in 0|1) exit $rc ;; esac
. ./scripts/lp-common.sh
log "preuninstall: the Java step could not run or failed (rc $rc): the shell fallback runs"
sh_report preuninstall-ops-failed "rc $rc"
if real_uninstall && hud=$(hud_addon); then
    log "거절: HUD · 계기판 길안내(jmk-autoplay-hud)를 먼저 제거하세요. 그 확장이 바꾼 순정 앱을 되돌린 뒤에 Wireless AutoPlay를 제거할 수 있습니다. 아무것도 바뀌지 않았습니다 (refused: uninstall jmk-autoplay-hud first; nothing changed)"
    sh_report preuninstall-refused-hud "$hud"
    exit 1
fi
stop_daemon
real_uninstall || { log "an update: the records stay"; exit 0; }
fw_remove
rm -f $PROPS_BEFORE $STORE/locked $INSTALLED $STORE/livepatch $DIR/livepatch
log "uninstalled (shell fallback): LivePatch puts the stock feature cfg back at the next boot"
exit 0
