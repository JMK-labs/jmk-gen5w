#!/system/bin/sh
# LivePatch line (0.5.0): refuses an install on NEMESIS below 1.17, over the legacy edits, without the JMK MAP menu, next to another wireless projection package
# (wireless.projection 2.x chains with us), or on a model the signed list has not opened (a Java step). rc 0 / 1 are the step's own results; anything else (the dex is
# gone, app_process fails, the step throws: 70) FAILS SAFE: the install is refused (exit 1), cause logged and reported, nothing changed.
sh ./scripts/ops.sh preinstall --ppid "$PPID"; rc=$?
case $rc in 0|1) exit $rc ;; esac
. ./scripts/lp-common.sh
log "preinstall: the Java step could not run (rc $rc): the install is refused, nothing changed"
sh_report preinstall-ops-failed "rc $rc"
exit 1
