#!/system/bin/sh
# The JMK menu's migration step (migrate.meta restore=): puts the legacy line's (0.3.x / 0.4.x) edits of the stock feature cfg, permission files and properties back
# BEFORE the LivePatch build is installed, so NEMESIS does not take our edited files as stock. Run as root from the unpacked zip: sh scripts/legacy-restore.sh
# Exit 0 = restored, 10 = nothing to do, 1 = a part failed (records kept), 70 = the step itself failed, 71 / 72 / 73 = the Java step could not run (scripts/lp-launch.sh).
# The last line printed is "legacy-restore: cfg= files= props=" (or a "legacy-restore: …" line saying why the step did not run).
# The runner's JMK_PKG is the package ID, not a folder (runner.md §3): the folder is this script's parent, JMK_TMP (the cwd) holds the dalvik-cache.
here=${0%/*}
case "$here" in /*) ;; *) here=$(pwd)/$here ;; esac
PKG=$here/..
T=${JMK_TMP:-$PKG}
[ -n "$JMK_AUTOPLAY_OPS_CMD" ] || [ -n "$JMK_AUTOPLAY_TEST_ROOT" ] || export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
if [ -n "$JMK_AUTOPLAY_OPS_CMD" ]; then exec $JMK_AUTOPLAY_OPS_CMD legacy-restore; fi
. "$here/lp-launch.sh"
jvm_run legacy-restore "$T" "$PKG/bin/autoplay.dex" legacy-restore --pkg "$PKG"
exit $?
