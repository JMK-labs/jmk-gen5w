#!/system/bin/sh
# Starts the package's Java steps (app_process on the package's dex) so that a dead VM is never silent: sourced by ops.sh, legacy-restore.sh, legacy-verify.sh.
#   jvm_run <label> <cache-base> <dex> <step args...>
# Exit codes besides the step's own: 73 = the dex is not there, 71 = no writable dalvik-cache anywhere, 72 = the VM died (a signal: "exit 134" is SIGABRT).
# Each of them prints one line starting with <label>: that says why; the step's own output and exit code pass through unchanged.
# (0.5.0, LY3LOBUL 2026-11-28: the migration runner's JMK_PKG is the package ID, not a folder: the old scripts took it for the folder, the VM found no dex and aborted
# with nothing printed; every path below is derived from $0 and the runner's cwd / JMK_TMP now.)
jvm_run() {
    label=$1; base=$2; dex=$3; shift 3
    if [ ! -f "$dex" ]; then echo "$label: the Java dex is missing: $dex (not started)"; return 73; fi
    var=
    alt="/data/local/tmp/jmk-ap /dev/jmk-ap"; app=/system/bin/app_process
    if [ -n "$JMK_AUTOPLAY_TEST_ROOT" ]; then   # the tests' sandbox: a fake app_process and their own fallback dirs
        [ -n "$JMK_AUTOPLAY_CACHE_ALT" ] && alt=$JMK_AUTOPLAY_CACHE_ALT
        [ -n "$JMK_AUTOPLAY_APP_PROCESS" ] && app=$JMK_AUTOPLAY_APP_PROCESS
    fi
    for b in "$base" $alt; do
        [ -n "$b" ] || continue
        mkdir -p "$b/var/dalvik-cache" 2>/dev/null || continue
        : > "$b/var/dalvik-cache/.w" 2>/dev/null || continue
        rm -f "$b/var/dalvik-cache/.w"
        var=$b/var
        break
    done
    if [ -z "$var" ]; then echo "$label: no writable dalvik-cache (tried $base and the fallbacks): the Java step was not started"; return 71; fi
    ANDROID_DATA=$var CLASSPATH=$dex $app /system/bin jmkautoplay.Ops "$@"
    rc=$?
    if [ $rc -ge 129 ] && [ $rc -le 192 ]; then
        echo "$label: the Java step died with signal $((rc - 128)) (exit $rc), cache $var, dex $dex"
        return 72
    fi
    return $rc
}
