#!/system/bin/sh
# The migration's check (migrate.meta verify=): exit 0 = the lower feature cfg looks stock (no legacy record, none of our lines commented), anything else = not
# (1 = records or commented lines; 71 / 72 / 73 = the Java step could not run, scripts/lp-launch.sh, with a "legacy-verify: …" line saying why). Writes nothing.
# The runner's JMK_PKG is the package ID, not a folder (runner.md §3): the folder is this script's parent, JMK_TMP (the cwd) holds the dalvik-cache.
here=${0%/*}
case "$here" in /*) ;; *) here=$(pwd)/$here ;; esac
PKG=$here/..
T=${JMK_TMP:-$PKG}
[ -n "$JMK_AUTOPLAY_OPS_CMD" ] || [ -n "$JMK_AUTOPLAY_TEST_ROOT" ] || export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
if [ -n "$JMK_AUTOPLAY_OPS_CMD" ]; then exec $JMK_AUTOPLAY_OPS_CMD legacy-verify; fi
. "$here/lp-launch.sh"
jvm_run legacy-verify "$T" "$PKG/bin/autoplay.dex" legacy-verify
exit $?
