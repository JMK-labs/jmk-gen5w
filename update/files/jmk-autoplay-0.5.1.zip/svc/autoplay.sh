#!/system/bin/sh
# NEMESIS service (root): the JMK Wireless AutoPlay daemon (jmkautoplay.AutoPlayDaemon). It writes the status the JMK MAP menu shows. Since 0.4.0 this script
# only prepares the state dir, stops the old daemon, runs the boot checks (the Java boot step: the closed-model note, LivePatch's state) and starts the
# daemon; the checks themselves are Java. 0.5.0 (LivePatch): no stock file is checked or re-applied here any more.
# (mksh: single-digit fds only; no sed/head/tail on this firmware)
[ -n "$JMK_AUTOPLAY_OPS_CMD" ] || export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin   # (the tests put their own PATH and the Java launcher)
PKG=${JMK_AUTOPLAY_PKG:-/data/nemesis/apps/jmk-autoplay}
[ -d "$PKG" ] || PKG=/data/nemesis/packages/jmk-autoplay
R=${JMK_AUTOPLAY_TEST_ROOT:-}
DIR=$R/data/local/tmp/jmk-autoplay        # status and requests for the JMK MAP menu

# The MAP menu (an app, uid of its own) reads $DIR; /data/local/tmp is 0771 shell:shell after boot, and root without
# capabilities can't create in it, so ask the shell user then (that dir then stays the shell's, 0777).
if mkdir -p "$DIR" 2>/dev/null; then
    chmod 0755 "$DIR"
else
    /system/xbin/nemesis root 2000 -c "mkdir -p $DIR; chmod 0777 $DIR" </dev/null >/dev/null 2>&1
fi
mkdir -p "$DIR/req" 2>/dev/null && chmod 1777 "$DIR/req"

if [ -f "$DIR/daemon.pid" ]; then
    read -r old < "$DIR/daemon.pid" || old=
    case "$old" in
        ''|*[!0-9]*) ;;
        *) grep -q jmkautoplay.AutoPlayDaemon "/proc/$old/cmdline" 2>/dev/null && kill "$old" 2>/dev/null ;;
    esac
    rm -f "$DIR/daemon.pid"
fi
# the boot checks (before the daemon: a model opened or closed since the install, LivePatch's state)
# A failure of the step itself (the dex is gone, app_process fails, it throws) is logged and reported and the daemon starts anyway: the checks are skipped this boot, the
# next one tries again (today's behaviour is "no checks" at worst, never a daemon that does not start).
( cd "$PKG" && sh ./scripts/ops.sh boot --pkg "$PKG" ); rc=$?
if [ $rc -ne 0 ]; then
    ( cd "$PKG" && . ./scripts/lp-common.sh && log "boot: the Java checks could not run (rc $rc): skipped, the daemon starts" && sh_report boot-ops-failed "rc $rc" ) >/dev/null 2>&1
fi
[ -n "$JMK_AUTOPLAY_SVC_TEST" ] && exit 0   # test/scripts-test.sh: the boot checks only, no daemon
mkdir -p "$PKG/var/dalvik-cache"
[ -f "$DIR/daemon.log" ] && mv "$DIR/daemon.log" "$DIR/daemon.log.old"
echo $$ > "$DIR/daemon.pid"
chmod 0644 "$DIR/daemon.pid"
ANDROID_DATA="$PKG/var" CLASSPATH="$PKG/bin/autoplay.dex" exec /system/bin/app_process /system/bin jmkautoplay.AutoPlayDaemon \
    </dev/null >>"$DIR/daemon.log" 2>&1
