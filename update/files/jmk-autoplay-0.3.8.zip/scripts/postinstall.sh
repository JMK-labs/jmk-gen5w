#!/system/bin/sh
# Turns the stock wireless CarPlay / Android Auto features on (a reboot applies them). Another model that the update
# list does not name yet, or a firmware without the cfg: installed, nothing changed ("locked").
. ./scripts/common.sh
log_cap $LOG
log "postinstall jmk-autoplay"
mkdir -p $STORE && chmod 0700 $STORE
: > $INSTALLED
# 0.3.7: the tamper lock first (common.sh lock_hold). While the MAP menu's verdict says lock=1, this run, whatever started
# it (a first install, an update from NEMESIS, NEMESIS Manager or the MAP menu, the menu's recheck, the service), writes
# nothing of ours: what of ours is in place goes back and LOCKED keeps the lock's text. Its own release rule (the verdict
# no longer says lock=1) applies our change: at that install, or at the service's next start (svc/autoplay.sh).
integrity_read
if [ -n "$ILOCK" ]; then
    lock_hold && log "integrity lock (${ITEXT:-lock=1}): nothing applied; applied once the lock is lifted"
    exit 0
fi
rm -f $LOCKED
if ! fits; then
    # 0.3.7: applied before (the published default with no list yet, or an earlier list) and this run finds a verified
    # list that leaves the car out: the stock features back now, as the boot's "closed" does (svc). Before, LOCKED was
    # written over our change in place, and the service, seeing LOCKED, never put it back (features on, shown locked).
    if [ -f $COMMENTED ] || [ -f $ADDED ] || [ -f $PROPS_BEFORE ]; then
        if ! stock_back; then
            log "the update list leaves $(getprop ro.build.product) out, but the stock files could not be put back (records kept; the service tries again)"
            exit 0
        fi
        echo "model $(getprop ro.build.product) (closed by the update list)" > $LOCKED
        log "locked: the update list leaves $(getprop ro.build.product) out: stock features back (reboot to apply)"
        sh_report postinstall-closed "$(getprop ro.build.product)"
        exit 0
    fi
    echo "model $(getprop ro.build.product)" > $LOCKED
    log "locked: $(getprop ro.build.product) is not checked yet, nothing changed"
    sh_report postinstall-locked "$(getprop ro.build.product); $(cfg_wireless); stepofspec $(getprop ro.product.opt.stepofspec)"
    exit 0
fi
cfg=$(cfg_path) || {
    echo "no featurexml.cfg in $(getprop ro.mobis.targetdir)" > $LOCKED
    log "locked: no featurexml.cfg ($(getprop ro.mobis.targetdir)), nothing changed"
    sh_report postinstall-no-cfg "$(getprop ro.mobis.targetdir)"
    exit 0
}
# 0.3.4 (QA #15): no whole-cfg copy any more (never used: the uninstall undoes our recorded lines; stale after a
# firmware update); the one an older version kept goes
rm -f $BACKUP/featurexml.cfg
log "featurexml.cfg before: $(md5of $cfg)"
props_save
if ! rw_begin; then
    log "FAIL: /system is read-only, nothing changed"
    sh_report postinstall-system-ro "$(grep ' /system ' /proc/mounts)"
    rw_end; exit 1
fi
ok=1
cfg_rewrite on || ok=0
feature_file $F_AA || ok=0
feature_file $F_CP || ok=0
rw_end
for p in $PROPS; do setprop $p t; done
[ -n "$FIT_DEFAULT" ] && log "no update list checked on this car yet: the published policy (every model) applies; a list that leaves it out puts the stock features back"
if [ $ok -eq 1 ]; then
    log "wireless CarPlay / Android Auto features on (reboot to apply); props: $(getprop persist.sys.iap2.wifi)/$(getprop persist.iap2.iden.wireless)"
else
    log "WARNING: a change failed (see above); the uninstall restores what was done"
    sh_report postinstall-apply "cfg $(md5of $cfg), added $(cat $ADDED 2>/dev/null)"
fi
[ "$(getprop persist.service.adb.tcp.enable)" = 1 ] && log "note: persist.service.adb.tcp.enable=1 puts eth0 on 192.168.0.123 (inside the hotspot): phones may get no address"
exit 0
