#!/system/bin/sh
# 2.3.8 (the owner, 2026-11-17): no JMK program next to Korea Projection. A first install is refused; an update goes
# ahead (NEMESIS has run the old package's uninstall hooks by now: a refusal would leave the menu half removed), the
# menu then tells the owner. The work folder outlives an uninstall, so it marks an earlier install.
kp=""
for d in /data/nemesis/apps/korea.projection /data/nemesis/packages/korea.projection; do [ -d "$d" ] && kp=$d; done
if [ -n "$kp" ]; then
    if [ ! -d /data/nemesis/apps/jmk-map-menu ] && [ ! -d /data/nemesis/packages/jmk-map-menu ] && [ ! -d /data/local/tmp/jmk-map-menu ]; then
        echo 'Korea Projection(korea.projection)과 함께 설치할 수 없습니다. 먼저 제거하세요 (remove korea.projection first)' >&2
        exit 1
    fi
    echo 'warning: korea.projection is installed; JMK programs are not made to run next to it' >&2
fi
exit 0
