#!/system/bin/sh
# Refuses a first install without the JMK MAP menu or next to another wireless projection package; an update always goes ahead (a Java step).
# 0.4.0 failure rule: rc 0 / 1 are the step's own results. Anything else (the dex is gone, app_process fails, the step throws: 70) FAILS SAFE: the install is refused
# (exit 1) with the cause logged and reported, nothing changed. The old shell exited 1 on its own refusals the same way.
sh ./scripts/ops.sh preinstall --ppid "$PPID"; rc=$?
case $rc in 0|1) exit $rc ;; esac
. ./scripts/fallback.sh
log "preinstall: the Java step could not run (rc $rc): the install is refused, nothing changed"
sh_report preinstall-ops-failed "rc $rc"
exit 1
