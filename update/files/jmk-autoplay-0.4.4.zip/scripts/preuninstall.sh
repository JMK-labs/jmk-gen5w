#!/system/bin/sh
# Stops the daemon; on a real uninstall it puts back exactly what we changed (a Java step). An update keeps the changes.
# 0.4.0 failure rule (2026-11-26): THE UNINSTALL NEVER DEPENDS ON JAVA. rc 0 / 1 are the step's own results (1 = refused: the HUD add-on is still there, or
# the records stay because /system could not be written). Anything else (the dex is gone, app_process fails, the step throws: 70) runs the shell fallback: the 0.3.21
# functions kept in scripts/fallback.sh for this path only, which put the stock files back, report it, and exit 0 (1 only when /system cannot be written: the
# records stay and NEMESIS keeps the package, as the old script did).
sh ./scripts/ops.sh preuninstall --ppid "$PPID"; rc=$?
case $rc in 0|1) exit $rc ;; esac
. ./scripts/fallback.sh
log "preuninstall: the Java step could not run or failed (rc $rc): the shell fallback runs"
sh_report preuninstall-ops-failed "rc $rc"
# the HUD add-on's refusal needs no Java either: AutoPlay is never removed under an add-on whose patched stock apps still depend on it (0.3.11)
if real_uninstall && hud=$(hud_addon); then
    log "거절: HUD · 계기판 길안내(jmk-autoplay-hud)를 먼저 제거하세요. 그 확장이 바꾼 순정 앱을 되돌린 뒤에 Wireless AutoPlay를 제거할 수 있습니다. 아무것도 바뀌지 않았습니다 (refused: uninstall jmk-autoplay-hud first; nothing changed)"
    sh_report preuninstall-refused-hud "$hud"
    exit 1
fi
stop_daemon
real_uninstall || { log "an update: the changes stay"; exit 0; }
fw_remove
if [ ! -f "$UNDO" ]; then
    # Ops never ran on this car (no undo file was ever written): nothing stock-specific can be done from here, and nothing of 0.4.0 was applied
    log "preuninstall fallback: no undo file ($UNDO): nothing stock is touched"
    sh_report preuninstall-no-undo "rc $rc"
    exit 0
fi
if ! undo_trusted; then
    # an undo file another uid could have written is never run; the uninstall is blocked only when /system cannot be written, so this goes on like "no undo file"
    log "preuninstall fallback: the undo file is not root-owned 0600: not used, nothing stock is touched"
    sh_report preuninstall-undo-untrusted "rc $rc"
    exit 0
fi
undo_load
if ! put_back; then
    log "FAIL: uninstall stopped: the records stay in $STORE, so it can be done again with /system writable"
    sh_report preuninstall-failed "rc $rc"
    exit 1
fi
props_restore
rm -f $COMMENTED $ADDED $PROPS_BEFORE $UNDO $STORE/commented $STORE/added $STORE/props.before $STORE/locked $INSTALLED $BACKUP/*.cfg
rmdir $BACKUP 2>/dev/null
log "uninstalled (shell fallback): stock features back (reboot to apply)"
exit 0
