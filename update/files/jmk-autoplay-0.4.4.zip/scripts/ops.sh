#!/system/bin/sh
# ops.sh <step> [args]: runs a step of the install hooks in the daemon's dex (the install hooks are Java steps). NEMESIS runs the hooks as root with the
# package folder as the current directory: the staging dir in preinstall, /data/nemesis/apps/<id> after. The dex's cache sits under ./var.
[ -n "$JMK_AUTOPLAY_OPS_CMD" ] || export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
trap '' HUP INT PIPE
if [ -n "$JMK_AUTOPLAY_OPS_CMD" ]; then   # test/ops-equiv-test.sh: the same classes on the Mac's JVM
    exec $JMK_AUTOPLAY_OPS_CMD "$@"
fi
D=$(pwd)
mkdir -p "$D/var/dalvik-cache" 2>/dev/null
ANDROID_DATA="$D/var" CLASSPATH="$D/bin/autoplay.dex" exec /system/bin/app_process /system/bin jmkautoplay.Ops "$@"
