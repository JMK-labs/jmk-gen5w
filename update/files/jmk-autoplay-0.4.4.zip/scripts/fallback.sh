#!/system/bin/sh
# The SHELL FALLBACK of the uninstall (2026-11-26): the uninstall never depends on Java, and this file carries NO stock name.
# Everything it puts back comes from the UNDO FILE that the daemon's install step writes on the car (/data/nemesis/jmk-autoplay/undo, root-owned 0600, atomic, written
# only after the edit it undoes succeeded, refreshed at every boot; never in the zip): the cfg's path, the cfg lines we commented, the permission files we
# added, the properties' values before us. scripts/preuninstall.sh sources this only when the Java step could not run. With no undo file nothing stock-
# specific is done (logged and reported); an undo file that is not root-owned 0600 is refused. The functions are the 0.3.21 ones (test/legacy is their oracle).
[ -n "$JMK_AUTOPLAY_TEST_ROOT" ] || export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin   # (the tests keep their own PATH)
R=${JMK_AUTOPLAY_TEST_ROOT:-}
DIR=$R/data/local/tmp/jmk-autoplay
STORE=$R/data/nemesis/jmk-autoplay
BACKUP=$R/data/nemesis/backups/jmk-autoplay
LOG=$R/data/nemesis/jmk-autoplay.log
INSTALLED=$STORE/installed
REPORTED=$R/data/nemesis/jmk-autoplay.reported
UNDO=$STORE/undo
# the undo file's three lists are copied into these (what the functions below read); the real records are removed with the undo file
COMMENTED=$STORE/.undo.commented
ADDED=$STORE/.undo.added
PROPS_BEFORE=$STORE/.undo.props
UNDO_CFG=
FEATURE_HEAD='<?xml version="1.0" encoding="utf-8"?>'

# /system read-write for a moment (in a sandbox root it counts as writable unless RW_FAIL is set)
rw_begin() { if [ -n "$R" ]; then [ -z "${RW_FAIL:-}" ]; return; fi; WAS_RO=0; system_rw || { WAS_RO=1; /system/xbin/nemesis remount rw >/dev/null 2>&1; }; system_rw; }
rw_end() { [ -n "$R" ] && return 0; sync; [ $WAS_RO -eq 1 ] && system_rw && /system/xbin/nemesis remount ro >/dev/null 2>&1; true; }

# the cfg's path comes from the undo file, never from a property
cfg_path() { [ -n "$UNDO_CFG" ] && [ -f "$R$UNDO_CFG" ] && echo "$R$UNDO_CFG"; }

# undo_trusted: the undo file is a regular file, owned by whoever runs this (root on the car) and mode 0600: never lines another uid could have written.
# toolbox "ls -l" prints "<mode> <owner> <group> ..." (a host ls adds the link count: 9 fields); the owner is compared with a file created just now.
undo_trusted() {
    local mine=$STORE/.undo.me m o m2 o2 n
    : > $mine 2>/dev/null || return 1
    set -- $(ls -l "$mine" 2>/dev/null); n=$#; m2=$1; if [ $n -ge 9 ]; then o2=$3; else o2=$2; fi
    rm -f $mine
    set -- $(ls -l "$UNDO" 2>/dev/null); n=$#; m=$1; if [ $n -ge 9 ]; then o=$3; else o=$2; fi
    [ -f "$UNDO" ] && [ -n "$m" ] && [ "$o" = "$o2" ] && case "$m" in -rw-------*) true ;; *) false ;; esac
}

# undo_load: split the undo file into the three lists and UNDO_CFG
undo_load() {
    local l
    UNDO_CFG=
    : > $COMMENTED; : > $ADDED; : > $PROPS_BEFORE
    while IFS= read -r l || [ -n "$l" ]; do
        case "$l" in
            cfg=*) UNDO_CFG=${l#cfg=} ;;
            comment=*) print -r -- "${l#comment=}" >> $COMMENTED ;;
            added=*) print -r -- "${l#added=}" >> $ADDED ;;
            prop=*) print -r -- "${l#prop=}" >> $PROPS_BEFORE ;;
        esac
    done < "$UNDO"
}

log() { echo "$1"; echo "$(date) $1" >> $LOG 2>/dev/null; true; }

# A real uninstall, not the old package's uninstall step inside an update (NEMESIS runs the old preuninstall with the
# new package already staged, from its "nemesis install --update" process). 0.3.4 (QA 2026-11-19 #5), three ways:
# the parent says "uninstall": a real uninstall, whatever is staged (a stage left by an interrupted install never
# turns it into nothing); it says "install": an update when our package is staged; it names neither (NEMESIS
# Manager's own process, an unreadable cmdline): the staged package decides, as before.
parent_cmdline() { cat /proc/$PPID/cmdline 2>/dev/null; }
real_uninstall() {
    case "$(parent_cmdline)" in *uninstall*) return 0 ;; esac
    grep -q '^id=jmk-autoplay$' $R/data/local/tmp/nemesis/stage/jmk-autoplay/NEMESIS.data 2>/dev/null && return 1
    return 0
}

parent_cmdline() { cat /proc/$PPID/cmdline 2>/dev/null; }
real_uninstall() {
    case "$(parent_cmdline)" in *uninstall*) return 0 ;; esac
    grep -q '^id=jmk-autoplay$' $R/data/local/tmp/nemesis/stage/jmk-autoplay/NEMESIS.data 2>/dev/null && return 1
    return 0
}

real_uninstall() {
    case "$(parent_cmdline)" in *uninstall*) return 0 ;; esac
    grep -q '^id=jmk-autoplay$' $R/data/local/tmp/nemesis/stage/jmk-autoplay/NEMESIS.data 2>/dev/null && return 1
    return 0
}

size_kb() { local n; set -- $(ls -s "$1" 2>/dev/null); n=$1; case "$n" in ''|*[!0-9]*) n=0 ;; esac; echo $n; }
# free_kb <dir>: KB free on its filesystem, empty when unknown. Toolbox df's last line is "<fs> <size> <used> <free>
# <blksize>" with sizes like 412.0M; busybox df has KB in the same (4th) column.
free_kb() {
    local out last v i f IFS
    out=$(df "$1" 2>/dev/null) || return 0
    IFS='
'
    set -f; set -- $out; set +f
    [ $# -ge 2 ] || return 0
    eval "last=\${$#}"
    IFS=' 	'
    set -f; set -- $last; set +f
    v=$4
    case "$v" in
        *K|*M|*G) ;;
        ''|*[!0-9]*) return 0 ;;
        *) echo "$v"; return 0 ;;
    esac
    i=${v%?}; f=0
    case "$i" in *.*) f=${i#*.}; i=${i%%.*}; f=${f%"${f#?}"} ;; esac
    case "$i$f" in ''|*[!0-9]*) return 0 ;; esac
    case "$v" in
        *K) echo $i ;;
        *M) echo $((i * 1024 + f * 1024 / 10)) ;;
        *G) echo $((i * 1048576 + f * 104857)) ;;
    esac
}

free_kb() {
    local out last v i f IFS
    out=$(df "$1" 2>/dev/null) || return 0
    IFS='
'
    set -f; set -- $out; set +f
    [ $# -ge 2 ] || return 0
    eval "last=\${$#}"
    IFS=' 	'
    set -f; set -- $last; set +f
    v=$4
    case "$v" in
        *K|*M|*G) ;;
        ''|*[!0-9]*) return 0 ;;
        *) echo "$v"; return 0 ;;
    esac
    i=${v%?}; f=0
    case "$i" in *.*) f=${i#*.}; i=${i%%.*}; f=${f%"${f#?}"} ;; esac
    case "$i$f" in ''|*[!0-9]*) return 0 ;; esac
    case "$v" in
        *K) echo $i ;;
        *M) echo $((i * 1024 + f * 1024 / 10)) ;;
        *G) echo $((i * 1048576 + f * 104857)) ;;
    esac
}

hud_addon() {
    local d
    for d in $R/data/nemesis/apps/jmk-autoplay-hud $R/data/nemesis/packages/jmk-autoplay-hud; do
        [ -d "$d" ] && { echo "$d"; return 0; }
    done
    return 1
}

fw_remove() {
    local b r n
    for b in iptables ip6tables; do
        for r in "INPUT -i wlan0 -p tcp --dport 5555 -j DROP" "INPUT -i wlan0 -j ACCEPT" "OUTPUT -o wlan0 -j ACCEPT"; do
            n=0
            while [ $n -lt 5 ] && $b -D $r >/dev/null 2>&1; do n=$((n + 1)); done
        done
    done
}

stop_daemon() {
    local pid
    [ -f "$DIR/daemon.pid" ] || return 0
    read -r pid < "$DIR/daemon.pid" || pid=
    case "$pid" in
        ''|*[!0-9]*) ;;
        *) grep -q jmkautoplay.AutoPlayDaemon "/proc/$pid/cmdline" 2>/dev/null && kill "$pid" 2>/dev/null ;;
    esac
    rm -f "$DIR/daemon.pid"
}

sh_report() {
    local cat="$1" detail="$2" ver= l box=$R/data/local/tmp/jmk-map-menu/outbox at tmp
    [ -d $box ] || return 0
    case "$cat" in ''|*[!a-z0-9-]*) return 0 ;; esac
    if [ -r ./NEMESIS.data ]; then
        while read -r l; do case "$l" in package-version=*) ver=${l#package-version=} ;; esac; done < ./NEMESIS.data
    fi
    case "$ver" in ''|*[!0-9.]*) return 0 ;; esac
    if [ -r $REPORTED ]; then
        while read -r l; do [ "$l" = "$ver $cat" ] && return 0; done < $REPORTED
    fi
    case "$detail" in *'"'*|*'\'*) detail='(detail not printable)' ;; esac
    set -f; set -- $detail; set +f; detail="$*"
    at=$(date +%s)000
    tmp=$box/.jmk-autoplay-install-$$.tmp
    echo "{\"kind\":\"jmk-report\",\"type\":\"install\",\"app\":\"jmk-autoplay\",\"ver\":\"$ver\",\"msg\":\"install: $cat\",\"detail\":\"$detail\",\"at\":$at}" > $tmp 2>/dev/null || { rm -f $tmp; return 0; }
    chmod 0644 $tmp
    mv $tmp $box/jmk-autoplay-install-$cat.json && echo "$ver $cat" >> $REPORTED
    return 0
}

md5of() { set -- $(md5 "$1" 2>/dev/null); echo "$1"; }

system_rw() {
    local dev mnt fs opts rest
    while read -r dev mnt fs opts rest; do
        [ "$mnt" = /system ] || continue
        case ",$opts," in *,rw,*) return 0 ;; esac
        return 1
    done < /proc/mounts
    return 1
}

system_rw() {
    local dev mnt fs opts rest
    while read -r dev mnt fs opts rest; do
        [ "$mnt" = /system ] || continue
        case ",$opts," in *,rw,*) return 0 ;; esac
        return 1
    done < /proc/mounts
    return 1
}

has_line() {
    local l
    [ -f "$2" ] || return 1
    while IFS= read -r l || [ -n "$l" ]; do [ "$l" = "$1" ] && return 0; done < "$2"
    return 1
}

feature_body() { echo "<permissions><feature name=\"$1\" /></permissions>"; }

ours_feature() {
    local n=${1##*/}
    n=${n%.xml}
    has_line "$FEATURE_HEAD" $R$1 && has_line "$(feature_body $n)" $R$1
}

props_restore() {
    local p v
    [ -f $PROPS_BEFORE ] || return 0
    while IFS='=' read -r p v; do [ -n "$p" ] && setprop "$p" "$v"; done < $PROPS_BEFORE
}

cfg_rewrite() {
    local want=off cfg tmp line e out n=0 i=0 chg=" " rec= free need sum
    cfg=$(cfg_path) || return 1
    tmp=$cfg.jmk
    rm -f $tmp $tmp.u
    need=$(( $(size_kb $cfg) * 2 + 64 ))
    free=$(free_kb ${cfg%/*})
    if [ -n "$free" ] && [ "$free" -lt $need ]; then
        log "FAIL: ${cfg%/*} has $free KB free, $need KB needed for the the cfg copy: left as it was"
        return 1
    fi
    : > $tmp || return 1
    while :; do
        if IFS= read -r line; then e=; elif [ -n "$line" ]; then e=n; else break; fi
        i=$((i+1)); out=$line
            case "$line" in
                "#-"*) has_line "${line#\#}" $COMMENTED && { out=${line#\#}; chg="$chg$i "; n=$((n+1)); } ;;
            esac
        print -r$e -- "$out" >> $tmp || { rm -f $tmp; log "FAIL: the cfg copy not written (line $i), left as it was"; return 1; }
    done < $cfg
    [ $n -eq 0 ] && { rm -f $tmp; return 0; }
    # the check: the copy with only our changed lines undone must be the cfg, byte for byte
    : > $tmp.u || { rm -f $tmp $tmp.u; return 1; }
    i=0
    while :; do
        if IFS= read -r line; then e=; elif [ -n "$line" ]; then e=n; else break; fi
        i=$((i+1))
        case "$chg" in *" $i "*) line="#$line" ;; esac
        print -r$e -- "$line" >> $tmp.u || { rm -f $tmp $tmp.u; log "FAIL: the cfg check copy not written, left as it was"; return 1; }
    done < $tmp
    sum=$(md5of $cfg)
    if [ -z "$sum" ] || [ "$(md5of $tmp.u)" != "$sum" ]; then
        rm -f $tmp $tmp.u; log "FAIL: the cfg copy does not undo into the cfg (incomplete write?), left as it was"; return 1
    fi
    rm -f $tmp.u
    sum=$(md5of $tmp)
    chmod 0644 $tmp; chown 0.0 $tmp 2>/dev/null
    sync
    if ! mv $tmp $cfg; then rm -f $tmp; log "FAIL: the cfg not replaced"; return 1; fi
    sync
    [ "$(md5of $cfg)" = "$sum" ] || { log "FAIL: the cfg is not the copy after the rename"; return 1; }
    log "the cfg: $n line(s) restored, now $sum"
    return 0
}

# put_back: the stock files back from the lists (the cfg lines, our permission files if still ours). 1 when something could not be put back.
put_back() {
    local ok=1 f left
    if [ -s $COMMENTED ] || [ -s $ADDED ]; then
        if rw_begin; then
            if [ -s $COMMENTED ] && ! cfg_rewrite; then
                if cfg_path >/dev/null; then ok=0; log "FAIL: the cfg not restored"; else log "no cfg any more: nothing to put back there"; fi
            fi
            if [ -s $ADDED ]; then
                left=
                while read -r f || [ -n "$f" ]; do
                    case "$f" in /*/*.xml) ;; *) continue ;; esac
                    [ -e "$R$f" ] || continue
                    if ! ours_feature "$f"; then log "WARNING: $f changed since we added it: left alone"; continue; fi
                    rm -f "$R$f"
                    [ -e "$R$f" ] && { left="$left $f"; ok=0; }
                done < $ADDED
                [ -n "$left" ] && log "FAIL: could not remove$left"
            fi
            rw_end
        else
            ok=0
            log "FAIL: /system read-only, nothing put back"
            sh_report preuninstall-system-ro "$(grep ' /system ' /proc/mounts)"
            rw_end
        fi
    fi
    [ $ok -eq 1 ]
}
