#!/system/bin/sh
# Turns the stock wireless CarPlay / Android Auto features on (a reboot applies them); the tamper lock, another model, a firmware without the cfg: see
# the daemon's Java step (the shell of 0.3.21 is test/legacy).
# 0.4.0 failure rule: rc 0 / 1 are the step's own results. Anything else FAILS SAFE: exit 1 (NEMESIS then does not take the install as done), the cause logged and
# reported. If the step got part-way, what it changed is recorded and a real uninstall puts it back (as after the old shell's "a change failed"). The car is
# never left worse than a failed install of the old script.
sh ./scripts/ops.sh postinstall --ppid "$PPID"; rc=$?
case $rc in 0|1) exit $rc ;; esac
. ./scripts/fallback.sh
log "postinstall: the Java step could not run or failed (rc $rc): nothing more is applied; what was applied is recorded and an uninstall puts it back"
sh_report postinstall-ops-failed "rc $rc"
exit 1
