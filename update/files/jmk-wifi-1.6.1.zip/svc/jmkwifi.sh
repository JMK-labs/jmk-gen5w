#!/system/bin/sh
# NEMESIS service (root): the Wi-Fi Driver's boot step, then the daemon. 1.5.0: everything that decides something is Java now
# (jmkwifi.WifiOps boot-prepare: the fit check of every boot, the setting 동글 용도, the dongle drivers' naming and insmod, the panic guards,
# driver.txt); this script only runs it, stops the previous daemon and starts the new one.
# The driver goes in first and as early as possible: its usbfs block must be in place before Android's USB host service sees the dongle (else the
# stock Android Auto service probes it as a phone). Never rmmod it (that rebooted the head unit).
# After an update started from adb this runs as root without capabilities: insmod is then impossible, and the daemon keeps what the previous one
# left running until the next boot.
# (mksh: single-digit fds only; no sed/head/tail on this firmware)
export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
PKG=/data/nemesis/apps/jmk-wifi
[ -d "$PKG" ] || PKG=/data/nemesis/packages/jmk-wifi
DIR=/data/local/tmp/jmk-wifi

UPT=/proc/uptime
BOOTID=/proc/sys/kernel/random/boot_id
STOREBOOTID=/data/nemesis/jmk-wifi/boot-id

# 1.5.4: a stage line of this script in daemon.log ("Boot: <stage> [detail] up=<s>", the same shape the Java steps write), synced: the lines the Java
# steps cannot write (the script started, the boot step ended with rc, the daemon is about to start) say whether a run ended inside the boot step or outside it
bootline() {
    local up idle
    read -r up idle < $UPT
    echo "$(date)  Boot: $1${2:+ $2} up=$up" >> "$DIR/daemon.log" 2>/dev/null
    sync
}
# the kind of this run, one fact (BootTrace.runKind): restart = the daemon already started in THIS boot (its boot-id record is this boot's), else boot
runkind() {
    local cur= st=
    [ -r $BOOTID ] && read -r cur < $BOOTID
    [ -r $STOREBOOTID ] && read -r st < $STOREBOOTID
    if [ -n "$cur" ] && [ "$cur" = "$st" ]; then echo restart; else echo boot; fi
}

mkdir -p "$PKG/var/dalvik-cache"
# 1.5.3: the previous run's log moves aside FIRST, so the boot step's stage lines and the daemon's are one run in one file (the next start reads .old: did that boot settle)
[ -f "$DIR/daemon.log" ] && mv "$DIR/daemon.log" "$DIR/daemon.log.old"
if [ -d "$DIR" ]; then
    cur=; [ -r $BOOTID ] && read -r cur < $BOOTID
    bootline service-begin "id=${cur%"${cur#????????}"} run=$(runkind)"
fi
# never keeps the daemon from starting: whatever this step could not do is said in its own log, and the daemon reads the facts again
( cd "$PKG" && ANDROID_DATA="$PKG/var" CLASSPATH="$PKG/bin/jmkwifi.dex" /system/bin/app_process /system/bin jmkwifi.WifiOps boot-prepare ) \
    </dev/null >>/data/local/tmp/jmk-wifi-boot.log 2>&1
rc=$?
[ -d "$DIR" ] && bootline boot-step-end "rc=$rc"

# status and logs: root's dir (the step made it; this is the way after a step that could not)
if [ ! -d "$DIR" ]; then
    if mkdir -p "$DIR" 2>/dev/null; then chmod 0755 "$DIR"; else /system/xbin/nemesis root 2000 -c "mkdir -p $DIR; chmod 0777 $DIR" </dev/null >/dev/null 2>&1; fi
fi
if [ -f "$DIR/daemon.pid" ]; then
    read -r old < "$DIR/daemon.pid" || old=
    case "$old" in
        ''|*[!0-9]*) ;;
        *) grep -q jmkwifi.WifiDaemon "/proc/$old/cmdline" 2>/dev/null && kill "$old" 2>/dev/null ;;
    esac
    rm -f "$DIR/daemon.pid"
fi
echo $$ > "$DIR/daemon.pid"
chmod 0644 "$DIR/daemon.pid"
bootline daemon-exec
ANDROID_DATA="$PKG/var" CLASSPATH="$PKG/bin/jmkwifi.dex" exec /system/bin/app_process /system/bin jmkwifi.WifiDaemon \
    </dev/null >>"$DIR/daemon.log" 2>&1
