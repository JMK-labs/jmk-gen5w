#!/system/bin/sh
# legacy-preflight.sh: what can fail AFTER the legacy package is removed, tried BEFORE anything is removed (MAP's migration runner, migrate.meta: preflight=scripts/legacy-preflight.sh, run as root from the
# unpacked new zip: `sh <folder>/scripts/legacy-preflight.sh`, no arguments, before the restore). It writes nothing but one temp file, which it removes. The LAST line is always `legacy-preflight: <summary>`.
#   exit 0  everything that can be proven now is fine (or there is nothing to prove: no stock source on this car, the restore step then decides)
#   exit 31 a file of the package is missing, or a gate piece is not the pinned file (md5): the exec tool, the three gate pieces, the dex, the drivers
#   exit 32 NEMESIS is older than 1.17 (the [patch.1] section would be ignored)
#   exit 33 the exec tool (bin/lp-gate) does not give what it must on THIS device (the stock file, or a copy of the P2 file, does not become the pinned gated file): the dd / md5 / cat applets
#   exit 34 /data has less than 115 MB free: NEMESIS refuses a LivePatch install with "Not enough space on /data" (exit 25) below 100 MB + the size of the targets (livepatch.c lp_check), and the install after
#           the uninstall needs the package too (LY3LOBUL 2026-11-28: 105.5 MB free, the install failed twice after the legacy package was gone; the updater's old zips held 525 MB). Free the space first.
# The dry run uses a stock copy: the library itself when it is stock, else the 1.x package's stock backup; a gated, P2 or unreadable library without a backup cannot prove the tool, the restore
# (exit 21 there) and the install then decide, both before anything is removed. Test seam: LR_ROOT prefixes /system and /data.
STOCK=f81b0eb4b392bc766e0bcc1488272e0e
P2=ef847b5075e01067a071c59434a9ac44
GATED=257a8a42268916576a16816219ea929c
R="${LR_ROOT:-}"
LIB="$R/system/lib/libhardware_legacy.so"
BK="$R/data/nemesis/backups/jmk-wifi/libhardware_legacy.so"
here="${0%/*}"
pkg="$here/.."
last="started"; tmpout=""
say() { last="$*"; echo "LegacyPreflight: $*"; }
sum() { set -- $(md5 "$1" 2>/dev/null); echo "$1"; }
fin() { rm -f "$tmpout" "$tmpout.part" "$tmpout.part.1" "$tmpout.part.2" "$tmpout.part.3"; echo "legacy-preflight: $last"; }
trap fin EXIT
# 1) the package's files
for f in bin/lp-gate bin/gate-site.bin bin/gate-cave.bin scripts/stock-site.bin scripts/legacy-restore.sh scripts/legacy-verify.sh bin/jmkwifi.dex bin/88x2bu.ko bin/8851bu.ko NEMESIS.data; do
    [ -s "$pkg/$f" ] || { say "the package file $f is missing"; exit 31; }
done
# the three gate pieces are pinned BYTES: their md5s (the packer asserts the same; a wrong size or content changes the md5). No `ls -l` column parsing: the car's toolbox ls has no link-count column (LY3LOBUL 2026-11-28),
# and the car has no wc / stat / awk / sed / head / tail / cut / tr / printf (the car's command set)
lastl() { while read -r l; do r="$l"; done; echo "$r"; }
[ "$(sum "$pkg/bin/gate-site.bin")" = 4166cb2433b5b25b14835650865737c4 ] && [ "$(sum "$pkg/bin/gate-cave.bin")" = 4994904add1c1f4a2db36c13ebb2f2cd ] && [ "$(sum "$pkg/scripts/stock-site.bin")" = d0c325cbe4a99e16f1de659844938368 ] \
    || { say "a gate piece is not the pinned file (bin/gate-site.bin, bin/gate-cave.bin, scripts/stock-site.bin: md5)"; exit 31; }
# 2) NEMESIS 1.17 or newer
nv=$(nemesis version 2>/dev/null)
nv1="${nv%%
*}"; ma="${nv1%%.*}"; rest="${nv1#*.}"; mi="${rest%%.*}"
case "$ma$mi" in ""|*[!0-9]*) say "NEMESIS 1.17 or newer is needed (found ${nv1:-none})"; exit 32 ;; esac
case "$nv1" in *.*) ;; *) say "NEMESIS 1.17 or newer is needed (found ${nv1:-none})"; exit 32 ;; esac
if [ "$ma" -lt 1 ] || { [ "$ma" -eq 1 ] && [ "$mi" -lt 17 ]; }; then say "NEMESIS 1.17 or newer is needed (found $nv1)"; exit 32; fi
# 2b) free space on /data. The car's toolbox df prints a table (LY3LOBUL 2026-11-28 03:58):
#       Filesystem               Size     Used     Free   Blksize
#       /data                  991.9M   517.4M   474.5M   4096
#     (the free space is the column headed Free); the older toolbox prints "/data: <total>M total, <used>M used, <free>M available (block size N)" (the word before "available"). Units K, M or G.
#     Unreadable = not judged (NEMESIS's own check still applies).
NEED_MB=115
dfout=$(df "${LR_DATA:-/data}" 2>/dev/null)
dffree() {
    read -r h; read -r d; i=0; col=0
    for w in $h; do
        i=$((i + 1))
        case "$w" in Free|free|Avail|Available|avail|available) col=$i ;; esac
    done
    if [ $col -gt 0 ]; then set -- $d; eval "echo \${$col}"; fi
}
freemb=$(echo "$dfout" | dffree)
if [ -z "$freemb" ]; then
    prev=""
    for w in $dfout; do
        case "$w" in available*) freemb="$prev"; break ;; esac
        prev="$w"
    done
fi
if [ -n "$freemb" ]; then
    num="${freemb%%[!0-9]*}"; unit="${freemb#"${freemb%%[!0-9.]*}"}"
    case "$num" in ""|*[!0-9]*) num="" ;; esac
    case "$unit" in G*) [ -n "$num" ] && num=$((num * 1024)) ;; K*) [ -n "$num" ] && num=$((num / 1024)) ;; M*|"") ;; B*) [ -n "$num" ] && num=$((num / 1048576)) ;; *) num="" ;; esac
    if [ -n "$num" ] && [ "$num" -lt $NEED_MB ]; then say "/data has $freemb free, the install needs $NEED_MB M (NEMESIS: 100 MB + the targets + the package): free space first (the updater's old zips, old test files)"; exit 34; fi
fi
# 3) the exec tool on this device, on a stock copy
cur=$(sum "$LIB"); src=""; want=0
# bin/lp-gate refuses a legacy-edited input (gated or P2: exit 1), so those libraries cannot be the dry-run source: the 1.x stock backup is, when there is one
case "$cur" in
$STOCK) src="$LIB"; want=0 ;;
$P2|$GATED) [ "$(sum "$BK")" = "$STOCK" ] && { src="$BK"; want=0; } ;;
"") ;;
*) src="$LIB"; want=10 ;;   # another firmware's file: the tool must pass it through
esac
if [ -z "$src" ]; then say "no stock source on this car (library ${cur:-unreadable}, no usable backup): the exec tool is not tried here; the restore and the install decide"; exit 0; fi
tmpout="${JMK_TMP:-/data/local/tmp}/jmk-lpgate-dry.$$"
rm -f "$tmpout"
out=$(sh "$pkg/bin/lp-gate" "$src" "$tmpout" 2>&1); rc=$?
lastline=$(echo "$out" | lastl)
[ $rc -eq $want ] || { say "bin/lp-gate gave exit $rc, expected $want ($lastline)"; exit 33; }
if [ $want -eq 0 ]; then [ "$(sum "$tmpout")" = "$GATED" ] || { say "bin/lp-gate wrote $(sum "$tmpout"), not the pinned gated file"; exit 33; }; fi
say "ok: the package is complete, NEMESIS $nv1, /data ${freemb:-?} free, bin/lp-gate on $([ $want -eq 0 ] && echo "a stock copy gives the pinned gated file" || echo "this firmware's library passes through)")"
exit 0
