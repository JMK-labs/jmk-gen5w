#!/system/bin/sh
# legacy-verify.sh: "the files are stock" for MAP's migration runner (migrate.meta: verify=scripts/legacy-verify.sh). Exit 0 = the library under LivePatch's outputs is NOT one of ours
# (stock, or another firmware's file we never touched); exit 1 = it is still a 1.4.x P2 or a 1.5.x gated file of this package. One line on stdout says why. Writes NOTHING.
# "Under LivePatch's outputs": when LivePatch has a row for the library, its recorded stock md5 counts (the path shows our mounted gate then, which is not a legacy file).
# Test seam: LR_ROOT prefixes /system and /data.
P2=ef847b5075e01067a071c59434a9ac44
GATED=257a8a42268916576a16816219ea929c
R="${LR_ROOT:-}"
LIB="$R/system/lib/libhardware_legacy.so"
TABLE="$R/data/nemesis/livepatch/table"
cur=""
if [ -f "$TABLE" ]; then
    while read -r t o s x; do [ "$t" = "/system/lib/libhardware_legacy.so" ] && cur="$s"; done < "$TABLE"
fi
[ -n "$cur" ] || { set -- $(md5 "$LIB" 2>/dev/null); cur="$1"; }
case "$cur" in
$P2) echo "/system/lib/libhardware_legacy.so is the 1.4.x P2 file (md5 $cur)"; exit 1 ;;
$GATED) echo "/system/lib/libhardware_legacy.so is the 1.5.x gated file (md5 $cur)"; exit 1 ;;
"") echo "/system/lib/libhardware_legacy.so is unreadable: nothing of ours to restore"; exit 0 ;;
*) echo "/system/lib/libhardware_legacy.so is not a file of this package (md5 $cur)"; exit 0 ;;
esac
