#!/system/bin/sh
# 1.5.0: preuninstall is Java (jmkwifi.WifiOps preuninstall): stops the daemon and, on a real uninstall, puts the stock library
# back. It NEVER blocks the uninstall (QA v2 N5): a step that cannot run is only said; the removal goes on. If the step cannot run (no dex, no
# app_process, a failed start), the daemon is still stopped here (pid file + a check that the pid runs our class): the package folder goes away under
# it. A library left gated and the stock client setting left as it is are harmless.
export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
trap '' HUP INT PIPE
DIR=/data/local/tmp/jmk-wifi
PARENTCMD=/proc/$PPID/cmdline
STAGEFILE=/data/local/tmp/nemesis/stage/jmk-wifi/NEMESIS.data
# 1.5.4: a real uninstall, or the old package's uninstall step inside an update (NEMESIS runs it with the new package staged)? Decided HERE, as it was in 1.4.x
# (common.sh real_uninstall): $PPID is the parent of THIS script = NEMESIS. The Java step cannot ask its own parent: that is this script, whose command line always
# says "uninstall", so 1.5.0 - 1.5.3 took every update for a real uninstall (the stock library put back, the stock Wi-Fi setting restored). 1 = real, 0 = an update.
real_uninstall() {
    case "$(cat $PARENTCMD 2>/dev/null)" in *uninstall*) echo 1; return 0 ;; esac
    if grep -q '^id=jmk-wifi$' $STAGEFILE 2>/dev/null; then echo 0; else echo 1; fi
}
stop_daemon() {
    [ -f "$DIR/daemon.pid" ] || return 0
    read -r pid < "$DIR/daemon.pid" || pid=
    case "$pid" in
        ''|*[!0-9]*) ;;
        *) grep -q jmkwifi.WifiDaemon "/proc/$pid/cmdline" 2>/dev/null && kill "$pid" 2>/dev/null ;;
    esac
    rm -f "$DIR/daemon.pid"
}
rc=1
if [ -f ./bin/jmkwifi.dex ]; then
    mkdir -p ./var/dalvik-cache
    JMK_REAL_UNINSTALL=$(real_uninstall) ANDROID_DATA="$PWD/var" CLASSPATH=./bin/jmkwifi.dex /system/bin/app_process /system/bin jmkwifi.WifiOps preuninstall
    rc=$?
    echo "preuninstall: rc $rc"
else
    echo "preuninstall: bin/jmkwifi.dex missing: nothing done, the removal goes on"
fi
[ "$rc" = 0 ] || { echo "preuninstall: the step did not run: stopping the daemon from the shell"; stop_daemon; }
exit 0
