#!/system/bin/sh
# 1.5.0: the work of this hook is Java (postinstall in jmkwifi.WifiOps, run from this package's folder; the staged one for the
# preinstall). NEMESIS runs the hook as root (without CAP_DAC_OVERRIDE for /data/local/tmp) with the package folder as the current directory, so the
# dex cache lives in ./var like the boot service's. A refusal or a failure is the step's exit code.
export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
trap '' HUP INT PIPE   # a hook started over adb runs in adbd's session: a pulled cable or a host timeout must not stop it halfway
mkdir -p ./var/dalvik-cache
[ -f ./bin/jmkwifi.dex ] || { echo "FAIL: bin/jmkwifi.dex missing"; exit 1; }
ANDROID_DATA="$PWD/var" CLASSPATH=./bin/jmkwifi.dex exec /system/bin/app_process /system/bin jmkwifi.WifiOps postinstall
