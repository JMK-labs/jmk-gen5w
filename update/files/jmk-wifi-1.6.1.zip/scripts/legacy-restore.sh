#!/system/bin/sh
# legacy-restore.sh: puts /system/lib/libhardware_legacy.so back to the stock file BEFORE the LivePatch build of jmk-wifi is installed (LivePatch takes the file under its
# outputs as "stock": a gated 1.5.x or P2 1.4.x file left there would become part of stock). MAP's migration runner (migrate.meta: restore=scripts/legacy-restore.sh) runs it from the
# unpacked new zip as root: `sh <folder>/scripts/legacy-restore.sh`, no arguments. mksh + toolbox only (md5, dd, cat, cp, mv, chmod, sync, rm); pieces are cut with dd bs=1 skip/count.
# The LAST output line is always `legacy-restore: <summary>`. Idempotent.
#   exit 0  restored (P2 or gated -> stock, md5 verified)        exit 10 nothing to do (already stock, or another library: left alone; the line says which)
#   exit 21 ours but no usable stock copy                          exit 22 remount / swap failed          exit 23 the restored file has the wrong md5 (nothing replaced)
#   (exit 0 and 10 also leave STORE/migrating for the new package's preinstall: PROCESS-FLOWS 1e)
#   exit 24 LivePatch's own row recorded our file as its stock (a mis-migrated car): it cannot be fixed under LivePatch's mount; uninstall, restore, install
# "The library" is the file UNDER LivePatch's outputs: when LivePatch has a row for it, the stock md5 it recorded counts (the path then shows our mounted gate, which is not a legacy file).
# Test seams (the car leaves them empty): LR_ROOT prefixes /system and /data, LR_MOUNTS is the mount table.
STOCK=f81b0eb4b392bc766e0bcc1488272e0e
P2=ef847b5075e01067a071c59434a9ac44
GATED=257a8a42268916576a16816219ea929c
SITE=17112; SITE_END=17116; CAVE=22308; CAVE_END=22356
R="${LR_ROOT:-}"
LIB="$R/system/lib/libhardware_legacy.so"
TABLE="$R/data/nemesis/livepatch/table"
BK="$R/data/nemesis/backups/jmk-wifi/libhardware_legacy.so"
MOUNTS="${LR_MOUNTS:-/proc/mounts}"
here="${0%/*}"
tmp="$LIB.jmk-restore"
wasro=0; last="started"
say() { last="$*"; echo "LegacyRestore: $*"; }
sum() { set -- $(md5 "$1" 2>/dev/null); echo "$1"; }
fin() {
    rc=$?
    rm -f "$tmp" "$tmp.1" "$tmp.2" "$tmp.3"
    if [ $wasro -eq 1 ]; then sync; nemesis remount ro >/dev/null 2>&1; fi
    # the migration marker (read by the new package's preinstall, deleted by its postinstall): the install that follows replaces a legacy package of a car that ran it; written only when this step let the migration go on
    if [ $rc -eq 0 ] || [ $rc -eq 10 ]; then [ -d "$R/data/nemesis/jmk-wifi" ] && echo 1 > "$R/data/nemesis/jmk-wifi/migrating"; fi
    echo "legacy-restore: $last"
}
trap fin EXIT
viarow=0; cur=""
if [ -f "$TABLE" ]; then
    while read -r t o s x; do [ "$t" = "/system/lib/libhardware_legacy.so" ] && cur="$s"; done < "$TABLE"
    [ -n "$cur" ] && viarow=1
fi
[ -n "$cur" ] || cur=$(sum "$LIB")
case "$cur" in
$STOCK) say "already stock"; exit 10 ;;
$P2|$GATED) [ $viarow -eq 1 ] && { say "LivePatch recorded our file ($cur) as its stock: uninstall, restore under no mount, install"; exit 24; } ;;
*) say "other library ${cur:-unreadable}, left alone"; exit 10 ;;
esac
# /system is read-only on the car: the temp file beside the library needs it read-write first; fin() puts it back on every way out
case " $(while read -r a b c d e; do [ "$b" = "/system" ] && echo ",$d,"; done < "$MOUNTS") " in *,rw,*) ;; *) wasro=1 ;; esac
if [ $wasro -eq 1 ]; then nemesis remount rw >/dev/null 2>&1 || { wasro=0; say "remount rw failed"; exit 22; }; fi
rm -f "$tmp" "$tmp.1" "$tmp.2" "$tmp.3"
if [ "$cur" = "$P2" ]; then
    [ -s "$here/stock-site.bin" ] || { say "missing stock-site.bin"; exit 21; }
    { dd if="$LIB" of="$tmp.1" bs=1 count=$SITE && dd if="$LIB" of="$tmp.2" bs=1 skip=$SITE_END && cat "$tmp.1" "$here/stock-site.bin" "$tmp.2" > "$tmp"; } >/dev/null 2>&1 \
        || { say "cutting the P2 file failed"; exit 22; }
    rm -f "$tmp.1" "$tmp.2"
    echo "LegacyRestore: P2 file: the four stock bytes put back"
else
    if [ "$(sum "$BK")" = "$STOCK" ]; then
        cp "$BK" "$tmp" || { say "copy of the stock backup failed"; exit 22; }
        echo "LegacyRestore: gated file: the stock copy of the backup folder is used"
    elif [ -s "$here/stock-site.bin" ] && [ -s "$here/stock-cave.bin" ]; then
        { dd if="$LIB" of="$tmp.1" bs=1 count=$SITE && dd if="$LIB" of="$tmp.2" bs=1 skip=$SITE_END count=$((CAVE - SITE_END)) && dd if="$LIB" of="$tmp.3" bs=1 skip=$CAVE_END \
            && cat "$tmp.1" "$here/stock-site.bin" "$tmp.2" "$here/stock-cave.bin" "$tmp.3" > "$tmp"; } >/dev/null 2>&1 \
            || { say "cutting the gated file failed"; exit 22; }
        rm -f "$tmp.1" "$tmp.2" "$tmp.3"
        echo "LegacyRestore: gated file: rebuilt from the file and the shipped stock bytes"
    else
        say "gated file and no usable stock copy (backup $(sum "$BK"))"; exit 21
    fi
fi
got=$(sum "$tmp")
[ "$got" = "$STOCK" ] || { say "the restored file is ${got:-unreadable}, not the stock $STOCK: nothing replaced"; exit 23; }
chmod 0644 "$tmp" 2>/dev/null
mv "$tmp" "$LIB" 2>/dev/null || { say "the swap failed (the temp file could not be moved over the library)"; exit 22; }
[ "$(sum "$LIB")" = "$STOCK" ] || { say "after the swap the library is $(sum "$LIB")"; exit 23; }
say "stock libhardware_legacy.so restored (was $cur; takes effect at the next boot)"
exit 0
