#!/system/bin/sh
# NEMESIS service (root): the MAP key watcher and camping daemon (jmkmap.MapDaemon). NEMESIS starts it at
# boot and right after every update; an older daemon is stopped first. After an update started from adb this runs
# as root without capabilities: the Dalvik cache therefore lives in the package (ANDROID_DATA), not /data/dalvik-cache.
# (mksh: single-digit fds only; no sed/head/tail on this firmware)
export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
PKG=/data/nemesis/apps/jmk-map-menu
[ -d "$PKG" ] || PKG=/data/nemesis/packages/jmk-map-menu
DIR=/data/local/tmp/jmk-map-menu
# started by an install from `adb shell`, this script shares that session: it was killed when the session closed
# (hangup, or writing to the gone terminal), mostly before the daemon was up (car 2026-11-10). Ignore the hangup
# (the daemon inherits that) and keep all output off the terminal.
trap '' HUP
mkdir -p "$PKG/var"
exec </dev/null >"$PKG/var/svc.log" 2>&1   # the latest start only
echo "$(date) start $$"
# the shared dir must be world-writable (the app, the uid-1000 ambient worker and this daemon all write there), and
# sticky (1777 since 2.1.0): nobody replaces or deletes another uid's file; each reader also checks whose a file is.
# /data/local/tmp is 0771 shell:shell after boot: root without capabilities can't create in it, so ask the shell user.
mkdir -p "$DIR" 2>/dev/null || /system/xbin/nemesis root 2000 -c "mkdir -p $DIR" </dev/null >/dev/null 2>&1
chmod 1777 "$DIR" 2>/dev/null || /system/xbin/nemesis root 2000 -c "chmod 1777 $DIR" </dev/null >/dev/null 2>&1
# the pid file survives a reboot (/data): only kill that pid while it is still our daemon, not whatever got the number
if [ -f "$DIR/daemon.pid" ]; then
    read -r old < "$DIR/daemon.pid" || old=
    case "$old" in
        ''|*[!0-9]*) ;;
        *) grep -q jmkmap.MapDaemon "/proc/$old/cmdline" 2>/dev/null && kill "$old" 2>/dev/null ;;
    esac
    rm -f "$DIR/daemon.pid"
fi
i=0
while [ "$(getprop sys.boot_completed)" != 1 ] && [ $i -lt 150 ]; do sleep 2; i=$((i + 1)); done
# 2.3.70: the icon app for the NEMESIS Manager's first screen, once Android is up (a package installed before the boot finished,
# or an earlier failure); in the background, never part of the daemon's start, always exits 0 (scripts/icon.sh)
[ -f "$PKG/scripts/icon.sh" ] && { sh "$PKG/scripts/icon.sh" </dev/null >/dev/null 2>&1 & }
# wireless adb (taken over from the usb.mode package): adbd also on TCP 5555, accepted only on the dongle's client port (rtwlan*, its
# number moves on a replug) and lo; key auth stays on, the developer's key is in the package (adbkey.pub). Java since 2.4.0 (Ops wireless-adb);
# needs capabilities (boot); after an adb install it fails quietly and the rules from the boot stay.
ANDROID_DATA="$PKG/var" CLASSPATH="$PKG/bin/mapmenu.dex" /system/bin/app_process /system/bin jmkmap.Ops wireless-adb "$PKG" </dev/null >>"$PKG/var/svc.log" 2>&1
mkdir -p "$PKG/var/dalvik-cache"
[ -f "$DIR/daemon.log" ] && mv "$DIR/daemon.log" "$DIR/daemon.log.old"
echo "$(date) daemon $$"
echo $$ > "$DIR/daemon.pid"
chmod 0644 "$DIR/daemon.pid"
ANDROID_DATA="$PKG/var" CLASSPATH="$PKG/bin/mapmenu.dex" exec /system/bin/app_process /system/bin jmkmap.MapDaemon \
    </dev/null >>"$DIR/daemon.log" 2>&1
