#!/system/bin/sh
# NEMESIS service (root): our driver (88x2bu; 1.4.0: 8851bu for AX900-class dongles), then the JMK Wi-Fi daemon.
# The driver goes in first and as early as possible: its usbfs block must be in place before Android's USB host
# service sees the dongle (else the stock Android Auto service probes it as a phone). Port names: wlan0 for the stock
# Wi-Fi stack's hotspot, rtwlan0 for our client (usb.mode lets adb in on rtwlan* only).
# Never rmmod it (that rebooted the head unit) and never call it bcmdhd (the stock stack rmmods that name).
# After an update started from adb this runs as root without capabilities: insmod is then impossible, and the
# daemon keeps what the previous one left running until the next boot.
# (mksh: single-digit fds only; no sed/head/tail on this firmware)
export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
PKG=/data/nemesis/apps/jmk-wifi
[ -d "$PKG" ] || PKG=/data/nemesis/packages/jmk-wifi
DIR=/data/local/tmp/jmk-wifi
ARGS='ifname=wlan%d if2name=rtwlan%d rtw_country_code=KR rtw_power_mgnt=0 rtw_ips_mode=0 rtw_enusbss=0 rtw_en_napi=0 rtw_en_gro=0'
# 1.4.0: the AX900-class driver (RTL8851BU / RTL8831BU): no power-save parameters there, its IPS/LPS are not built in
# (CONFIG_RTW_IPS / CONFIG_RTW_LPS off in its autoconf.h); rtw_usbfs_block is our patch 0003
ARGS_8851='ifname=wlan%d if2name=rtwlan%d rtw_country_code=KR rtw_en_napi=0 rtw_en_gro=0 rtw_usbfs_block=1'
STORE=/data/nemesis/jmk-wifi
# exactly 8851bu.ko's own table (driver patch 0005, the build's "USB IDs:" line); another AX chip stays unsupported
AX_IDS=' 0bda:b851 0bda:b831 3625:010b 2c4e:0128 2001:332a 7392:e611 '
VCD_IDS=' 0bda:1a2b 0bda:1a2c '
# RTL88x2BU dongles the 88x2bu driver takes (with one of these in, it is the driver: the proven one wins)
BU_IDS=' 0bda:b812 0bda:b82c 0bda:b81a 0bda:b820 0bda:b82b 2357:012d 2357:012e 2357:0138 2357:0115 0b05:184c 0b05:1841 0b05:19aa 7392:b822 7392:c822 2001:331c 2001:331e 0846:9055 13b1:0043 056e:4011 '
# vendor:product of every USB device, one string (no tr / sed on this firmware)
usb_ids() {
    ids=' '
    for d in /sys/bus/usb/devices/*; do
        [ -r "$d/idVendor" ] && [ -r "$d/idProduct" ] || continue
        read -r v < "$d/idVendor"; read -r p < "$d/idProduct"
        ids="$ids$v:$p "
    done
    echo "$ids"
}
any_of() { for i in $2; do case "$1" in *" $i "*) return 0 ;; esac; done; return 1; }
# "client" mode (the preinstall saw a stock Wi-Fi module): wlan0 belongs to the stock module, so both of our ports are
# rtwlan (the jmk.usbwifi names) and the daemon only runs the phone-hotspot client
mode=
[ -f /data/nemesis/jmk-wifi/mode ] && read -r mode < /data/nemesis/jmk-wifi/mode
[ "$mode" = client ] && ARGS="ifname=rtwlan%d ${ARGS#ifname=wlan%d }" && ARGS_8851="ifname=rtwlan%d ${ARGS_8851#ifname=wlan%d }"

# "locked" (1.3.6, the preinstall decided: another model whose kernel or library does not fit): never insmod there, no
# daemon; only the status, so that the MAP menu shows 이 차종 미지원 (pid= empty: not running)
if [ "$mode" = locked ]; then
    why=
    [ -f /data/nemesis/jmk-wifi/locked ] && read -r why < /data/nemesis/jmk-wifi/locked
    if mkdir -p "$DIR" 2>/dev/null; then chmod 0755 "$DIR"; else /system/xbin/nemesis root 2000 -c "mkdir -p $DIR; chmod 0777 $DIR" </dev/null >/dev/null 2>&1; fi
    rm -f "$DIR/status.new"
    { echo "mode=locked"; echo "locked=$why"; echo "pid="; } > "$DIR/status.new" && chmod 0644 "$DIR/status.new" && mv "$DIR/status.new" "$DIR/status"
    echo "locked: no driver on this model ($why)" > "$DIR/driver.txt"
    exit 0
fi

# 1.4.0: a dongle that shows as its Windows driver disk (virtual CD) is told to switch first; it comes back as the
# Wi-Fi device a moment later
note=
ids=$(usb_ids)
# 1.4.1 (AX900 owners, 2026-11-18): at 3 s of uptime the dongle was often not on the bus yet (the reports saw 0bda:b831
# later), so 88x2bu went in and the AX900 stayed without a driver. Up to 4 s more for a known dongle to show.
n=0
while [ $n -lt 4 ] && ! any_of "$ids" "$BU_IDS $AX_IDS $VCD_IDS"; do sleep 1; n=$((n + 1)); ids=$(usb_ids); done   # whole seconds: toolbox sleep
[ $n -gt 0 ] && note="waited $n s for the dongle"
if any_of "$ids" "$VCD_IDS" && [ -x "$PKG/bin/jmkiw" ]; then
    note="eject: $("$PKG/bin/jmkiw" eject 2>&1)"
    n=0
    while [ $n -lt 16 ]; do
        sleep 0.5; n=$((n + 1))
        ids=$(usb_ids)
        any_of "$ids" "$VCD_IDS" || break
    done
    note="$note; after $((n / 2)) s: $(any_of "$ids" "$VCD_IDS" && echo 'still a CD' || echo 'switched')"
fi
# which driver: 8851bu when an AX900-class dongle is in, else 88x2bu (as before: also with no dongle yet, for a later
# plug of an RTL88x2BU one). 8851bu is a trial: two boots in a row that do not get 3 minutes past its insmod turn it off
# (the daemon reports that), so a module that hangs this kernel cannot keep the head unit from starting.
drv=88x2bu
# 1.4.8 (QA 2026-11-19, an EV6 owner 2026-11-20): a new package version starts the guard again (a car whose 1.4.7 or
# older guard had turned the driver off after two short drives gets it back with the update); the daemon resets it
# as soon as this driver made its network port (WifiDaemon.axWorked), no timer any more
ver=
while IFS='=' read -r k v; do [ "$k" = package-version ] && ver=$v; done < "$PKG/NEMESIS.data"
seenver=; [ -f "$STORE/8851bu-ver" ] && read -r seenver < "$STORE/8851bu-ver"
if [ -n "$ver" ] && [ "$ver" != "$seenver" ]; then
    mkdir -p "$STORE" && echo 0 > "$STORE/8851bu-tries" && echo "$ver" > "$STORE/8851bu-ver"
fi
if any_of "$ids" "$AX_IDS" && ! any_of "$ids" "$BU_IDS"; then
    tries=0
    [ -f "$STORE/8851bu-tries" ] && read -r tries < "$STORE/8851bu-tries"
    case "$tries" in ''|*[!0-9]*) tries=0 ;; esac
    if [ "$tries" -ge 2 ]; then
        note="$note${note:+; }8851bu off: $tries boots did not get past it"
    else
        drv=8851bu
        mkdir -p "$STORE" && echo $((tries + 1)) > "$STORE/8851bu-tries" && sync
    fi
fi
loaded=
err=
while read -r name rest; do
    [ "$name" = "$drv" ] && loaded=1
done < /proc/modules
if [ -z "$loaded" ]; then
    if [ "$drv" = 8851bu ]; then
        err=$(insmod "$PKG/bin/8851bu.ko" $ARGS_8851 2>&1)
    else
        err=$(insmod "$PKG/bin/88x2bu.ko" $ARGS 2>&1)   # 1.3.7: its error text goes into driver.txt (the daemon's report)
    fi
    rc=$?
else
    rc=loaded
fi
read -r up idle < /proc/uptime

# status and logs: root's dir, readable by all (0755), so nobody can swap a log for a symlink; requests from the menu
# app go into req/ (1777). /data/local/tmp is 0771 shell:shell after boot, and root without capabilities can't create
# in it, so ask the shell user then (that dir then stays the shell's, 0777).
if mkdir -p "$DIR" 2>/dev/null; then
    chmod 0755 "$DIR"
else
    /system/xbin/nemesis root 2000 -c "mkdir -p $DIR; chmod 0777 $DIR" </dev/null >/dev/null 2>&1
fi
mkdir -p "$DIR/req" 2>/dev/null && chmod 1777 "$DIR/req"
echo "uptime $up: insmod $rc (mode ${mode:-emulate}) driver $drv${note:+; $note}" > "$DIR/driver.txt"
case "$rc" in 0|loaded) ;; *) [ -n "$err" ] && echo "insmod error: $err" >> "$DIR/driver.txt" ;; esac

# 1.4.1: an AX900-class dongle that comes on the bus after this (still enumerating, or its virtual CD switched late):
# for 90 s, switch a CD and put 8851bu in (the same two-failed-boots guard); it binds only the AX ids
if [ "$drv" = 88x2bu ] && [ "$mode" != client ]; then
    (
        n=0
        while [ $n -lt 90 ]; do
            sleep 1; n=$((n + 1))
            ids=$(usb_ids)
            any_of "$ids" "$BU_IDS" && break
            if any_of "$ids" "$VCD_IDS" && [ -x "$PKG/bin/jmkiw" ]; then "$PKG/bin/jmkiw" eject >/dev/null 2>&1; continue; fi
            any_of "$ids" "$AX_IDS" || continue
            tries=0
            [ -f "$STORE/8851bu-tries" ] && read -r tries < "$STORE/8851bu-tries"
            case "$tries" in ''|*[!0-9]*) tries=0 ;; esac
            if [ "$tries" -ge 2 ]; then echo "late AX dongle at ${n} s: 8851bu off ($tries boots did not get past it)" >> "$DIR/driver.txt"; break; fi
            mkdir -p "$STORE" && echo $((tries + 1)) > "$STORE/8851bu-tries" && sync
            err=$(insmod "$PKG/bin/8851bu.ko" $ARGS_8851 2>&1); rc=$?
            echo "late AX dongle at ${n} s: insmod 8851bu $rc${err:+ ($err)}" >> "$DIR/driver.txt"
            break
        done
    ) </dev/null >/dev/null 2>&1 &
fi

if [ -f "$DIR/daemon.pid" ]; then
    read -r old < "$DIR/daemon.pid" || old=
    case "$old" in
        ''|*[!0-9]*) ;;
        *) grep -q jmkwifi.WifiDaemon "/proc/$old/cmdline" 2>/dev/null && kill "$old" 2>/dev/null ;;
    esac
    rm -f "$DIR/daemon.pid"
fi
mkdir -p "$PKG/var/dalvik-cache"
[ -f "$DIR/daemon.log" ] && mv "$DIR/daemon.log" "$DIR/daemon.log.old"
echo $$ > "$DIR/daemon.pid"
chmod 0644 "$DIR/daemon.pid"
ANDROID_DATA="$PKG/var" CLASSPATH="$PKG/bin/jmkwifi.dex" exec /system/bin/app_process /system/bin jmkwifi.WifiDaemon \
    </dev/null >>"$DIR/daemon.log" 2>&1
