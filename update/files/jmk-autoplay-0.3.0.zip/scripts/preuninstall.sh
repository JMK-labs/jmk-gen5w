#!/system/bin/sh
# Stops the daemon. On a real uninstall it puts back exactly what we changed: the cfg lines we commented, the files we
# added, the properties' earlier values (a reboot applies it). NEMESIS runs this before every update too: then the
# changes stay (the new postinstall finds them in place).
# 0.3.0: Wireless AutoPlay comes as a pair with its HUD · 계기판 길안내 add-on (jmk-autoplay-hud, a package of its own,
# AGPL-3.0, depends on this one). The JMK MAP menu removes the add-on first; uninstalled here by hand (NEMESIS Manager)
# while the add-on is still there, its patched stock apps stay behind without these features: a clear warning (a hook
# never runs nemesis itself).
. ./scripts/common.sh
log "preuninstall jmk-autoplay"
stop_daemon
real_uninstall || exit 0
if hud=$(hud_addon); then
    log "WARNING: JMK AutoPlay 확장(jmk-autoplay-hud)이 아직 설치되어 있습니다 ($hud). 그 확장이 바꾼 순정 앱은 그대로 남습니다: NEMESIS Manager에서 jmk-autoplay-hud도 제거하고 재부팅하세요 (the add-on's patched stock apps stay until it is uninstalled too)"
    sh_report preuninstall-hud-left "$hud"
fi
if [ -f $COMMENTED ] || [ -f $ADDED ]; then
    if rw_begin; then
        cfg_rewrite off || log "WARNING: featurexml.cfg not restored"
        if [ -f $ADDED ]; then
            while read -r f; do case "$f" in $PERM/*.xml) rm -f "$R$f" ;; esac; done < $ADDED
        fi
        rw_end
    else
        log "WARNING: /system read-only, the features stay until a reinstall/uninstall with /system writable"
        sh_report preuninstall-system-ro "$(grep ' /system ' /proc/mounts)"
        rw_end
    fi
fi
props_restore
rm -f $COMMENTED $ADDED $PROPS_BEFORE $LOCKED $INSTALLED
log "uninstalled: stock features back (reboot to apply)"
exit 0
