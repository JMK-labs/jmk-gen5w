#!/system/bin/sh
# jmk-autoplay, shared by the hooks. NEMESIS runs them as root with the package folder as the current directory.
# (this head unit's mksh: single-digit fds only; no sed/head/tail/printf; toolbox grep, md5, cmp exist)
export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
# a hook started over adb runs in adbd's session: a pulled cable or a host timeout must not stop it halfway
trap '' HUP INT PIPE
# R: a sandbox root for test/scripts-test.sh on the Mac only. Empty on the car, where every path is the real one.
R=${JMK_AUTOPLAY_TEST_ROOT:-}
PKG=$R/data/nemesis/apps/jmk-autoplay
[ -d "$PKG" ] || PKG=$R/data/nemesis/packages/jmk-autoplay
DIR=$R/data/local/tmp/jmk-autoplay        # status and requests for the JMK MAP menu
STORE=$R/data/nemesis/jmk-autoplay        # our state (root only); outlives an uninstall
BACKUP=$R/data/nemesis/backups/jmk-autoplay   # stock copies of every file we change, restored by the uninstall
LOG=$R/data/nemesis/jmk-autoplay.log
INSTALLED=$STORE/installed              # there while installed: an update's preinstall knows it is one
REPORTED=$R/data/nemesis/jmk-autoplay.reported

log() { echo "$1"; echo "$(date) $1" >> $LOG 2>/dev/null; true; }

# A real uninstall, not the old package's uninstall step inside an update (NEMESIS runs the old preuninstall with the
# new package already staged).
real_uninstall() {
    case "$(cat /proc/$PPID/cmdline 2>/dev/null)" in *uninstall*) return 0 ;; esac
    grep -q '^id=jmk-autoplay$' $R/data/local/tmp/nemesis/stage/jmk-autoplay/NEMESIS.data 2>/dev/null && return 1
    return 0
}

# Another wireless CarPlay / Android Auto package (the MAP menu's rule, MapDaemon.projectionId): two of them would
# change the same stock files and features. Leafia (wireless.cp.aa.<fw>), Evergreen (wireless.carplay.aa), 단풍
# (danpung, danpung.update), Korea Projection, wireless.projection, projection.tbt, enhanced.projection, and an
# HMG-API wireless mod. Prints the first one found.
other_projection() {
    local d id
    for d in $R/data/nemesis/apps/* $R/data/nemesis/packages/*; do
        [ -d "$d" ] || continue
        id=${d##*/}
        case "$id" in
            jmk-*|jmk.*) continue ;;
            wireless.*|danpung*|aa.usbwifi|*carplay*|*projection*|*leafia*|*evergreen*|*androidauto*) echo "$id"; return 0 ;;
        esac
    done
    for d in $R/data/hmgapi/mods/*; do
        [ -d "$d" ] || continue
        case "${d##*/}" in *wireless*|*carplay*|*projection*) echo "HMG-API mod ${d##*/}"; return 0 ;; esac
    done
    return 1
}

# The HUD · 계기판 길안내 add-on (jmk-autoplay-hud, 0.3.0): prints its NEMESIS folder while it is installed.
hud_addon() {
    local d
    for d in $R/data/nemesis/apps/jmk-autoplay-hud $R/data/nemesis/packages/jmk-autoplay-hud; do
        [ -d "$d" ] && { echo "$d"; return 0; }
    done
    return 1
}

stop_daemon() {
    local pid
    [ -f "$DIR/daemon.pid" ] || return 0
    read -r pid < "$DIR/daemon.pid" || pid=
    case "$pid" in
        ''|*[!0-9]*) ;;
        *) grep -q jmkautoplay.AutoPlayDaemon "/proc/$pid/cmdline" 2>/dev/null && kill "$pid" 2>/dev/null ;;
    esac
    rm -f "$DIR/daemon.pid"
}

# One install report per version and category, through the JMK MAP menu's outbox (sent when the head unit is online
# and reports are on; the menu adds the car's code, firmware and versions and takes MAC and IP addresses out).
sh_report() {
    local cat="$1" detail="$2" ver= l box=$R/data/local/tmp/jmk-map-menu/outbox at tmp
    [ -d $box ] || return 0
    case "$cat" in ''|*[!a-z0-9-]*) return 0 ;; esac
    if [ -r ./NEMESIS.data ]; then
        while read -r l; do case "$l" in package-version=*) ver=${l#package-version=} ;; esac; done < ./NEMESIS.data
    fi
    case "$ver" in ''|*[!0-9.]*) return 0 ;; esac
    if [ -r $REPORTED ]; then
        while read -r l; do [ "$l" = "$ver $cat" ] && return 0; done < $REPORTED
    fi
    case "$detail" in *'"'*|*'\'*) detail='(detail not printable)' ;; esac
    set -f; set -- $detail; set +f; detail="$*"
    at=$(date +%s)000
    tmp=$box/.jmk-autoplay-install-$$.tmp
    echo "{\"kind\":\"jmk-report\",\"type\":\"install\",\"app\":\"jmk-autoplay\",\"ver\":\"$ver\",\"msg\":\"install: $cat\",\"detail\":\"$detail\",\"at\":$at}" > $tmp 2>/dev/null || { rm -f $tmp; return 0; }
    chmod 0644 $tmp
    mv $tmp $box/jmk-autoplay-install-$cat.json && echo "$ver $cat" >> $REPORTED
    return 0
}

# ---------------------------------------------------------------- 0.2.0: the stock wireless features
# The KOR firmware lists the wireless CarPlay, wireless Android Auto and hotspot permission files with "-" in
# <ro.mobis.targetdir>/featurexml.cfg, so PackageManager and com.hkmc.Feature drop them (read once per process: a reboot
# applies a change). We comment those three lines ("#-…") and add the two feature files the firmware does not ship.
# Every change is recorded, and a real uninstall puts back exactly what we changed (tools/jmk-autoplay/RESEARCH-core.md §1, §2).
PERM=/system/etc/permissions      # as the cfg names it (files on disk: $R$PERM)
F_AA=com.hkmc.software.connectivity.androidauto_wireless
F_CP=com.hkmc.software.connectivity.carplay_wireless
F_HS=com.hkmc.software.wifihotspot
COMMENTED=$STORE/commented        # the cfg lines we commented, as they were ("-/system/etc/permissions/….xml")
ADDED=$STORE/added                # the permission files we added (as /system/etc/permissions/….xml)
PROPS_BEFORE=$STORE/props.before  # "name=value" before we set them (first install only)
LOCKED=$STORE/locked              # why nothing was changed (another model, no cfg)
PROPS="persist.sys.iap2.wifi persist.iap2.iden.wireless"   # iAP2 asks the iPhone for Wi-Fi (the CarPlay feature alone does not)

md5of() { set -- $(md5 "$1" 2>/dev/null); echo "$1"; }

system_rw() {
    local dev mnt fs opts rest
    while read -r dev mnt fs opts rest; do
        [ "$mnt" = /system ] || continue
        case ",$opts," in *,rw,*) return 0 ;; esac
        return 1
    done < /proc/mounts
    return 1
}

# /system read-write for a moment if it was not (after boot it is rw by design: never leave it ro when it was rw)
WAS_RO=0
rw_begin() { WAS_RO=0; system_rw || { WAS_RO=1; /system/xbin/nemesis remount rw >/dev/null 2>&1; }; system_rw; }
rw_end() { sync; [ $WAS_RO -eq 1 ] && system_rw && /system/xbin/nemesis remount ro >/dev/null 2>&1; true; }

cfg_path() {
    local d
    d=$(getprop ro.mobis.targetdir)
    [ -n "$d" ] && [ -f "$R$d/featurexml.cfg" ] && echo "$R$d/featurexml.cfg"
}

# Our model (KR Ioniq 5) always; another one only once the signed update list names "projection" for it (the MAP
# menu writes car-ok, like Active Ambient's gate).
fits() {
    local p ok
    p=$(getprop ro.build.product)
    case "$p" in NEEV.KOR.*) return 0 ;; esac
    ok=$(cat $R/data/nemesis/jmk-updates/car-ok 2>/dev/null)
    case ",$ok," in *,projection,*) return 0 ;; esac
    return 1
}

# Is $1 a whole line of file $2 (no grep -x / -F on this firmware's toolbox)?
has_line() {
    local l
    [ -f "$2" ] || return 1
    while IFS= read -r l || [ -n "$l" ]; do [ "$l" = "$1" ] && return 0; done < "$2"
    return 1
}

# Rewrite the cfg through a copy: "-<file>" -> "#-<file>" for our three ($1 = on), or back for the lines in $COMMENTED
# ($1 = off). The copy sits next to the cfg (same filesystem), gets the stock owner and mode, and replaces it by rename:
# the cfg is never half written (a failed write leaves the old one), and a copy that came out empty is never used.
cfg_rewrite() {
    local want=$1 cfg tmp line n=0
    cfg=$(cfg_path) || return 1
    tmp=$cfg.jmk
    rm -f $tmp
    : > $tmp || return 1
    while IFS= read -r line || [ -n "$line" ]; do
        if [ $want = on ]; then
            case "$line" in
                "-$PERM/$F_AA.xml"|"-$PERM/$F_CP.xml"|"-$PERM/$F_HS.xml")
                    print -r -- "#$line" >> $tmp; has_line "$line" $COMMENTED || print -r -- "$line" >> $COMMENTED; n=$((n+1)); continue ;;
            esac
        else
            case "$line" in
                "#-"*) if has_line "${line#\#}" $COMMENTED; then print -r -- "${line#\#}" >> $tmp; n=$((n+1)); continue; fi ;;
            esac
        fi
        print -r -- "$line" >> $tmp
    done < $cfg
    [ $n -eq 0 ] && { rm -f $tmp; return 0; }
    if [ ! -s $tmp ]; then rm -f $tmp; log "FAIL: featurexml.cfg copy came out empty, left as it was"; return 1; fi
    chmod 0644 $tmp; chown 0.0 $tmp 2>/dev/null
    sync
    if ! mv $tmp $cfg; then rm -f $tmp; log "FAIL: featurexml.cfg not replaced"; return 1; fi
    sync
    log "featurexml.cfg: $n line(s) $( [ $want = on ] && echo commented || echo restored ), now $(md5of $cfg)"
    return 0
}

feature_file() {   # $1 = the feature name: a stock-format permissions file with that one feature
    local f=$PERM/$1.xml
    [ -f $R$f ] && return 0
    echo '<?xml version="1.0" encoding="utf-8"?>' > $R$f && echo "<permissions><feature name=\"$1\" /></permissions>" >> $R$f \
        && chmod 0644 $R$f && echo $f >> $ADDED
}

# The properties' values before us, once: an update keeps the first install's.
props_save() {
    local p
    [ -f $PROPS_BEFORE ] && return 0
    for p in $PROPS; do echo "$p=$(getprop $p)" >> $PROPS_BEFORE; done
}

# The uninstall: every property back to its recorded value (empty when it had none).
props_restore() {
    local p v
    [ -f $PROPS_BEFORE ] || return 0
    while IFS='=' read -r p v; do [ -n "$p" ] && setprop "$p" "$v"; done < $PROPS_BEFORE
}
