#!/system/bin/sh
set -e
. ./scripts/common.sh
# an update that stopped half-way may have taken the state and the app file already (2.4.4): carry on from there
[ -f "$STATE_FILE" ] || { [ ! -f "$TARGET" ] && mkdir -p "$BACKUP" && echo absent > "$STATE_FILE"; } || { echo 'No installation backup state; leaving APK untouched' >&2; exit 1; }
state=$(cat "$STATE_FILE")
case "$state" in present) [ -f "$PREVIOUS_APK" ] || exit 1 ;; absent) ;; *) exit 1 ;; esac
same_file "$TARGET" app/JMKAmbient.apk || [ ! -f "$TARGET" ] || { echo 'Installed APK changed; leaving it untouched' >&2; exit 1; }
stop_worker || { echo 'Could not stop the ambient worker; leaving APK untouched' >&2; exit 1; }
if [ -r "$RECIPE_FILE" ]; then
    mkdir -p "$RECIPE_BACKUP"
    chmod 0700 "$RECIPE_BACKUP"
    recipe_copy=$RECIPE_BACKUP/recipes-$(date +%Y%m%d-%H%M%S)-$$.json
    cp "$RECIPE_FILE" "$recipe_copy"
    chmod 0600 "$recipe_copy"
    same_file "$RECIPE_FILE" "$recipe_copy" || exit 1
    echo "Recipe backup: $recipe_copy"
fi
begin_system_write
trap 'end_system_write' 0
# the stock CarPlay library name back (exact original bytes; the shim file stays). Only here, after every check that
# can stop this hook: a stopped uninstall or update keeps the package, so it keeps its tap too. Before 2.4.5 this ran
# first and such a stop left the package without it (car 2026-11-11); bin/boot.sh now also puts a missing tap back.
carplay_tap uninstall
if [ "$state" = present ]; then replace_apk "$PREVIOUS_APK"; else rm -f "$TARGET"; sync; fi
end_system_write
trap - 0
# Restore the old APK's Dalvik cache as well as its bytes (ambient.apk.settle without the wait), then the runtime copy (only when it is the package's own)
if [ "$state" = present ]; then ctl ambient.apk.settle || true; fi
ctl ambient.runtime.drop || true
rm -f "$STATE_FILE"
echo 'Recipes remain in app data and a readable copy was backed up when available.'
