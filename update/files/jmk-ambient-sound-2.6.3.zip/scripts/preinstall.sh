#!/system/bin/sh
set -e
. ./scripts/common.sh
# Any head unit (2.5.4): on one these commands were not checked on, it installs locked (ambient.model, AmbientCtl): no light command, no CarPlay
# sound tap, the MAP menu's screen read-only. Before, the install was refused. The dex runs from the staging dir (this hook's cwd).
CTL_DEX=$PWD/bin/miclight.dex
ctl ambient.model say=pre || true
# the JMK MAP menu decides whether this version may run (2.1.1+) and updates it: it goes in first. Only on a first
# install: an update has already run the old package's uninstall hooks by now (NEMESIS is not transactional), so a
# refusal here would leave it half removed. The backups folder outlives an uninstall.
if [ ! -d "$BACKUP" ] && [ ! -d /data/nemesis/apps/jmk-map-menu ] && [ ! -d /data/nemesis/packages/jmk-map-menu ]; then
    echo 'JMK 런처 메뉴(jmk-map-menu)를 먼저 설치하세요 (install jmk-map-menu first)' >&2
    exit 1
fi
# 2.5.11 (the owner, 2026-11-17): installs next to the Korean mod package again (2.5.7-2.5.10 refused a first install there)
[ -f app/JMKAmbient.apk ] && [ -f bin/miclight.dex ] && [ -f bin/ambient_party_mode.sh ] || { echo 'Package payload incomplete' >&2; exit 1; }
if [ -e "$TARGET" ]; then
    if ! same_file "$TARGET" app/JMKAmbient.apk && ! same_file "$TARGET" app/JMKAmbient-approved-legacy.apk; then
        # 2.5.20: one of our own earlier releases (left by a factory reset, which keeps /system, or a removal cut
        # short) is ours to replace; anything else stays refused
        set -- $(md5 "$TARGET" 2>/dev/null)
        if [ -n "$1" ] && [ -f app/JMKAmbient-known.md5 ] && grep -q "^$1\$" app/JMKAmbient-known.md5; then
            echo "Existing JMKAmbient.apk is an earlier JMK Active Ambient release ($1): replaced"
        else
            echo 'Existing JMKAmbient.apk differs from the approved build; refusing replacement' >&2
            exit 1
        fi
    fi
fi
