#!/system/bin/sh
TARGET=/system/app/JMKAmbient.apk
BACKUP=/data/nemesis/backups/jmk-ambient-sound
STATE_FILE=$BACKUP/previous-state
PREVIOUS_APK=$BACKUP/JMKAmbient.previous.apk
RECIPE_FILE=/data/data/com.jmk.ambient/files/recipes.json
RECIPE_BACKUP=/data/nemesis/backups/jmk-ambient-sound-recipes
PKG=/data/nemesis/apps/jmk-ambient-sound
REMOUNTED_RW=0

same_file() { [ -f "$1" ] && [ -f "$2" ] && cmp "$1" "$2" >/dev/null 2>&1; }
# Every stock-facing step of the hooks and of the boot service is a verb of AmbientCtl in miclight.dex (2.6.0): ctl <verb> [k=v ...] runs it
# in a short process of its own (a work dir with the dalvik cache a fresh app_process needs) and returns the verb's exit code (127: it did not
# run). CTL_DEX names another dex (the preinstall's staging copy). The verbs are: ambient.model, .report, .report.locked, .boot.run,
# .hook.stop, .runtime.stage / .drop, .migrate.old, .apk.settle, .tiles.install, .tap.prepare / .boot / .remove / .repair.
ctl() {
    ctl_dex=${CTL_DEX:-$PKG/bin/miclight.dex}
    [ -f "$ctl_dex" ] || return 127
    ctl_n=0
    while ! mkdir "/data/nemesis/jmk-ambient-sound-ctl-$$-$ctl_n" 2>/dev/null; do
        ctl_n=$((ctl_n + 1))
        [ "$ctl_n" -lt 10 ] || return 127
    done
    ctl_work=/data/nemesis/jmk-ambient-sound-ctl-$$-$ctl_n
    chmod 0700 "$ctl_work" 2>/dev/null || true
    mkdir "$ctl_work/dalvik-cache" 2>/dev/null || { rm -rf "$ctl_work" 2>/dev/null || true; return 127; }
    ANDROID_DATA="$ctl_work" CLASSPATH="$ctl_dex" /system/bin/app_process /system/bin jmkaudioprobe.AmbientCtl "$@" </dev/null
    ctl_rc=$?
    rm -rf "$ctl_work" 2>/dev/null || true
    return "$ctl_rc"
}
# Another model not checked yet (2.5.4, the rule in AmbientCtl ambient.model): true when the light may run here.
model_ok() { ctl ambient.model >/dev/null 2>&1; }
# A locked install tells the developer once per version, through the JMK MAP menu's outbox: this head unit's device, fingerprint and car
# model code, so that the model can be checked and turned on. Nothing else. Never fails.
locked_report() { ctl ambient.report.locked >/dev/null 2>&1 || true; return 0; }
# A report to the developer (2.5.5) through the JMK MAP menu's outbox, sent when the head unit is online and reports are on:
# report <type> <msg> [<detail> [<log file>]]. Never fails.
report() {
    ctl ambient.report "type=$1" "msg=$2" ${3:+"detail=$3"} ${4:+"file=$4"} >/dev/null 2>&1 || true
    return 0
}
# The same without Java (2.5.5), for when the helper itself does not run: plain_report <file name> <type> <msg>, a fixed
# message (no quotes), no detail.
plain_report() {
    pr_box=/data/local/tmp/jmk-map-menu/outbox
    [ -d "$pr_box" ] || return 0
    pr_ver=
    { while read -r pr_line; do case "$pr_line" in package-version=*) pr_ver=${pr_line#package-version=} ;; esac; done < "$PKG/NEMESIS.data"; } 2>/dev/null || true
    pr_tmp=$pr_box/.jmk-ambient-sound-$1-$$.tmp
    echo "{\"kind\":\"jmk-report\",\"type\":\"$2\",\"app\":\"jmk-ambient-sound\",\"ver\":\"$pr_ver\",\"msg\":\"$3\",\"detail\":\"\",\"at\":$(date +%s)000}" > "$pr_tmp" 2>/dev/null || { rm -f "$pr_tmp"; return 0; }
    chmod 0644 "$pr_tmp" 2>/dev/null || true
    mv "$pr_tmp" "$pr_box/jmk-ambient-sound-$1.json" 2>/dev/null || rm -f "$pr_tmp"
    return 0
}
# CarPlay sound for the light (2.3.0): bin/libjmkalsa.so preloaded into the CarPlay app (F3 first: only where it fits this car's libraries),
# put in and taken out by CarPlayTap (in miclight.dex; the 4 KB shim stays on uninstall). Best effort: a refusal or an error only means the
# light does not follow CarPlay; the install or uninstall goes on. carplay_tap install|uninstall|repair. Takes effect at the next boot.
carplay_tap() {
    case "$1" in install) tap_verb=prepare ;; uninstall) tap_verb=remove ;; *) tap_verb=$1 ;; esac
    tap_out=$(ctl "ambient.tap.$tap_verb" 2>&1) || true
    [ -z "$tap_out" ] || echo "$tap_out"
    case "$tap_out" in *'ok tap='*) ;; *) plain_report "carplay-tap-$1" error "carplay-tap $1: helper did not run" ;; esac
    return 0
}
begin_system_write() {
    found=0; writable=0
    while read -r dev mountpoint fs options rest; do
        [ "$mountpoint" = /system ] || continue
        found=1
        case ",$options," in *,rw,*) writable=1 ;; esac
        break
    done < /proc/mounts
    [ "$found" -eq 1 ] || { echo 'Cannot determine /system mount state' >&2; return 1; }
    if [ "$writable" -eq 0 ]; then /system/xbin/nemesis remount rw || return 1; REMOUNTED_RW=1; fi
}
end_system_write() {
    # /system stays read-write (NEMESIS leaves it so after boot): a "remount ro" that failed (EBUSY) used to fail this
    # hook, and an update then stopped half-way with the package half-removed (car 2026-11-10, ambient 2.4.3)
    REMOUNTED_RW=0
    return 0
}
# Stops the ambient worker for an install or an uninstall (ambient.hook.stop): a running one is remembered so that the boot service starts it
# again after an update. The first argument is the controller to ask (the staged shim); none = the runtime copy. Returns the stop's exit code.
# U1 (2.6.0): the uninstall is the release's way back and must never depend on the Java helper. When ctl cannot run (no dex, a damaged one, an
# unwritable dalvik cache: no "ok stopped=" line), our own worker is stopped from the shell instead.
stop_worker() {
    stop_out=$(if [ -n "$1" ]; then ctl ambient.hook.stop "controller=$1"; else ctl ambient.hook.stop; fi 2>&1)
    stop_rc=$?
    [ -z "$stop_out" ] || echo "$stop_out"
    case "$stop_out" in *'ok stopped='*) return "$stop_rc" ;; esac
    stop_worker_shell
}
# a process that is there and not a zombie (a zombie has ended; its parent has not looked yet)
sw_alive() {
    [ -r "/proc/$1/stat" ] || return 1
    read -r sw_l < "/proc/$1/stat" || return 1
    case "$sw_l" in *') Z '*) return 1 ;; esac
    return 0
}
# Our worker, found by its command line (AmbientCtl worker.run), asked to end with TERM, KILL after 5 s. No restore runs (the light's records
# stay for the boot's restore, as after a power cut). Never fails.
stop_worker_shell() {
    sw_found=0
    for sw_d in /proc/[0-9]*; do
        [ -r "$sw_d/cmdline" ] || continue
        grep -q 'jmkaudioprobe.AmbientCtl' "$sw_d/cmdline" 2>/dev/null || continue
        grep -q 'worker.run' "$sw_d/cmdline" 2>/dev/null || continue
        sw_pid=${sw_d#/proc/}
        [ "$sw_pid" != "$$" ] || continue
        sw_found=$((sw_found + 1))
        kill -TERM "$sw_pid" 2>/dev/null
        sw_n=0
        while sw_alive "$sw_pid" && [ "$sw_n" -lt 50 ]; do sleep 0.1; sw_n=$((sw_n + 1)); done
        ! sw_alive "$sw_pid" || kill -KILL "$sw_pid" 2>/dev/null
    done
    echo "The Java helper did not run: the ambient worker was stopped from the shell ($sw_found found)."
    return 0
}
# The shim and the dex into the launcher's data dir, as uid 1000 (the package tree can be root-private): ambient.runtime.stage.
install_runtime() { ctl ambient.runtime.stage "dir=$1"; }
replace_apk() {
    source_apk=$1
    temp_apk=$TARGET.pending.$$
    [ ! -e "$temp_apk" ] || return 1
    cp "$source_apk" "$temp_apk" || return 1
    chmod 0644 "$temp_apk" || { rm -f "$temp_apk"; return 1; }
    same_file "$source_apk" "$temp_apk" || { rm -f "$temp_apk"; return 1; }
    mv "$temp_apk" "$TARGET" || return 1
    sync
    same_file "$source_apk" "$TARGET"
}
