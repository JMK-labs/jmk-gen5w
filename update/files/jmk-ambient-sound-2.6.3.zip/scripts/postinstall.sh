#!/system/bin/sh
set -e
. ./scripts/common.sh
[ -f app/JMKAmbient.apk ] && [ -f bin/miclight.dex ] || exit 1
# Taking over from the old package id (ambient-sound, app org.gen5w.ambientsound, up to 2.0.7): stop its worker so the two never fight over the
# light (and start ours after this install if it ran), and leave its settings where the new app imports them on its first start. The old package
# is then removed with `nemesis uninstall ambient-sound`. (ambient.migrate.old)
ctl ambient.migrate.old || true
chmod 0755 "$PKG" "$PKG/bin" "$PKG/scripts"
chmod 0644 "$PKG/bin/miclight.dex" "$PKG/bin/ambient_party_mode.sh"
[ ! -f "$PKG/bin/libjmkalsa.so" ] || chmod 0644 "$PKG/bin/libjmkalsa.so"
stage=/data/nemesis/jmk-ambient-sound-stage-$$
[ ! -e "$stage" ] || { echo 'Runtime staging path already exists' >&2; exit 1; }
mkdir "$stage"
chmod 0755 "$stage"
trap 'rm -rf "$stage"' 0
cp "$PKG/bin/ambient_party_mode.sh" "$stage/ambient_party_mode.sh"
cp "$PKG/bin/miclight.dex" "$stage/miclight.dex"
chmod 0644 "$stage/ambient_party_mode.sh" "$stage/miclight.dex"
same_file "$PKG/bin/ambient_party_mode.sh" "$stage/ambient_party_mode.sh"
same_file "$PKG/bin/miclight.dex" "$stage/miclight.dex"
mkdir -p "$BACKUP"
chmod 0700 "$BACKUP"
if [ -f "$STATE_FILE" ]; then
    state=$(cat "$STATE_FILE")
    case "$state" in present) [ -f "$PREVIOUS_APK" ] || exit 1 ;; absent) ;; *) exit 1 ;; esac
else
    state_new=$BACKUP/previous-state.new.$$
    if [ -f "$TARGET" ]; then
        previous_new=$BACKUP/JMKAmbient.previous.new.$$
        cp "$TARGET" "$previous_new"
        chmod 0600 "$previous_new"
        same_file "$TARGET" "$previous_new" || exit 1
        mv "$previous_new" "$PREVIOUS_APK"
        echo present > "$state_new"
    else
        echo absent > "$state_new"
    fi
    chmod 0600 "$state_new"
    mv "$state_new" "$STATE_FILE"
fi
stop_worker "$stage/ambient_party_mode.sh" || { echo 'Could not stop the ambient worker; APK left unchanged' >&2; exit 1; }
install_runtime "$stage" || { echo 'Could not stage the system-UID runtime; APK left unchanged' >&2; exit 1; }
begin_system_write
trap 'end_system_write; rm -rf "$stage"' 0
replace_apk app/JMKAmbient.apk
# another model not checked yet (2.5.4): installed locked, so no CarPlay sound tap either (nothing to feed)
locked=0
model_ok || locked=1
if [ "$locked" -eq 0 ]; then
    carplay_tap install
else
    ctl ambient.model say=post || true
fi
end_system_write
rm -rf "$stage"
trap - 0
# a fresh dex cache for the replaced APK and the wait until PackageManager has it (reports "package not registered" after 10 s); the home tile
ctl ambient.apk.settle wait=1 || true
ctl ambient.tiles.install "dir=$PWD" || true
# a locked install tells the developer once per version (this head unit's model, for checking it)
[ "$locked" -eq 0 ] || locked_report
exit 0
